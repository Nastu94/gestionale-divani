<?php

namespace App\Http\Controllers;

use App\Http\Controllers\OrderPublicConfirmationController;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\OrderNumber;
use App\Models\Product;
use App\Models\Component;
use App\Models\Fabric;
use App\Models\Color;
use App\Models\StockLevel;
use App\Models\StockMovement;
use App\Models\StockReservation;
use App\Models\Customer;
use App\Models\OccasionalCustomer;
use App\Policies\OrderPolicy;
use App\Services\InventoryService;
use App\Services\ProcurementService;
use App\Services\OrderUpdateService;
use App\Services\OrderDeleteService;
use App\Services\ReturnedProductReservationService; 
use App\Services\Traits\InventoryServiceExtensions;
use App\Support\Pricing\CustomerPriceResolver;
use App\Mail\Orders\OrderConfirmationRequestMail;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Symfony\Component\HttpKernel\Exception\HttpExceptionInterface;
use Throwable;

class OrderCustomerController extends Controller
{
    // inietta il resolver
    public function __construct(private CustomerPriceResolver $priceResolver) {}

    /**
     * Mostra l’elenco paginato degli ordini cliente.
     * Questo metodo gestisce la visualizzazione della pagina degli ordini,
     * con supporto per ordinamento e filtri dinamici.
     * 
     * @param Request $request
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        /*──── Parametri ───*/
        $sort    = $request->input('sort', 'ordered_at');
        $dir     = $request->input('dir',  'desc') === 'asc' ? 'asc' : 'desc';
        $filters = $request->input('filter', []);

        /*──── Whitelist ordinabile ───*/
        $allowedSorts = ['id', 'customer', 'ordered_at', 'delivery_date', 'total', 'reference'];
        if (! in_array($sort, $allowedSorts, true)) $sort = 'ordered_at';

        /*──── Query ───*/
        $orders = Order::query()
            ->with([
                'customer:id,company',
                'occasionalCustomer:id,company',
                'orderNumber:id,number,order_type'
            ])
            ->whereHas('orderNumber', fn ($q) => $q->where('order_type', 'customer'))

            /*──────── EXIST test produzione avviata ────────*/
            ->select('orders.*')                       // <- mantieni i campi base
            ->selectRaw(
                'EXISTS (
                    SELECT 1
                    FROM   order_items oi
                    JOIN   v_order_item_phase_qty v
                        ON v.order_item_id = oi.id
                    WHERE  oi.order_id    = orders.id
                    AND  v.phase        > 0          -- oltre “Inserito”
                    AND  v.qty_in_phase > 0
                ) AS has_started_prod'
            )

            /*─── Filtri ───*/
            ->when($filters['id'] ?? null,
                fn ($q,$v) => $q->where('id', $v))

            ->when($filters['customer'] ?? null, function ($q,$v) {
                $q->where(function ($q) use ($v) {
                    $q->whereHas('customer',
                            fn ($q) => $q->where('company','like',"%$v%"))
                    ->orWhereHas('occasionalCustomer',
                            fn ($q) => $q->where('company','like',"%$v%"));
                });
            })

            ->when($filters['ordered_at'] ?? null,
                fn ($q,$v) => $q->whereDate('ordered_at', $v))

            ->when($filters['delivery_date'] ?? null,
                fn ($q,$v) => $q->whereDate('delivery_date', $v))

            ->when($filters['total'] ?? null,
                fn ($q,$v) => $q->where('total', 'like', "%$v%"))

            ->when($filters['reference'] ?? null,
                fn ($q,$v) => $q->where('reference', 'like', "%{$v}%"))

            /*─── Ordinamento ───*/
            ->when($sort === 'customer', function ($q) use ($dir) {
                $q->leftJoin('customers as c',          'orders.customer_id',            '=', 'c.id')
                ->leftJoin('occasional_customers as oc','orders.occasional_customer_id','=','oc.id')
                ->orderByRaw("COALESCE(c.company, oc.company) {$dir}")
                ->select('orders.*');
            }, function ($q) use ($sort, $dir) {
                $q->orderBy($sort, $dir);
            })

            ->paginate(15)
            ->appends($request->query());
        
        // Carico le opzioni globali Tessuti/Colori attivi (id + name o code come fallback)
        $fabrics = Fabric::query()
            ->when(\Schema::hasColumn('fabrics','is_active'), fn($q)=>$q->where('is_active',1))
            ->orderBy('name')
            ->get(['id','name','code']);

        $colors = Color::query()
            ->when(\Schema::hasColumn('colors','is_active'), fn($q)=>$q->where('is_active',1))
            ->orderBy('name')
            ->get(['id','name','code']);

        $variableOptions = [
            'fabrics' => $fabrics->map(fn($f)=>[
                'id'   => $f->id,
                'name' => $f->name ?? $f->code ?? ('Tessuto #'.$f->id),
            ])->values(),
            'colors'  => $colors->map(fn($c)=>[
                'id'   => $c->id,
                'name' => $c->name ?? $c->code ?? ('Colore #'.$c->id),
            ])->values(),
        ];

        return view('pages.orders.index-customers',
            compact('orders', 'sort', 'dir', 'filters'))
            ->with('variableOptions', $variableOptions);
    }

    /**
     * Stampa le righe selezionate nella tabella Ordini Cliente.
     *
     * La stampa non genera etichette: crea una pagina HTML stampabile
     * con le stesse colonne visibili nell'elenco principale.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\View\View|\Illuminate\Http\RedirectResponse
     */
    public function printSelected(Request $request): \Illuminate\View\View|RedirectResponse
    {
        /*
        * La rotta è già protetta dal middleware permission:orders.customer.view,
        * ma manteniamo anche un controllo esplicito lato controller.
        */
        abort_unless($request->user()?->can('orders.customer.view'), 403);

        /*
        * Validiamo gli ID ricevuti dal form.
        *
        * Laravel, con $request->validate(), interrompe automaticamente
        * l'esecuzione se la validazione fallisce e reindirizza indietro
        * nelle richieste HTTP tradizionali.
        */
        $data = $request->validate([
            'ids'   => ['required', 'array', 'min:1', 'max:100'],
            'ids.*' => ['required', 'integer', 'distinct', 'exists:orders,id'],
        ]);

        /*
        * Normalizziamo gli ID:
        * - cast a intero
        * - rimozione duplicati
        * - reset degli indici
        */
        $ids = collect($data['ids'])
            ->map(fn ($id) => (int) $id)
            ->unique()
            ->values();

        /*
        * Carichiamo solo ordini cliente.
        *
        * Manteniamo anche il calcolo has_started_prod usato nella tabella
        * principale, così la stampa resta coerente con la vista elenco.
        */
        $orders = Order::query()
            ->with([
                'customer:id,company',
                'occasionalCustomer:id,company',
                'orderNumber:id,number,order_type',
            ])
            ->whereHas('orderNumber', fn ($q) => $q->where('order_type', 'customer'))
            ->select('orders.*')
            ->selectRaw(
                'EXISTS (
                    SELECT 1
                    FROM   order_items oi
                    JOIN   v_order_item_phase_qty v
                        ON v.order_item_id = oi.id
                    WHERE  oi.order_id    = orders.id
                    AND    v.phase        > 0
                    AND    v.qty_in_phase > 0
                ) AS has_started_prod'
            )
            ->whereIn('orders.id', $ids)
            ->get()
            /*
            * Manteniamo l'ordine con cui gli ID sono arrivati dal frontend.
            */
            ->sortBy(fn (Order $order) => $ids->search((int) $order->id))
            ->values();

        /*
        * Se qualcuno prova a inviare ID non coerenti con ordini cliente,
        * blocchiamo la stampa.
        */
        abort_if($orders->count() !== $ids->count(), 404, 'Uno o più ordini selezionati non sono disponibili.');

        return view('pages.orders.print-selected-customers', [
            'orders' => $orders,
            'printedAt' => now(),
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Salva un nuovo ordine cliente.
     *
     * Regole:
     * - OCCASIONALE: conferma automatica (status=1) e si esegue SUBITO il flusso attuale:
     *   verifica → prenota → PO per shortfall. La "verifica disponibilità" lato FE è obbligatoria.
     * - STANDARD: allo store NON si toccano materiali/PO. Si genera un token di conferma e si invierà la mail
     *   (Step 4). I PO saranno valutati SOLO dopo conferma cliente e SOLO se delivery_date - confirmed_at < 30 gg.
     */
    public function store(Request $request): JsonResponse
    {
        Log::info('OrderCustomer@store – richiesta ricevuta (con variabili + sconti)', [
            'user_id' => optional($request->user())->id,
            'payload' => $request->all(),
        ]);

        /*──────────────── VALIDAZIONE ────────────────*/
        $data = $request->validate([
            'order_number_id'        => ['required', 'integer', Rule::exists('order_numbers', 'id')],
            'occasional_customer_id' => ['nullable', 'integer', Rule::exists('occasional_customers', 'id')],
            'customer_id'            => ['nullable', 'integer', Rule::exists('customers', 'id')],
            'delivery_date'          => ['required', 'date'],
            'shipping_address'       => ['required', 'string', 'max:255'],

            // NEW: flag "#" (ordine nero) e note ordine
            'hash_flag'              => ['sometimes', 'boolean'],
            'note'                   => ['nullable', 'string'],
            'reference'             => ['nullable', 'string', 'max:255'],
            // NEW: zona spedizione (nota interna, solo stampa documenti)
            'shipping_zone'          => ['nullable', 'string', 'max:255'],
            'packages'               => ['nullable', 'integer', 'min:1'],

            // NEW: note colori per riga (multi-colore/dettagli interni)
            'lines.*.color_notes'    => ['nullable', 'string'],

            'lines'                  => ['required', 'array', 'min:1'],
            'lines.*.product_id'     => ['required', 'integer', Rule::exists('products', 'id')],
            'lines.*.quantity'       => ['required', 'numeric', 'min:0.01'],

            // prezzo lato client opzionale (solo se l’utente ha permesso override)
            'lines.*.price'          => ['nullable', 'numeric', 'min:0'],

            // variabili di riga
            'lines.*.fabric_id'      => ['nullable', 'integer', Rule::exists('fabrics', 'id')],
            'lines.*.color_id'       => ['nullable', 'integer', Rule::exists('colors', 'id')],

            // NEW: sconti riga come token "N%" o "N"
            'lines.*.discount'       => ['sometimes', 'array'],
            'lines.*.discount.*'     => ['string','regex:/^\d+(\.\d+)?%?$/'],
        ]);

        /*──────────────── NORMALIZZAZIONE CAMPI EXTRA ────────────────*/
        // Normalizza shipping_zone: stringa vuota -> null
        if (array_key_exists('shipping_zone', $data)) {
            $data['shipping_zone'] = trim((string) $data['shipping_zone']);
            if ($data['shipping_zone'] === '') {
                $data['shipping_zone'] = null;
            }
        }

        // Normalizza reference: stringa vuota -> null
        if (array_key_exists('reference', $data)) {
            $data['reference'] = trim((string) $data['reference']);
            if ($data['reference'] === '') {
                $data['reference'] = null;
            }
        }

        // Normalizza color_notes: stringa vuota -> null
        if (array_key_exists('lines', $data)) {
            foreach ($data['lines'] as &$line) {
                if (array_key_exists('color_notes', $line)) {
                    $line['color_notes'] = trim((string) $line['color_notes']);
                    if ($line['color_notes'] === '') {
                        $line['color_notes'] = null;
                    }
                }
            }
        }

        Log::debug('OrderCustomer@store – dati validati', $data);

        /* esclusività customer_id / occasional_customer_id */
        if (! ($data['customer_id'] xor ($data['occasional_customer_id'] ?? null))) {
            Log::warning('OrderCustomer@store – violazione esclusività customer vs occasional', $data);
            return response()->json(['message' => 'Indicare solo customer_id oppure occasional_customer_id.'], 422);
        }

        $deliveryDate = Carbon::parse($data['delivery_date'])->toDateString();
        $isOccasional = !empty($data['occasional_customer_id']); // NEW: ramo cliente occasionale

        /*──────────────── HELPER LOCALI (closure) ────────────────*/

        // Normalizza tipo surcharge (per logging/meta).
        $normType = function (?string $t): string {
            $t = strtolower((string)$t);
            return in_array($t, ['percent','percentage','%'], true) ? 'percent' : 'fixed';
        };

        // Somma importi surcharge per meta (solo diagnostica/meta, NON influenza il prezzo).
        $appliedAmount = function (float $base, string $type, ?float $value, float &$fixedSum, float &$percentSum): float {
            $v = (float)($value ?? 0);
            if ($type === 'percent') { $percentSum += $v; return $base * ($v / 100); }
            $fixedSum += $v; return $v;
        };

        // Risolve il componente effettivo dello slot variabile (per meta di tracciabilità).
        $resolveResolvedComponentId = function (Product $product, ?int $fabricId, ?int $colorId): ?int {
            $placeholder = $product->variableComponent();    // riga BOM “slot”
            if (! $placeholder) return null;
            $qid = Component::query()
                ->where('category_id', $placeholder->category_id)
                ->when($fabricId, fn($q)=>$q->where('fabric_id', $fabricId))
                ->when($colorId,  fn($q)=>$q->where('color_id',  $colorId))
                ->value('id');
            return $qid ?: $placeholder->id; // fallback prudente allo slot
        };

        // Meta surcharge tessuto/colore (prende pivot, fallback tabella).
        $fabricMeta = function (Product $product, ?int $fabricId): array {
            if (!$fabricId) return ['type'=>null,'value'=>null];
            $pf = $product->fabrics()->where('fabrics.id', $fabricId)->first();
            $type  = $pf?->pivot?->surcharge_type;
            $value = $pf?->pivot?->surcharge_value;
            if ($type === null || $value === null) { // fallback alla tabella fabrics
                $fab   = Fabric::select('surcharge_type','surcharge_value')->find($fabricId);
                $type  = $fab?->surcharge_type;
                $value = $fab?->surcharge_value;
            }
            return ['type'=>$type, 'value'=>$value];
        };
        $colorMeta = function (Product $product, ?int $colorId): array {
            if (!$colorId) return ['type'=>null,'value'=>null];
            $pc = $product->colors()->where('colors.id', $colorId)->first();
            $type  = $pc?->pivot?->surcharge_type;
            $value = $pc?->pivot?->surcharge_value;
            if ($type === null || $value === null) { // fallback alla tabella colors
                $col   = Color::select('surcharge_type','surcharge_value')->find($colorId);
                $type  = $col?->surcharge_type;
                $value = $col?->surcharge_value;
            }
            return ['type'=>$type, 'value'=>$value];
        };

        // applica i token sconto ("N%" o "N" in €) in sequenza sul prezzo lordo unitario.
        $applyDiscountTokens = function (float $unitGross, array $tokens): array {
            $price = $unitGross;
            foreach ($tokens as $tok) {
                if (!is_string($tok) || $tok === '') continue;
                $tok = trim($tok);
                if (str_ends_with($tok, '%')) {
                    $p = (float) substr($tok, 0, -1);
                    $price = $price * max(0.0, (100.0 - $p)) / 100.0;
                } else {
                    $f = (float) $tok;
                    $price = $price - max(0.0, $f);
                }
            }
            $unitNet = max(0.0, round($price, 2));
            $discVal = round($unitGross - $unitNet, 2);
            return [$unitNet, $discVal];
        };

        /*──────────────── VERIFICA DISPONIBILITÀ ────────────────*/
        // NEW: la pre-verifica (dry-run) è OBBLIGATORIA SOLO per gli OCCASIONALI.
        $inv = null;
        if ($isOccasional) {
            $inv = InventoryService::forDelivery($deliveryDate)
                ->check(collect($data['lines'])->map(fn($l)=>[
                    'product_id' => (int) $l['product_id'],
                    'quantity'   => (float) $l['quantity'],
                    'fabric_id'  => array_key_exists('fabric_id', $l) && $l['fabric_id'] !== null ? (int) $l['fabric_id'] : null,
                    'color_id'   => array_key_exists('color_id',  $l) && $l['color_id']  !== null ? (int) $l['color_id']  : null,
                ])->values()->all());

            if ($inv === null) {
                return response()->json(['message'=>'Esegui prima la verifica disponibilità.'], 409);
            }
        }

        /*──────────────── PREPARAZIONE RIGHE (variabili + pricing + sconti) ────────────────*/
        $customerId  = $data['customer_id'] ?? null; // guest → null
        $canOverride = $request->user()->can('orders.customer.update');

        $resolvedLines = collect($data['lines'])->map(function (array $l) use (
            $customerId, $deliveryDate, $canOverride,
            $normType, $appliedAmount, $resolveResolvedComponentId, $fabricMeta, $colorMeta,
            $applyDiscountTokens
        ) {
            $productId = (int) $l['product_id'];
            $qty       = (float) $l['quantity'];
            $fabricId  = array_key_exists('fabric_id', $l) && $l['fabric_id'] !== null ? (int) $l['fabric_id'] : null;
            $colorId   = array_key_exists('color_id',  $l) && $l['color_id']  !== null ? (int) $l['color_id']  : null;
            $colorNotes = array_key_exists('color_notes', $l) ? trim((string) $l['color_notes']) : null;
            if ($colorNotes === '') {
                $colorNotes = null;
            }

            /** @var \App\Models\Product $product */
            $product   = Product::findOrFail($productId);

            // Sicurezza: variabili scelte DEVONO essere in whitelist prodotto
            if ($fabricId !== null && ! in_array($fabricId, $product->fabricIds(), true)) {
                abort(response()->json(['message' => "Il tessuto selezionato non è consentito per il prodotto #{$productId}."], 422));
            }
            if ($colorId !== null && ! in_array($colorId, $product->colorIds(), true)) {
                abort(response()->json(['message' => "Il colore selezionato non è consentito per il prodotto #{$productId}."], 422));
            }

            // NEW: token sconto riga (array di stringhe "N%" o "N")
            $tokens = array_key_exists('discount', $l) && is_array($l['discount']) ? array_map('strval', $l['discount']) : [];

            // 1) Calcola SEMPRE il LORDO unitario (base + sovrapprezzi tessuto/colore)
            $breakdown = $product->pricingBreakdown($fabricId, $colorId, $customerId, $deliveryDate);
            $unitGross = (float) ($breakdown['unit_price'] ?? 0.0);

            // 2) NETTO unitario: override (se consentito) oppure applicazione sconti dopo i sovrapprezzi
            if ($canOverride && array_key_exists('price', $l) && $l['price'] !== null && $l['price'] !== '') {
                $unitNet  = (float) $l['price'];                // il valore passato È già il NETTO
                $discUnit = round($unitGross - $unitNet, 2);    // solo diagnostica
            } else {
                [$unitNet, $discUnit] = $applyDiscountTokens($unitGross, $tokens);
            }

            // 3) Meta surcharge (facoltativi, per tracciabilità)
            $base = (float) ($breakdown['base_price'] ?? $product->effectiveBasePriceFor($customerId, $deliveryDate));
            $fixedSum   = 0.0;
            $percentSum = 0.0;

            $fm = $fabricMeta($product, $fabricId);
            $cm = $colorMeta($product,  $colorId);

            if ($fm['type'] !== null) {
                $fabricType = $normType($fm['type']);
                $fabricAmt  = $appliedAmount($base, $fabricType, (float)$fm['value'], $fixedSum, $percentSum);
            } else { $fabricType = null; $fabricAmt = 0.0; }

            if ($cm['type'] !== null) {
                $colorType  = $normType($cm['type']);
                $colorAmt   = $appliedAmount($base, $colorType, (float)$cm['value'], $fixedSum, $percentSum);
            } else { $colorType = null; $colorAmt = 0.0; }

            $surchargeTotalApplied = $fabricAmt + $colorAmt;

            // componente effettivo risolto (per slot variabile)
            $resolvedComponentId = $resolveResolvedComponentId($product, $fabricId, $colorId);

            Log::debug('OrderCustomer@store – pricing line resolved (lordo/netto + meta)', [
                'product_id' => $productId,
                'qty'        => $qty,
                'fabric_id'  => $fabricId,
                'color_id'   => $colorId,
                'unit_gross' => $unitGross,
                'unit_net'   => $unitNet,
                'discount_tokens' => $tokens,
                'base_price' => $base,
                'surch_fixed'=> $fixedSum,
                'surch_pct'  => $percentSum,
                'surch_tot'  => $surchargeTotalApplied,
                'resolved_component_id' => $resolvedComponentId,
            ]);

            return [
                'product_id' => $productId,
                'quantity'   => $qty,

                // Persistiamo il NETTO come stringa decimale
                'price'      => number_format($unitNet, 2, '.', ''),

                'fabric_id'  => $fabricId,
                'color_id'   => $colorId,
                'color_notes' => $colorNotes,
                // token sconto da salvare su order_items.discount
                'discount'   => $tokens,

                // meta facoltativi (già presenti nella tua logica)
                'resolved_component_id'     => $resolvedComponentId,
                'surcharge_fixed_applied'   => $fixedSum,
                'surcharge_percent_applied' => $percentSum,
                'surcharge_total_applied'   => $surchargeTotalApplied,
            ];
        })->values();

        // Totale ordine calcolato sul NETTO (quantity * unit_price)
        $total = $resolvedLines->reduce(fn(float $s, $l) => $s + ($l['quantity'] * (float) $l['price']), 0.0);

        try {
            /*──────────────── TRANSAZIONE: salva ordine + righe + variabili ────────────────*/
            /** @var \App\Models\Order $order */
            $order = DB::transaction(function () use ($data, $deliveryDate, $resolvedLines, $total, $isOccasional) {

                /* 1) blocca OrderNumber (customer) */
                $orderNumber = OrderNumber::where('id', $data['order_number_id'])
                    ->where('order_type', 'customer')
                    ->with('order')
                    ->lockForUpdate()
                    ->firstOrFail();

                if ($orderNumber->order) {
                    abort(409, 'OrderNumber già assegnato.');
                }

                /* 2) header */
                $order = Order::create([
                    'order_number_id'        => $orderNumber->id,
                    'customer_id'            => $data['customer_id']            ?? null,
                    'occasional_customer_id' => $data['occasional_customer_id'] ?? null,
                    'shipping_address'       => $data['shipping_address'],
                    'shipping_zone'          => $data['shipping_zone'] ?? null,
                    'reference'              => $data['reference'] ?? null,
                    'packages'               => $data['packages'] ?? null,
                    'total'                  => $total,
                    'ordered_at'             => now(),
                    'delivery_date'          => $deliveryDate,

                    // campi header aggiunti
                    'hash_flag'              => (bool) ($data['hash_flag'] ?? false),
                    'note'                   => $data['note'] ?? null,
                ]);

                /* 3) righe + variabili */
                foreach ($resolvedLines as $line) {
                    /** @var \App\Models\OrderItem $item */
                    $item = $order->items()->create([
                        'product_id' => $line['product_id'],
                        'quantity'   => $line['quantity'],
                        'unit_price' => $line['price'],           // NETTO congelato
                        'discount'   => $line['discount'] ?? [],  // token sconto in JSON
                    ]);

                    // Persisti le variabili della riga (se presenti)
                    $fabricId = $line['fabric_id'] ?? null;
                    $colorId  = $line['color_id']  ?? null;
                    $colorNotes = $line['color_notes'] ?? null;

                    if ($fabricId !== null || $colorId !== null || $colorNotes !== null) {
                        $payload = [];
                        if (Schema::hasColumn('order_product_variables', 'fabric_id'))  { $payload['fabric_id']  = $fabricId; }
                        if (Schema::hasColumn('order_product_variables', 'color_id'))   { $payload['color_id']   = $colorId; }
                        if (Schema::hasColumn('order_product_variables', 'resolved_component_id')) {
                            $payload['resolved_component_id'] = $line['resolved_component_id'] ?? null;
                        }
                        if (Schema::hasColumn('order_product_variables', 'surcharge_fixed_applied')) {
                            $payload['surcharge_fixed_applied'] = $line['surcharge_fixed_applied'] ?? 0;
                        }
                        if (Schema::hasColumn('order_product_variables', 'surcharge_percent_applied')) {
                            $payload['surcharge_percent_applied'] = $line['surcharge_percent_applied'] ?? 0;
                        }
                        if (Schema::hasColumn('order_product_variables', 'surcharge_total_applied')) {
                            $payload['surcharge_total_applied'] = $line['surcharge_total_applied'] ?? 0;
                        }
                        if (Schema::hasColumn('order_product_variables', 'color_notes')) {
                            $payload['color_notes'] = $colorNotes;
                        }
                        if (!empty($payload)) {
                            $item->variables()->create($payload);
                        }
                    }
                }

                /* 3.bis) gestione stato per tipo cliente */
                if ($isOccasional) {
                    // 🟢 OCCASIONALE → conferma automatica
                    if ((int) $order->status === 0) {
                        $order->status       = 1;
                        $order->confirmed_at = now();
                        $order->reason       = null;
                        $order->save();
                    }
                } else {
                    // 🔵 STANDARD → prepara token e marca richiesta (niente Response qui!)
                    $order->confirm_token             = (string) Str::uuid();
                    $order->confirmation_requested_at = now();
                    $order->confirm_locale            = app()->getLocale();
                    $order->save();
                }

                return $order; // IMPORTANT: restituiamo il Model, non una Response
            });

            // === Branching post-transazione ===

            if (is_null($order->occasional_customer_id)) {
                /**
                 * Per gli ordini standard l'ordine è già stato salvato correttamente.
                 * L'eventuale errore di invio mail NON deve trasformare il salvataggio
                 * dell'ordine in un falso errore 500 applicativo.
                 */
                Log::info('OrderCustomer@store – ordine standard salvato, preparo invio mail', [
                    'order_id' => $order->id,
                    'customer_email' => $order->customer->email ?? null,
                ]);

                try {
                    /**
                     * Invio della mail di conferma al cliente.
                     */
                    Mail::to($order->customer->email)->send(new OrderConfirmationRequestMail(
                        order: $order,
                        replacePrevious: $isUpdate ?? false
                    ));

                    Log::info('OrderCustomer@store – mail inviata correttamente', [
                        'order_id' => $order->id,
                    ]);

                    return response()->json([
                        'order_id' => $order->id,
                        'po_numbers' => [],
                        'awaiting_confirmation' => true,
                        'mail_sent' => true,
                        'message' => 'Ordine salvato e richiesta conferma inviata al cliente.',
                    ], 201);

                } catch (Throwable $mailException) {
                    /**
                     * L'ordine è già stato creato: segnaliamo il problema mail senza
                     * mascherarlo come errore interno di salvataggio ordine.
                     */
                    Log::error('OrderCustomer@store – ordine salvato ma invio mail fallito', [
                        'order_id' => $order->id,
                        'customer_email' => $order->customer->email ?? null,
                        'error' => $mailException->getMessage(),
                    ]);

                    return response()->json([
                        'order_id' => $order->id,
                        'po_numbers' => [],
                        'awaiting_confirmation' => true,
                        'mail_sent' => false,
                        'message' => 'Ordine salvato correttamente, ma l\'invio email di conferma è fallito.',
                    ], 201);
                }
            }

            // OCCASIONALI: prosegue il TUO flusso attuale (explode BOM → reserve → check → PO)
            // =========== Tentativo copertura con RESI (prodotti finiti) =====================
            $returnsCoverageByKey = [];   // chiave: "product_id:fabric_id:color_id" => qty coperta
            $makeKey = fn($pid,$fid,$cid) => sprintf('%d:%d:%d', $pid, $fid ?? 0, $cid ?? 0);

            if ($isOccasional) {
                // carica variabili riga per match FC
                $order->load(['items.variable','items.product']);
                $returnsSvc = app(ReturnedProductReservationService::class);

                foreach ($order->items as $it) {
                    // qty da coprire = intera riga (non abbiamo altre coperture fin qui)
                    $res = $returnsSvc->reserveForItem($it, (float)$it->quantity, $request->user());
                    $covered = (float) ($res['reserved'] ?? 0);

                    if ($covered > 0) {
                        $fid = $it->variable?->fabric_id;
                        $cid = $it->variable?->color_id;
                        $k   = $makeKey($it->product_id, $fid, $cid);
                        $returnsCoverageByKey[$k] = ($returnsCoverageByKey[$k] ?? 0) + $covered;
                    }
                }
            }

            // ⬇️ ADATTA le righe usate per la disponibilità: sottrai la qty coperta coi resi
            $usedLines = collect($resolvedLines)
                ->map(function ($l) use (&$returnsCoverageByKey, $makeKey) {
                    $pid = (int) $l['product_id'];
                    $fid = array_key_exists('fabric_id',$l) ? $l['fabric_id'] : null;
                    $cid = array_key_exists('color_id', $l) ? $l['color_id']  : null;
                    $k   = $makeKey($pid, $fid, $cid);

                    $qty     = (float) $l['quantity'];
                    $covered = (float) ($returnsCoverageByKey[$k] ?? 0);

                    if ($covered <= 0) {
                        return [
                            'product_id' => $pid,
                            'quantity'   => $qty,
                            'fabric_id'  => $fid,
                            'color_id'   => $cid,
                        ];
                    }

                    // applica copertura, consumando la mappa (in caso di più righe uguali)
                    $take = min($qty, $covered);
                    $returnsCoverageByKey[$k] = max($covered - $take, 0);

                    $left = $qty - $take;
                    if ($left <= 1e-6) {
                        return null; // riga interamente coperta da resi → NON entra in BOM
                    }

                    return [
                        'product_id' => $pid,
                        'quantity'   => $left,
                        'fabric_id'  => $fid,
                        'color_id'   => $cid,
                    ];
                })
                ->filter()   // rimuovi null (righe totalmente coperte da reso)
                ->values()
                ->all();

            // FABbisogno per componente (senza check iniziale)
            $componentsNeeded = InventoryServiceExtensions::explodeBomArray($usedLines);

            // Prenota arrivi liberi
            InventoryServiceExtensions::reserveFreeIncoming(
                $order,
                $componentsNeeded,
                Carbon::parse($deliveryDate)
            );

            // Check finale per shortfall residui
            $invResult = InventoryService::forDelivery($deliveryDate, $order->id)->check($usedLines);

            foreach ($invResult->shortage as $row) {
                $missing  = $row['shortage'];
                $fromStock= min($row['available'], $missing);

                if ($fromStock > 0) {
                    $sl = StockLevel::where('component_id', $row['component_id'])
                        ->orderBy('quantity')
                        ->first();

                    StockReservation::create([
                        'stock_level_id' => $sl->id,
                        'order_id'       => $order->id,
                        'quantity'       => $fromStock,
                    ]);

                    StockMovement::create([
                        'stock_level_id' => $sl->id,
                        'type'           => 'reserve',
                        'quantity'       => $fromStock,
                        'note'           => "Prenotazione stock per OC #{$order->id}",
                    ]);
                }
            }

            Log::info('OrderCustomer@store – ordine e righe salvati', [
                'order_id' => $order->id,
                'lines'    => $resolvedLines->count(),
                'total'    => $total,
            ]);

            /*────────── CREA / MERGE PO se servono (SOLO OCCASIONALI) ──────────*/
            $poNumbers = [];
            $invFinal  = InventoryService::forDelivery($deliveryDate, $order->id)->check($usedLines);
            if (!$invFinal->ok && $request->user()->can('orders.supplier.create')) {
                $shortCol  = ProcurementService::buildShortageCollection($invFinal->shortage);
                $proc      = ProcurementService::fromShortage($shortCol, $order->id);
                $poNumbers = $proc['po_numbers']->all();
            }

            return response()->json([
                'order_id'   => $order->id,
                'po_numbers' => $poNumbers,
            ], 201);

        } catch (HttpExceptionInterface $e) {
            /**
             * Gestisce correttamente gli errori HTTP applicativi già previsti
             * dal flusso, ad esempio il conflitto 409 su OrderNumber già assegnato.
             *
             * In questo modo non trasformiamo un errore di business noto
             * in un generico 500 interno.
             */
            Log::warning('OrderCustomer@store – errore HTTP gestito', [
                'status'  => $e->getStatusCode(),
                'message' => $e->getMessage(),
            ]);

            return response()->json([
                'message'              => $e->getMessage() ?: 'Richiesta non valida.',
                'refresh_order_number' => $e->getStatusCode() === 409,
            ], $e->getStatusCode());

        } catch (\Throwable $e) {
            Log::error('OrderCustomer@store – eccezione', [
                'error' => $e->getMessage(),
                'trace' => substr($e->getTraceAsString(), 0, 2048),
            ]);

            return response()->json([
                'message' => 'Errore interno durante il salvataggio dell’ordine.'
            ], 500);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(Order $order)
    {
        //
    }

    /**
     * Restituisce in JSON le righe dell’ordine + esploso componenti.
     *
     * Coerenza con la nuova logica prezzi:
     * - Il prezzo unitario del prodotto proviene SEMPRE da $item->unit_price
     *   (valore “congelato” salvato dallo store/update tramite resolver),
     *   quindi NON ricalcoliamo nulla e non richiamiamo il resolver qui.
     * - I costi dei componenti restano informativi (come nel codice originale),
     *   stimati sul supplier col last_cost più basso, se presente.
     *
     * @param  Order  $order  (route model binding)
     * @return \Illuminate\Http\JsonResponse
     */
    public function lines(Order $order): JsonResponse
    {
        // 1) Eager-load: prodotto, BOM con pivot (quantity/is_variable/slot),
        //    suppliers dei componenti BOM, e la variabile di riga (hasOne "variable").
        $order->load([
            'items.product',                                // id, sku, name (ok anche senza select mirato)
            'items.product.components.componentSuppliers',  // per last_cost indicativo
            'items.product.components' => function ($q) {
                // Non stringiamo le colonne per non perdere i campi pivot.
                // La relazione Product::components ha già withPivot(['quantity','is_variable','variable_slot'])
            },
            'items.variable:id,order_item_id,fabric_id,color_id,resolved_component_id',
        ]);

        Log::debug('OrderCustomer@lines - lines for order', [
            'order_id' => $order->id,
            'lines'    => $order->items,
        ]);

        // 2) Pre-carica TUTTI i componenti risolti referenziati dalle righe ordine
        $resolvedIds = $order->items
            ->pluck('variable.resolved_component_id')
            ->filter()
            ->unique()
            ->values();

        Log::debug('OrderCustomer@lines - resolved component IDs', [
            'order_id' => $order->id,
            'resolved_ids' => $resolvedIds,
        ]);

        /** @var \Illuminate\Support\Collection<int,\App\Models\Component> $resolvedMap */
        $resolvedMap = \App\Models\Component::query()
            ->whereIn('id', $resolvedIds)
            ->with(['componentSuppliers:id,component_id,last_cost'])
            ->get()
            ->keyBy('id');

        Log::debug('OrderCustomer@lines - loaded resolved components', [
            'order_id' => $order->id,
            'components' => $resolvedMap->values(),
        ]);

        $rows = collect();

        foreach ($order->items as $item) {
            $product    = $item->product;
            $qtyOrdered = (float) $item->quantity;
            $priceUnit  = (float) $item->unit_price;
            $subtotal   = $qtyOrdered * $priceUnit;

            /* ───────────────── 1) Riga PRODOTTO ───────────────── */
            $rows->push([
                'code'   => $product->sku,
                'desc'   => $product->name,
                'qty'    => $qtyOrdered,
                'unit'   => 'pz',
                'price'  => $priceUnit,       // prezzo congelato di vendita
                'subtot' => $subtotal,
                'type'   => 'product',
            ]);

            Log::debug('OrderCustomer@lines - product row', [
                'order_id' => $order->id,
                'row'      => $rows->last(),
            ]);

            /* ─────────────── 2) Righe COMPONENTI ────────────────
            Se il componente BOM è "variabile", sostituisco il placeholder
            con il componente realmente selezionato in ordine (resolved_component_id).
            */
            $resolvedId = $item->variable?->resolved_component_id;

            foreach ($product->components as $component) {
                $isVar = (bool) ($component->pivot->is_variable ?? false);

                // Se variabile e ho un resolved_component_id valido → sostituisco
                $compEff = ($isVar && $resolvedId && $resolvedMap->has($resolvedId))
                    ? $resolvedMap->get($resolvedId)
                    : $component;

                // qty componente richiesto per la riga d’ordine
                $qtyComp = $qtyOrdered * (float) ($component->pivot->quantity ?? 0);

                // costo indicativo: supplier col last_cost più basso
                $priceComp = optional(
                    $compEff->componentSuppliers->sortBy('last_cost')->first()
                )->last_cost ?? 0.0;

                $rows->push([
                    'code'   => $compEff->code,
                    'desc'   => $compEff->description,
                    'qty'    => $qtyComp,
                    'unit'   => $compEff->unit_of_measure ?? 'pz',
                    'price'  => (float) $priceComp,
                    'subtot' => (float) $priceComp * $qtyComp,
                    'type'   => 'component',
                ]);
            }
        }

        Log::debug('OrderCustomer@lines - all rows', [
            'order_id' => $order->id,
            'rows'     => $rows,
        ]);

        // Manteniamo l’ordine "prodotto → suoi componenti"
        return response()->json([
            'rows'   => $rows->values(),
            'note'   => $order->note,      // TEXT/nullable
            'reason' => $order->reason,    // TEXT/nullable → popolata in caso di rifiuto
            'reference' => $order->reference,
            'packages' => $order->packages,
        ]);
    }

    /**
     * GET /orders/customer/{order}/edit
     * Restituisce i dati ordine in JSON per il modal “Modifica”.
     *
     * @param  Order  $order
     * @return \Illuminate\Http\JsonResponse
     */
    public function edit(Order $order): JsonResponse
    {
        /* ── Eager-load con i campi che servono alla UI ── */
        $order->load([
            'items.product:id,sku,name,price',
            'items.variable:id,order_item_id,fabric_id,color_id,color_notes,resolved_component_id,surcharge_fixed_applied,surcharge_percent_applied,surcharge_total_applied',
            'items.variable.fabric:id,name',
            'items.variable.color:id,name',
            'customer:id,company,email,vat_number,tax_code',
            'customer.shippingAddress:id,customer_id,address,city,postal_code,country',
            'occasionalCustomer:id,company,email,vat_number,tax_code,address,postal_code,city,province,country',
        ]);

        /* 1️⃣ formatter indirizzo di spedizione */
        $fmt = function ($addr = null) {
            if (!$addr) return null;

            return collect([
                $addr->address,
                $addr->postal_code && $addr->city ? "{$addr->postal_code} {$addr->city}" : $addr->city,
                $addr->province,
                $addr->country,
            ])->filter()->join(', ');
        };

        /* 2️⃣ serializza cliente “standard” */
        $cust = $order->customer ? [
            'id'               => $order->customer->id,
            'company'          => $order->customer->company,
            'email'            => $order->customer->email,
            'vat_number'       => $order->customer->vat_number,
            'tax_code'         => $order->customer->tax_code,
            'shipping_address' => $fmt($order->customer->shippingAddress),
        ] : null;

        /* 3️⃣ serializza cliente occasionale */
        $occ  = $order->occasionalCustomer ? [
            'id'               => $order->occasionalCustomer->id,
            'company'          => $order->occasionalCustomer->company,
            'email'            => $order->occasionalCustomer->email,
            'vat_number'       => $order->occasionalCustomer->vat_number,
            'tax_code'         => $order->occasionalCustomer->tax_code,
            'shipping_address' => $fmt($order->occasionalCustomer),   // stesso record
        ] : null;

        Log::debug('OrderCustomer@edit - lines for order', [
            'order_id' => $order->id,
            'lines'    => $order->items,
        ]);

        /* 4️⃣ serializza righe:
        *    - price = unit_price NETTO salvato
        *    - discount = array token ("N%" | "N") → se nel DB è TEXT JSON, normalizzo
        *    - variabili con null-safety (->variable?->…)
        */
        $lines = $order->items->map(function ($it) {
            // Normalizza tokens sconto qualunque sia il cast del model
            $raw = $it->discount;
            if (is_array($raw)) {
                $tokens = array_values(array_map('strval', $raw));
            } elseif (is_string($raw) && $raw !== '') {
                $decoded = json_decode($raw, true);
                $tokens  = is_array($decoded) ? array_values(array_map('strval', $decoded)) : [];
            } else {
                $tokens = [];
            }

            return [
                'product_id'  => $it->product_id,
                'sku'         => $it->product?->sku,
                'name'        => $it->product?->name,
                'quantity'    => $it->quantity,
                'price'       => $it->unit_price,              // NETTO congelato
                'discount'    => $tokens,                      // ← necessario per editLine

                // Variabili (null-safe)
                'fabric_id'   => $it->variable?->fabric_id,
                'color_id'    => $it->variable?->color_id,
                'fabric_name' => $it->variable?->fabric?->name,
                'color_name'  => $it->variable?->color?->name,
                'color_notes' => $it->variable?->color_notes,
            ];
        })->values();

        /* 5️⃣ risposta JSON per fetchOrder */
        return response()->json([
            'id'               => $order->id,
            'number'           => $order->number,
            'order_number_id'  => $order->order_number_id,
            'delivery_date'    => $order->delivery_date?->format('Y-m-d'),
            'customer'         => $cust,
            'occ_customer'     => $occ,
            'shipping_address' => $order->shipping_address,
            'shipping_zone'    => $order->shipping_zone ?? null,
            'reference'        => $order->reference ?? null,
            // NEW: campi header aggiunti/attesi dalla UI
            'hash_flag'        => (bool) ($order->hash_flag ?? false),
            'note'             => $order->note ?? null,
            'packages'         => $order->packages ?? null,

            'lines'            => $lines,
        ]);
    }

    /**
     * Modifica un ordine esistente.
     *
     * Regole:
     * - OCCASIONALE: flusso ATTUALE (verifica → prenota → PO sul delta), ammesso solo ai ruoli autorizzati (Policy).
     * - STANDARD confermato (status=1): Opzione A (conservativa) → dopo l'update NESSUN ricalcolo automatico
     *   (il CTA “Ricalcola approvvigionamenti” lancerà un job dedicato).
     * - STANDARD non confermato (status=0): comportamento identico allo STORE → nuovo token + invio mail
     *   (testo: “sostituisce e annulla il precedente”), e NESSUNA azione su riserve/PO ora.
     */
    public function update(Request $request, Order $order): JsonResponse
    {
        // Autorizzazione (Policy aggiornata negli step precedenti)
        //$this->authorize('update', $order);

        /*──────── VALIDAZIONE ────────*/
        $data = $request->validate([
            'delivery_date'      => ['required','date'],

            // header extra
            'hash_flag'          => ['sometimes','boolean'],
            'note'               => ['nullable','string'],
            'packages'           => ['nullable','integer','min:1'],
            'shipping_zone'       => ['nullable', 'string', 'max:255'],
            'reference'          => ['nullable', 'string', 'max:255'],
            // righe
            'lines'              => ['required','array','min:1'],
            'lines.*.product_id' => ['required','integer', Rule::exists('products','id')],
            'lines.*.quantity'   => ['required','numeric','min:0.01'],

            // prezzo opzionale (override finale NETTO)
            'lines.*.price'      => ['nullable','numeric','min:0'],

            // variabili
            'lines.*.fabric_id'  => ['nullable','integer', Rule::exists('fabrics','id')],
            'lines.*.color_id'   => ['nullable','integer', Rule::exists('colors','id')],
            'lines.*.color_notes' => ['nullable', 'string'],

            // sconti multi-token (array di stringhe "N%" | "N")
            'lines.*.discount'   => ['nullable','array'],
            'lines.*.discount.*' => ['nullable','string'],
        ]);

        $customerId  = $order->customer_id; // guest → null
        $delivery    = Carbon::parse($data['delivery_date']);
        $canOverride = $request->user()->can('orders.customer.update');

        /**
         * Aggiorna i campi header dell'ordine.
         *
         * I campi testuali opzionali vengono normalizzati:
         * - stringa vuota => null
         */
        $order->fill([
            ...(array_key_exists('hash_flag', $data) ? [
                'hash_flag' => (bool) $data['hash_flag']
            ] : []),

            ...(array_key_exists('note', $data) ? [
                'note' => $data['note']
            ] : []),

            ...(array_key_exists('shipping_zone', $data) ? [
                'shipping_zone' => ($data['shipping_zone'] !== null && trim((string) $data['shipping_zone']) !== '')
                    ? trim((string) $data['shipping_zone'])
                    : null
            ] : []),

            ...(array_key_exists('reference', $data) ? [
                'reference' => ($data['reference'] !== null && trim((string) $data['reference']) !== '')
                    ? trim((string) $data['reference'])
                    : null
            ] : []),

            ...(array_key_exists('packages', $data) ? [
                'packages' => $data['packages']
            ] : []),
        ]);

        $order->save();

        /*──────── Helper sconti ────────*/
        $normalizeDiscountTokens = function ($raw): array {
            if (is_string($raw) && $raw !== '') {
                $decoded = json_decode($raw, true);
                $raw = is_array($decoded) ? $decoded : [$raw];
            }
            if (!is_array($raw)) return [];
            $out = [];
            foreach ($raw as $tok) {
                if ($tok === null || $tok === '') continue;
                $s = Str::of((string)$tok)->trim();
                if ($s->endsWith('%')) {
                    $n = (float)str_replace('%','',(string)$s);
                    $out[] = rtrim(rtrim(number_format($n, 4, '.', ''), '0'), '.') . '%';
                } else {
                    $n = (float)$s;
                    $out[] = rtrim(rtrim(number_format($n, 4, '.', ''), '0'), '.');
                }
            }
            return $out;
        };

        $applyDiscounts = function (float $unitGross, array $tokens): float {
            $net = $unitGross;
            foreach ($tokens as $t) {
                if (str_ends_with($t, '%')) {
                    $p = (float)str_replace('%','',$t);
                    $net -= $net * ($p / 100);
                } else {
                    $net -= (float)$t;
                }
            }
            return max(0.0, $net);
        };

        /*──────── Helper sovrapprezzi (coerenti con store) ────────*/
        $normType = function (?string $t): string {
            $t = strtolower((string)$t);
            return in_array($t, ['percent','percentage','%'], true) ? 'percent' : 'fixed';
        };
        $appliedAmount = function (float $base, string $type, ?float $value, float &$fixedSum, float &$percentSum): float {
            $v = (float)($value ?? 0);
            if ($type === 'percent') { $percentSum += $v; return $base * ($v / 100); }
            $fixedSum += $v; return $v;
        };
        $fabricMeta = function (Product $product, ?int $fabricId): array {
            if (!$fabricId) return ['type'=>null,'value'=>null];
            $pf = $product->fabrics()->where('fabrics.id', $fabricId)->first();
            $type  = $pf?->pivot?->surcharge_type;
            $value = $pf?->pivot?->surcharge_value;
            if ($type === null || $value === null) {
                $fab   = Fabric::select('surcharge_type','surcharge_value')->find($fabricId);
                $type  = $fab?->surcharge_type;
                $value = $fab?->surcharge_value;
            }
            return ['type'=>$type, 'value'=>$value];
        };
        $colorMeta = function (Product $product, ?int $colorId): array {
            if (!$colorId) return ['type'=>null,'value'=>null];
            $pc = $product->colors()->where('colors.id', $colorId)->first();
            $type  = $pc?->pivot?->surcharge_type;
            $value = $pc?->pivot?->surcharge_value;
            if ($type === null || $value === null) {
                $col   = Color::select('surcharge_type','surcharge_value')->find($colorId);
                $type  = $col?->surcharge_type;
                $value = $col?->surcharge_value;
            }
            return ['type'=>$type, 'value'=>$value];
        };
        $resolveResolvedComponentId = function (Product $product, ?int $fabricId, ?int $colorId): ?int {
            $placeholder = $product->variableComponent();    // riga BOM “slot”
            if (! $placeholder) return null;
            $qid = Component::query()
                ->where('category_id', $placeholder->category_id)
                ->when($fabricId, fn($q)=>$q->where('fabric_id', $fabricId))
                ->when($colorId,  fn($q)=>$q->where('color_id',  $colorId))
                ->value('id');
            return $qid ?: $placeholder->id;
        };

        /*──────── PREPARAZIONE RIGHE (prezzo + sconti + variabili + meta) ────────*/
        $prepared = collect($data['lines'])->map(function(array $l) use (
            $customerId, $delivery, $canOverride,
            $normalizeDiscountTokens, $applyDiscounts,
            $normType, $appliedAmount, $fabricMeta, $colorMeta, $resolveResolvedComponentId
        ) {
            $productId = (int) $l['product_id'];
            $qty       = (float) $l['quantity'];
            $fabricId  = array_key_exists('fabric_id', $l) && $l['fabric_id'] !== null ? (int) $l['fabric_id'] : null;
            $colorId   = array_key_exists('color_id',  $l) && $l['color_id']  !== null ? (int) $l['color_id']  : null;
            $tokens    = $normalizeDiscountTokens($l['discount'] ?? []);
            $colorNotes = array_key_exists('color_notes', $l) ? trim((string) $l['color_notes']) : null;
            if ($colorNotes === '') {
                $colorNotes = null;
            }

            /** @var \App\Models\Product $product */
            $product   = Product::findOrFail($productId);

            // whitelist sicurezza
            if ($fabricId !== null && ! in_array($fabricId, $product->fabricIds(), true)) {
                abort(response()->json(['message' => "Il tessuto selezionato non è consentito per il prodotto #{$productId}."], 422));
            }
            if ($colorId !== null && ! in_array($colorId, $product->colorIds(), true)) {
                abort(response()->json(['message' => "Il colore selezionato non è consentito per il prodotto #{$productId}."], 422));
            }

            // Breakdown prezzo da modello (lordo variabili)
            $fb = $product->pricingBreakdown($fabricId, $colorId, $customerId, $delivery->toDateString());
            if ($fb === null) {
                abort(response()->json(['message' => 'Prezzo non disponibile per uno dei prodotti nella data indicata.'], 422));
            }
            $unitGross = (float) $fb['unit_price'];

            // Override prezzo: se consentito e passato, consideralo NETTO finale; altrimenti applica sconti
            $unitNet = ($canOverride && array_key_exists('price', $l) && $l['price'] !== null && $l['price'] !== '')
                ? (float) $l['price']
                : $applyDiscounts($unitGross, $tokens);

            // Meta sovrapprezzi applicati (solo diagnostica)
            $base = (float) ($fb['base_price'] ?? 0.0);
            $fixedSum   = 0.0;
            $percentSum = 0.0;

            $fm = $fabricMeta($product, $fabricId);
            $cm = $colorMeta($product,  $colorId);

            $fabricAmt = 0.0; $colorAmt = 0.0;
            if ($fm['type'] !== null) {
                $fabricType = $normType($fm['type']);
                $fabricAmt  = $appliedAmount($base, $fabricType, (float)$fm['value'], $fixedSum, $percentSum);
            }
            if ($cm['type'] !== null) {
                $colorType  = $normType($cm['type']);
                $colorAmt   = $appliedAmount($base, $colorType, (float)$cm['value'], $fixedSum, $percentSum);
            }
            $surchargeTotalApplied = $fabricAmt + $colorAmt;

            // componente effettivo risolto (slot variabile BOM)
            $resolvedComponentId = $resolveResolvedComponentId($product, $fabricId, $colorId);

            return [
                // chiave logica per diff (prodotto+variabili)
                'key'        => sprintf('%d:%d:%d', $productId, $fabricId ?? 0, $colorId ?? 0),

                // dati riga
                'product_id' => $productId,
                'quantity'   => $qty,
                'price'      => (string) $unitNet,  // NETTO post sconti (congelato)
                'discount'   => $tokens,            // ← salva i token

                // variabili
                'fabric_id'  => $fabricId,
                'color_id'   => $colorId,
                'resolved_component_id'     => $resolvedComponentId,
                'color_notes' => $colorNotes,
                // meta sovrapprezzi (diagnostica)
                'surcharge_fixed_applied'   => $fixedSum,
                'surcharge_percent_applied' => $percentSum,
                'surcharge_total_applied'   => $surchargeTotalApplied,
            ];
        })->values();

        /*──────── BUSINESS LOGIC: upsert righe (+ eventuali materiali/PO gestiti dal Service) ────────*/
        $svc = app(OrderUpdateService::class);

        $result = $svc->handle(
            $order,
            $prepared,                        // include variabili + sconti + applied
            $delivery->toDateString(),
            $request->user()
        );

        // ── Branching post-update per STANDARD ─────────────────────────────────────
        if (is_null($order->occasional_customer_id)) {
            if ((int) $order->status === 0) {
                // STANDARD NON confermato → come store: rigenera token + invia mail (nessun materiale/PO adesso)
                $order->confirm_token             = (string) Str::uuid();
                $order->reason                    = null; // reset eventuale motivo rifiuto
                $order->confirmation_requested_at = now();
                $order->confirm_locale            = app()->getLocale();
                $order->save();

                // Invia mail di conferma con token (code + locale)
                Mail::to($order->customer->email)->queue(new OrderConfirmationRequestMail(
                    order: $order,
                    replacePrevious: $isUpdate ?? false // true nell'update standard non confermato
                ));

                return response()->json([
                    'order_id'               => $order->id,
                    'message'                => 'Richiesta conferma inviata al cliente (sostituisce e annulla la precedente).',
                    'awaiting_confirmation'  => true,
                    'result'                 => $result,
                ]);
            }

            // STANDARD confermato → Opzione A: nessun ricalcolo automatico
            return response()->json([
                'order_id'         => $order->id,
                'message'          => 'Ordine aggiornato.',
                'recalc_available' => true,   // il FE può mostrare il CTA “Ricalcola approvvigionamenti”
                'result'           => $result,
            ]);
        }

        // ── Occasionali: flusso attuale eseguito dal Service ───────────────────────
        return response()->json([
            'order_id' => $order->id,
            'message'  => 'Ordine occasionale aggiornato.',
            'result'   => $result,
        ]);
    }

    /**
     * Ricalcola le prenotazioni materiali e crea nuovi PO se servono.
     *
     * Regole:
     * - SOLO per ordini STANDARD confermati (status=1).
     * - Se la consegna è entro 30 giorni dalla conferma, si possono creare nuovi PO.
     * - Se la consegna è oltre 30 giorni dalla conferma, NON si creano nuovi PO.
     * - Il ricalcolo integra le prenotazioni esistenti (su incoming libero e stock fisico),
     *   ma NON rilascia prenotazioni già fatte (sia su incoming che su stock).
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Order  $order
     * @return \Illuminate\Http\JsonResponse
     */
    public function recalcProcurement(Request $request, Order $order): JsonResponse
    {
        // 1) Solo STANDARD confermati
        if (!is_null($order->occasional_customer_id)) {
            return response()->json(['message' => 'Azione non prevista per ordini occasionali.'], 422);
        }
        if ((int) $order->status !== 1) {
            return response()->json(['message' => 'Disponibile solo per ordini standard confermati.'], 422);
        }

        // 2) Calcolo regola < 30 giorni per la CREAZIONE di nuovi PO
        $confirmedAt = Carbon::parse($order->confirmed_at);
        $deliveryAt  = Carbon::parse($order->delivery_date);
        $daysDiff    = $confirmedAt->diffInDays($deliveryAt, false); // negativo se consegna < conferma
        $eligibleForPo = $daysDiff >= 0 && $daysDiff < 30;

        // 3) Snapshot righe → array {product_id, quantity, fabric_id, color_id}
        $order->load(['items.variable','items.product']);
        $returnsSvc = app(ReturnedProductReservationService::class);

        $returnsCoverageByKey = [];
        $makeKey = fn($pid,$fid,$cid) => sprintf('%d:%d:%d', $pid, $fid ?? 0, $cid ?? 0);

        foreach ($order->items as $it) {
            $res = $returnsSvc->reserveForItem($it, (float)$it->quantity, $request->user());
            $covered = (float) ($res['reserved'] ?? 0);
            if ($covered > 0) {
                $fid = $it->variable?->fabric_id;
                $cid = $it->variable?->color_id;
                $k   = $makeKey($it->product_id, $fid, $cid);
                $returnsCoverageByKey[$k] = ($returnsCoverageByKey[$k] ?? 0) + $covered;
            }
        }
        // ⬇️ ADATTA le righe usate per la disponibilità: sottrai la qty coperta coi resi
        // base lines dall'ordine
        $baseLines = $order->items->map(function ($it) {
            return [
                'product_id' => (int) $it->product_id,
                'quantity'   => (float) $it->quantity,
                'fabric_id'  => $it->variable?->fabric_id,
                'color_id'   => $it->variable?->color_id,
            ];
        })->values();

        // adatta quantità in base alla copertura resi
        $usedLines = $baseLines
            ->map(function ($l) use (&$returnsCoverageByKey, $makeKey) {
                $pid = (int) $l['product_id'];
                $fid = array_key_exists('fabric_id',$l) ? $l['fabric_id'] : null;
                $cid = array_key_exists('color_id', $l) ? $l['color_id']  : null;
                $k   = $makeKey($pid, $fid, $cid);

                $qty     = (float) $l['quantity'];
                $covered = (float) ($returnsCoverageByKey[$k] ?? 0);

                if ($covered <= 0) {
                    return [
                        'product_id' => $pid,
                        'quantity'   => $qty,
                        'fabric_id'  => $fid,
                        'color_id'   => $cid,
                    ];
                }

                // applica copertura, consumando la mappa (in caso di più righe uguali)
                $take = min($qty, $covered);
                $returnsCoverageByKey[$k] = max($covered - $take, 0);

                $left = $qty - $take;
                if ($left <= 1e-6) {
                    return null; // riga interamente coperta da resi → NON entra in BOM
                }

                return [
                    'product_id' => $pid,
                    'quantity'   => $left,
                    'fabric_id'  => $fid,
                    'color_id'   => $cid,
                ];
            })
            ->filter()   // rimuovi null (righe totalmente coperte da reso)
            ->values()
            ->all();

        // 4) TX: integrazioni su incoming libero + prenotazioni STOCK fisico
        DB::transaction(function () use ($order, $usedLines, $deliveryAt) {

            // 4.a) Fabbisogno per componente
            $componentsNeeded = InventoryServiceExtensions::explodeBomArray($usedLines);

            // 4.b) Prenota quantità libere su PO esistenti (nessuna riduzione: solo integrazioni)
            InventoryServiceExtensions::reserveFreeIncoming(
                $order,
                $componentsNeeded,
                $deliveryAt
            );

            // 4.c) Verifica copertura aggiornata (tenendo conto anche delle mie incoming reservation)
            $invResult = InventoryService::forDelivery($order->delivery_date, $order->id)->check($usedLines);

            // 4.d) Prenota da STOCK fisico quanto possibile (solo integrazioni; nessun rilascio)
            foreach ($invResult->shortage as $row) {
                $missing   = (float) $row['shortage'];   // fabbisogno ancora scoperto
                $fromStock = (float) min($row['available'], $missing);

                if ($fromStock > 0) {
                    // FIFO sui lotti del componente, con lock per concorrenza
                    $levels = StockLevel::query()
                        ->where('component_id', (int) $row['component_id'])
                        ->orderBy('created_at')
                        ->lockForUpdate()
                        ->get();

                    $needLeft = $fromStock;

                    foreach ($levels as $sl) {
                        if ($needLeft <= 0) break;

                        $already = (float) StockReservation::query()
                            ->where('stock_level_id', $sl->id)
                            ->sum('quantity');

                        $free = (float) $sl->quantity - $already;
                        if ($free <= 0) continue;

                        $take = min($free, $needLeft);
                        if ($take <= 0) continue;

                        StockReservation::create([
                            'stock_level_id' => $sl->id,
                            'order_id'       => $order->id,
                            'quantity'       => $take,
                        ]);

                        StockMovement::create([
                            'stock_level_id' => $sl->id,
                            'type'           => 'reserve',
                            'quantity'       => $take,
                            'note'           => "Prenotazione stock per OC #{$order->id} (CTA ricalcolo)",
                        ]);

                        $needLeft -= $take;
                    }
                }
            }
        });

        // 5) Verifica finale e creazione PO (SOLO se < 30 giorni)
        $poNumbers = [];
        $invFinal  = InventoryService::forDelivery($order->delivery_date, $order->id)->check($usedLines);

        if (!$invFinal->ok && $eligibleForPo) {
            $shortCol  = ProcurementService::buildShortageCollection($invFinal->shortage);
            $proc      = ProcurementService::fromShortage($shortCol, $order->id);
            $poNumbers = $proc['po_numbers']->all();
        }

        return response()->json([
            'recalc_performed' => true,
            'eligible_for_po'  => $eligibleForPo,
            'po_numbers'       => $poNumbers,
            'message'          => $eligibleForPo
                ? (count($poNumbers) ? 'Ricalcolo completato: creati nuovi PO.' : 'Ricalcolo completato: nessun nuovo PO necessario.')
                : 'Ricalcolo completato: consegna non entro 30 giorni dalla conferma, nessun nuovo PO creato.',
        ]);
    }

    /**
     * Elimina un ordine cliente e restituisce i numeri dei PO generati.
     */
    public function destroy(Order $order)
    {
        // già protetto dal middleware permission:orders.customer.delete

        /* ❗ eventuale business-rule: non eliminare se spedito / fatturato
        if ($order->shipped_at || $order->invoiced_at) {
            return back()->with('error',
                "Impossibile eliminare: l’ordine è già evaso / fatturato.");
        }
        */

        try {
            $poNumbers = app(OrderDeleteService::class)->handle($order);

            $msg = "Ordine #{$order->orderNumber->number} eliminato con successo.";
            if ($poNumbers->isNotEmpty()) {
                $msg .= ' Restano aperti gli ordini fornitore generati con la creazione dell\'ordine: '.
                        $poNumbers->implode(', ');
            }

            return back()->with('success', $msg);

        } catch (\Throwable $e) {
            Log::error('OC delete failed', [
                'order_id' => $order->id,
                'error'    => $e->getMessage()
            ]);

            return back()->with('error',
                'Errore interno: ordine non eliminato.');
        }
    }

    /**
     * Conferma manualmente un ordine STANDARD (interno).
     *
     * Requisito: deve seguire lo stesso percorso della conferma via link.
     * Strategia:
     * - Se esiste un confirm_token, prova a chiamare direttamente
     *   OrderPublicConfirmationController::confirm() (stesso identico flusso).
     * - Se fallisce (token scaduto/non valido/altro), esegue un fallback "forzato"
     *   che porta comunque l'ordine nello stato CONFERMATO (status=1).
     *
     * @param  Request  $request
     * @param  Order    $order
     * @return RedirectResponse
     */
    public function confirmManual(Request $request, Order $order): RedirectResponse
    {
        /*──────────────── AUTORIZZAZIONE ────────────────*/
        // La rotta è già protetta dal middleware permission:orders.customer.update,
        // ma facciamo comunque un guard di sicurezza lato controller.
        abort_unless($request->user()?->can('orders.customer.update'), 403);

        /*──────────────── VALIDAZIONI BUSINESS ────────────────*/
        // Solo ordini STANDARD (gli occasionali sono già auto-confermati nel tuo flusso).
        if (!is_null($order->occasional_customer_id)) {
            return back()->with('error', 'Conferma manuale non prevista per ordini occasionali.');
        }

        // Idempotenza: se già confermato, non facciamo nulla.
        if ((int) $order->status === 1) {
            return back()->with('success', 'Ordine già confermato.');
        }

        /*──────────────── 1) TENTATIVO: stesso flusso della conferma via link ────────────────*/
        // Se abbiamo un token, chiamiamo direttamente lo stesso controller usato dal link pubblico.
        // Questo evita duplicazioni e garantisce “stesso percorso”.
        if (!empty($order->confirm_token)) {
            try {
                // app()->call gestisce automaticamente l’ordine dei parametri nel metodo confirm()
                // (Request + token oppure token + Request).
                app()->call([OrderPublicConfirmationController::class, 'confirm'], [
                    'request' => $request,
                    'token'   => $order->confirm_token,
                ]);

                // Ricarica ordine per verificare l'esito reale della conferma.
                $order->refresh();

                if ((int) $order->status === 1) {
                    return back()->with('success', 'Ordine confermato manualmente.');
                }

                // Se non è stato confermato, continuiamo con fallback.
                Log::warning('confirmManual: chiamata al flusso pubblico eseguita ma ordine non risulta confermato', [
                    'order_id' => $order->id,
                    'token'    => $order->confirm_token,
                ]);

            } catch (\Throwable $e) {
                // Se il token è scaduto/non valido o il controller lancia abort/exception,
                // passiamo al fallback.
                Log::warning('confirmManual: impossibile usare il flusso pubblico, fallback forzato', [
                    'order_id' => $order->id,
                    'token'    => $order->confirm_token,
                    'error'    => $e->getMessage(),
                ]);
            }
        }

        /*──────────────── 2) FALLBACK: conferma forzata (token scaduto o assente) ────────────────*/
        DB::transaction(function () use ($order, $request) {
            /** @var Order $locked */
            $locked = Order::query()
                ->whereKey($order->id)
                ->lockForUpdate()
                ->firstOrFail();

            // Idempotenza anche sotto lock (concorrenza: click link + conferma manuale).
            if ((int) $locked->status === 1) {
                return;
            }

            // Porta l'ordine in stato confermato.
            $locked->status       = 1;
            $locked->confirmed_at = now();
            $locked->reason       = null;

            // Se vuoi rendere il link non più utilizzabile, azzera il token (solo se colonna esiste).
            if (Schema::hasColumn('orders', 'confirm_token')) {
                $locked->confirm_token = null;
            }

            // (Opzionale) Tracciamento interno: chi ha confermato manualmente.
            if (Schema::hasColumn('orders', 'confirmed_by_user_id')) {
                $locked->confirmed_by_user_id = (int) $request->user()->id;
            }
            if (Schema::hasColumn('orders', 'confirmed_via')) {
                $locked->confirmed_via = 'manual';
            }

            $locked->save();
        });

        return back()->with('success', 'Ordine confermato manualmente.');
    }
}
