<?php

namespace App\Http\Controllers;

use App\Models\ComponentCategory;
use App\Enums\ProductionPhase;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class ComponentCategoryController extends Controller
{
    /**
     * Lista categorie con sorting e filtering su code e name.
     *
     * @param Request $request
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        // Leggi parametri
        $sort = $request->input('sort', 'id');  // default: id
        $dir  = $request->input('dir', 'asc') === 'desc' ? 'desc' : 'asc';

        // Filtri
        $filters       = $request->input('filter', []);
        $filterCode    = $filters['code']  ?? null;
        $filterName    = $filters['name']  ?? null;
        $filterPhase   = $filters['phase'] ?? null;

        /* se arriva una LABEL (struttura, taglio, …) => convertila in value */
        if ($filterPhase && ! is_numeric($filterPhase)) {
            $filterPhaseEnum = collect(ProductionPhase::cases())
                ->firstWhere(fn ($c) =>
                    str_contains(
                        str($c->label())->lower(),       // label “Struttura”
                        str($filterPhase)->lower()       // testo inserito
                    )
                );
            $filterPhase = $filterPhaseEnum?->value;     // null → niente match
        }

        /* ---------- query ---------- */
        $query = ComponentCategory::query()
            ->with('phaseLinks')          // evita N+1 per la colonna in tabella
            ->when($filters['code']  ?? null,
                fn ($q,$v) => $q->where('code', 'like', "%$v%"))
            ->when($filters['name']  ?? null,
                fn ($q,$v) => $q->where('name', 'like', "%$v%"))
            ->when($filterPhase,
                fn ($q,$v) => $q->whereHas('phaseLinks',
                            fn ($q) => $q->where('phase', $v)));

        /* ordinamento ---------------------------------------------------- */
        if ($sort === 'phase') {
            // ordina per valore numerico della “prima” fase
            $query->leftJoin('component_category_phase as ccp','ccp.category_id','=','component_categories.id')
                ->select('component_categories.*')
                ->groupBy('component_categories.id')
                ->orderByRaw('MIN(ccp.phase) ' . $dir);
        } elseif (in_array($sort, ['id','code','name'])) {
            $query->orderBy($sort, $dir);
        } else {
            $query->orderBy('id');
        }

        // Paginazione con preservazione della query-string
        $categories = $query
            ->paginate(15)
            ->appends($request->query());

        // Passaggio dati alla view
        return view('pages.master-data.index-component_categories', [
            'categories' => $categories,
            'sort'       => $sort,
            'dir'        => $dir,
            'filters'    => [
                'code' => $filterCode,
                'name' => $filterName,
                'phase' => $filterPhase, 
            ],
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Salva una nuova categoria.
     * 
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(Request $request)
    {
        // Normalizza il codice in maiuscolo
        $request->merge([
            'code' => strtoupper($request->input('code')),
        ]);

        // Messaggi personalizzati
        $messages = [
            'code.required' => 'Il codice è obbligatorio.',
            'code.string'   => 'Il codice deve essere una stringa.',
            'code.max'      => 'Il codice non può superare i 5 caratteri.',
            'code.unique'   => 'Questo codice è già in uso.',
            'name.required' => 'Il nome è obbligatorio.',
            'name.string'   => 'Il nome deve essere una stringa.',
            'name.max'      => 'Il nome non può superare i 100 caratteri.',
            'description.string' => 'La descrizione deve essere una stringa.',
            'phases.array' => 'Le fasi devono essere un array.',
            'phases.*.integer' => 'Ogni fase deve essere un numero intero.',
            'phases.*.between' => 'Ogni fase deve essere compresa tra 1 e 5.',
        ];

        // Validazione dei dati in ingresso
        $validator = Validator::make($request->all(), [
            'code'        => ['required','string','max:5','unique:component_categories,code'],
            'name'        => ['required','string','max:100'],
            'description' => ['nullable','string'],
            'phases'      => ['nullable','array'],
            'phases.*'    => ['integer', Rule::in([ProductionPhase::ASSEMBLY->value, ProductionPhase::FINISHING->value])],
        ], $messages);

        // Se la validazione fallisce, log degli errori e ritorno alla form
        // con gli errori e i dati inseriti
        // Questo evita di perdere i dati inseriti dall'utente
        // e permette di correggere gli errori senza dover reinserire tutto
        if ($validator->fails()) {
            // Log degli errori di validazione
            Log::warning('Validation errors in ComponentCategoryController@store', $validator->errors()->toArray());
            return back()->withErrors($validator)->withInput();
        }

        // Se la validazione ha successo, procediamo con la creazione
        // della nuova categoria
        $data = $validator->validated();

        // Iniziamo una transazione per garantire l'integrità dei dati
        try {
            // Iniziamo la transazione
            DB::beginTransaction();

            // Creiamo la nuova categoria con i dati validati
            $cat = ComponentCategory::create($data);

            if ($request->filled('phases')) {
                $cat->syncPhases($request->input('phases', []));
            }

            // Commit della transazione
            DB::commit();

            // Redirect alla lista delle categorie con un messaggio di successo
            return redirect()
                ->route('categories.index')
                ->with('success', 'Categoria creata con successo.');
        } catch (\Throwable $e) {
            // In caso di errore, rollback della transazione
            DB::rollBack();

            // Log dell'errore con il messaggio dell'eccezione
            Log::error('Error in ComponentCategoryController@store', ['exception'=>$e->getMessage()]);

            // Redirect alla form con un messaggio di errore
            return back()->withInput()->with('error','Errore durante la creazione. Controlla i log.');
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(ComponentCategory $category)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(ComponentCategory $category)
    {
        //
    }

    /**
     * Aggiorna una categoria esistente.
     * 
     * @param Request $request
     * @param ComponentCategory $componentCategory
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(Request $request, ComponentCategory $category)
    {
        Log::debug('ComponentCategoryController@update', [
            'id' => $category->id,
            'data' => $request->all(),
        ]);

        // Normalizza il codice in maiuscolo
        $request->merge([
            'code' => strtoupper($request->input('code')),
        ]);

        // Messaggi personalizzati
        $messages = [
            'code.required' => 'Il codice è obbligatorio.',
            'code.string'   => 'Il codice deve essere una stringa.',
            'code.max'      => 'Il codice non può superare i 5 caratteri.',
            'code.unique'   => 'Questo codice è già in uso per un’altra categoria.',
            'name.required' => 'Il nome è obbligatorio.',
            'name.string'   => 'Il nome deve essere una stringa.',
            'name.max'      => 'Il nome non può superare i 100 caratteri.',
            'description.string' => 'La descrizione deve essere una stringa.',
            'phases.array' => 'Le fasi devono essere un array.',
            'phases.*.integer' => 'Ogni fase deve essere un numero intero.',
            'phases.*.between' => 'Ogni fase deve essere compresa tra 1 e 5.',
        ];

        // Validazione
        $validator = Validator::make($request->all(), [
            'code'        => [
                'required','string','max:5',
                Rule::unique('component_categories','code')->ignore($category->id),
            ],
            'name'        => ['required','string','max:100'],
            'description' => ['nullable','string'],
            'phases'      => ['nullable','array'],
            'phases.*'    => ['integer', Rule::in([ProductionPhase::ASSEMBLY->value, ProductionPhase::FINISHING->value])],
        ], $messages);

        // Se la validazione fallisce, log degli errori e ritorno alla form
        // con gli errori e i dati inseriti
        // Questo evita di perdere i dati inseriti dall'utente
        // e permette di correggere gli errori senza dover reinserire tutto
        if ($validator->fails()) {
            Log::warning('Validation errors in ComponentCategoryController@update', $validator->errors()->toArray());
            return back()->withErrors($validator)->withInput();
        }

        // Se la validazione ha successo, procediamo con l'aggiornamento
        // dei dati della categoria
        $data = $validator->validated();

        // Iniziamo una transazione per garantire l'integrità dei dati
        // in caso di errori durante l'aggiornamento
        try {
            // Iniziamo la transazione
            DB::beginTransaction();

            // Aggiorniamo la categoria con i dati validati
            $category->update($data);
            $category->syncPhases($request->input('phases', []));

            // Commit della transazione
            DB::commit();

            // Redirect alla lista delle categorie con un messaggio di successo
            return redirect()
                ->route('categories.index')
                ->with('success', 'Categoria aggiornata con successo.');
        } catch (\Throwable $e) { 
            // In caso di errore, rollback della transazione
            DB::rollBack();

            // Log dell'errore con il messaggio dell'eccezione
            Log::error('Error in ComponentCategoryController@update', ['exception'=>$e->getMessage()]);

            // Redirect alla form con un messaggio di errore
            return back()->withInput()->with('error','Errore durante l\'aggiornamento. Controlla i log.');
        }
    }

    /**
     * Elimina una categoria.
     * 
     * @param ComponentCategory $category
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroy(ComponentCategory $category)
    {
        // Verifica se la categoria ha componenti associati
        if ($category->components()->exists()) {
            return back()->with('error', 'Impossibile eliminare la categoria perché contiene dei componenti.');
        }

        // Iniziamo una transazione per garantire l'integrità dei dati
        try {
            // Iniziamo la transazione
            DB::beginTransaction();

            // Elimina la categoria
            $category->delete();

            // Commit della transazione
            DB::commit();

            // Redirect alla lista delle categorie con un messaggio di successo
            return redirect()
                ->route('categories.index')
                ->with('success', 'Categoria eliminata con successo.');
        } catch (\Throwable $e) {
            // In caso di errore, rollback della transazione
            DB::rollBack();

            // Log dell'errore con il messaggio dell'eccezione
            Log::error('Error in ComponentCategoryController@destroy', ['exception'=>$e->getMessage()]);

            // Redirect alla lista con un messaggio di errore
            return back()->with('error','Errore durante l\'eliminazione. Controlla i log.');
        }
    }
}
