<?php

namespace App\Services;

use App\Models\Product;
use App\Models\StockLevel;
use App\Models\Component;
use App\Services\Traits\InventoryServiceExtensions;
use Illuminate\Support\Collection;
use Illuminate\Support\Carbon;
use Carbon\CarbonImmutable;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;

/**
 * InventoryService
 * ---------------------------------------------------------------------
 * Calcola la disponibilità di componenti per un Ordine Cliente
 * tenendo conto di:
 *   • stock fisico               (StockLevel)
 *   • prenotazioni altri OC      (stock_reservations)
 *   • quantità in arrivo         (order_items di PO supplier)
 *   • prenotazioni altri OC sui PO (po_reservations)
 *
 * Con forDelivery($date, ?$excludeOcId) puoi escludere dal conteggio
 * le prenotazioni dell'OC stesso (utile in fase di modifica).
 */
class InventoryService
{
    use InventoryServiceExtensions;

    protected CarbonImmutable $deliveryDate;
    protected ?int $excludeOrderId = null;  

    public function __construct(CarbonImmutable $deliveryDate, ?int $excludeOrderId)
    {
        $this->deliveryDate   = $deliveryDate;
        $this->excludeOrderId = $excludeOrderId;
    }

    /** Factory fluente */
    public static function forDelivery($date, ?int $excludeOrderId = null): self
    {
        return new self(
            Carbon::parse($date)->startOfDay()->toImmutable(),
            $excludeOrderId
        );
    }

    /**
     * @param  array<int, array{product_id:int, quantity:float}>  $orderLines
     * @return AvailabilityResult
     */
    public function check(array $orderLines): AvailabilityResult
    {
        Log::info('Inventory check – start', [
            'delivery_date' => $this->deliveryDate->toDateString(),
            'exclude_oc'    => $this->excludeOrderId,
            'lines'         => $orderLines,
        ]);
        /* 1. BOM → fabbisogno componenti */
        $required = $this->explodeBom($orderLines);
        Log::debug('BOM exploded', ['required' => $required]);

        /* 2. Stock fisico disponibile */
        $onHand   = StockLevel::query()
            ->whereIn('component_id', $required->keys())
            ->selectRaw('component_id, SUM(quantity) as qty')
            ->groupBy('component_id')
            ->pluck('qty', 'component_id');

        $reserved = $this->reservedStock($required->keys());

        $available = $onHand->map(fn ($qty,$cid) => $qty - ($reserved[$cid] ?? 0));

        Log::debug('Stock snapshot', [
            'on_hand'  => $onHand,
            'reserved' => $reserved,
            'avail'    => $available,
        ]);

        /* 3. In arrivo */
        $incoming      = $this->incomingPurchase($required->keys());
        $incomingMine  = $this->myIncoming($required->keys());

        Log::debug('Incoming snapshot', [
            'incoming'      => $incoming,
            'incoming_mine' => $incomingMine,
        ]);

        /* 4. Shortage */
        $shortage = collect();
        foreach ($required as $cid => $need) {
            $have = ($available[$cid] ?? 0) + ($incoming[$cid] ?? 0) + ($incomingMine[$cid] ?? 0);

            if ($need > $have + 1e-6) {
                /**
                 * Recupera il componente anche se archiviato.
                 *
                 * Serve per non bloccare disponibilità e riconciliazioni su ordini storici
                 * che puntano ancora a componenti non più attivi in anagrafica.
                 */
                $component = Component::withTrashed()->find((int) $cid);

                if (! $component) {
                    throw new \RuntimeException(
                        "Componente #{$cid} non trovato durante il calcolo disponibilità."
                    );
                }

                $shortage->push([
                    'component_id' => $cid,
                    'code'         => $component->code,
                    'description'  => $component->description,
                    'needed'       => $need,
                    'available'    => $available[$cid]    ?? 0,
                    'incoming'     => $incoming[$cid]     ?? 0,
                    'my_incoming'  => $incomingMine[$cid] ?? 0,
                    'shortage'     => round($need - $have, 4),
                ]);
            }
        }

        Log::info('Inventory check – end', [
            'delivery_date' => $this->deliveryDate->toDateString(),
            'exclude_oc'    => $this->excludeOrderId,
            'ok'            => $shortage->isEmpty(),
            'shortage_cnt'  => $shortage->count(),
            'shortage'      => $shortage,
        ]);

        return new AvailabilityResult($shortage->isEmpty(), $shortage);
    }

    /** esplode righe prodotto → fabbisogno componenti */
    public function explodeBom(array $orderLines): Collection
    {
        Log::debug('explodeBom – input', $orderLines);

        $needed = collect();

        foreach ($orderLines as $line) {
            $productId = (int) $line['product_id'];
            $qtyProd   = (float) $line['quantity'];

            /**
             * Recupera il prodotto anche se è stato archiviato tramite soft delete.
             *
             * Gli ordini già creati devono restare lavorabili anche se, in seguito,
             * il prodotto viene disattivato o archiviato dall'anagrafica.
             */
            $product = Product::withTrashed()
                ->with(['components' => function ($q) {
                    /**
                     * Manteniamo gli stessi pivot già usati dalla BOM.
                     *
                     * Nota:
                     * non cambiamo la struttura della relazione, ma permettiamo al prodotto
                     * storico di caricare comunque i componenti necessari all'esplosione BOM.
                     */
                    $q->withPivot(['quantity', 'is_variable', 'variable_slot']);
                }])
                ->find($productId);

            if (! $product) {
                /**
                 * Se il prodotto non esiste nemmeno con withTrashed(), allora non è solo
                 * archiviato: manca proprio dal database.
                 *
                 * In quel caso è corretto lanciare un errore più leggibile rispetto
                 * al generico ModelNotFoundException.
                 */
                throw new \RuntimeException(
                    "Prodotto #{$productId} non trovato durante l'esplosione BOM."
                );
            }

            // Variabili selezionate per la riga; fallback ai default del prodotto
            $fabricId = array_key_exists('fabric_id', $line) && $line['fabric_id'] !== null
                ? (int) $line['fabric_id']
                : ($product->defaultFabricId() ?? null);

            Log::debug('explodeBom – fabricId', [
                'product_id' => $productId,
                'input'      => $line,
                'default'    => $product->defaultFabricId(),
                'resolved'   => $fabricId,
            ]);

            $colorId  = array_key_exists('color_id',  $line) && $line['color_id'] !== null
                ? (int) $line['color_id']
                : ($product->defaultColorId() ?? null);

            Log::debug('explodeBom – colorId', [
                'product_id' => $productId, 
                'input'      => $line,
                'default'    => $product->defaultColorId(),
                'resolved'   => $colorId,
            ]);

            foreach ($product->components as $comp) {
                $pivotQty = (float) $comp->pivot->quantity;
                $compId   = (int) $comp->id;

                // Se è lo "slot variabile", mappalo al componente reale selezionato
                if ((int) ($comp->pivot->is_variable ?? 0) === 1) {

                    // Verifiche minime
                    if ($fabricId === null || $colorId === null) {
                        throw new \RuntimeException(
                            "Variabili mancanti per prodotto {$productId}: " .
                            "fabric_id={$fabricId}, color_id={$colorId}."
                        );
                    }

                    /**
                     * Cerca prima il componente reale attivo.
                     *
                     * Questo resta il comportamento preferito per ordini nuovi e dati puliti.
                     */
                    $real = Component::query()
                        ->where('is_active', 1)
                        ->whereNull('deleted_at')
                        ->where('category_id', $comp->category_id)
                        ->where('fabric_id', $fabricId)
                        ->where('color_id', $colorId)
                        ->orderBy('id')
                        ->first();

                    /**
                     * Fallback per ordini storici.
                     *
                     * Se il componente reale è stato archiviato dopo la creazione dell'ordine,
                     * la riconciliazione deve poter comunque calcolare il fabbisogno.
                     */
                    if (! $real) {
                        $real = Component::withTrashed()
                            ->where('category_id', $comp->category_id)
                            ->where('fabric_id', $fabricId)
                            ->where('color_id', $colorId)
                            ->orderBy('id')
                            ->first();

                        if ($real) {
                            Log::warning('explodeBom – componente reale archiviato/inattivo usato per ordine storico', [
                                'product_id'  => $productId,
                                'category_id' => $comp->category_id,
                                'fabric_id'   => $fabricId,
                                'color_id'    => $colorId,
                                'component_id'=> $real->id,
                                'is_active'   => $real->is_active ?? null,
                                'deleted_at'  => $real->deleted_at ?? null,
                            ]);
                        }
                    }

                    if (! $real) {
                        throw new \RuntimeException(
                            "Nessun componente anagrafico trovato per categoria={$comp->category_id}, " .
                            "fabric_id={$fabricId}, color_id={$colorId}. " .
                            "Crea/abilita il componente reale prima di procedere."
                        );
                    }

                    $compId = (int) $real->id;
                    Log::debug('explodeBom – slot variabile risolto', [
                        'product_id'   => $productId,
                        'slot'         => $comp->pivot->variable_slot,
                        'placeholder'  => $comp->id,
                        'resolved_id'  => $compId,
                        'fabric_id'    => $fabricId,
                        'color_id'     => $colorId,
                    ]);
                }

                // Accumula fabbisogno
                $need = $qtyProd * $pivotQty;
                $needed[$compId] = ($needed[$compId] ?? 0) + $need;
            }
        }

        Log::debug('explodeBom – output', ['needed' => $needed]);

        return $needed;
    }

    /** stock prenotato da altri OC */
    protected function reservedStock(Collection $componentIds): Collection
    {
        $data = DB::table('stock_reservations as sr')
            ->join('stock_levels as sl', 'sl.id', '=', 'sr.stock_level_id')
            ->whereIn('sl.component_id', $componentIds)
            ->when($this->excludeOrderId,
                fn ($q) => $q->where('sr.order_id', '!=', $this->excludeOrderId))
            ->selectRaw('sl.component_id, SUM(sr.quantity) as qty')
            ->groupBy('sl.component_id')
            ->pluck('qty', 'sl.component_id');

        Log::debug('reservedStock', ['data' => $data]);
        return $data;
    }

    /**
     * Incoming non riservato da altri OC (qty ancora “libera” sui PO)
     *
     * @return Collection<int,float>  component_id => qty
    */
    protected function incomingPurchase(Collection $componentIds): Collection
    {
        // FIX: non escludere le mie reservation dal conteggio e sommare per component_id
        return DB::table('orders as o')
            ->join('order_numbers as onr', 'onr.id', '=', 'o.order_number_id')
            ->join('order_items as oi', 'oi.order_id', '=', 'o.id')
            ->leftJoin('po_reservations as pr', 'pr.order_item_id', '=', 'oi.id')
            ->where('onr.order_type', 'supplier')
            ->whereNull('o.bill_number')
            ->whereIn('oi.component_id', $componentIds)
            ->whereBetween('o.delivery_date', [now()->startOfDay(), $this->deliveryDate])
            ->groupBy('oi.component_id')
            ->selectRaw('
                oi.component_id,
                GREATEST(
                    SUM(oi.quantity) - COALESCE(SUM(pr.quantity), 0),
                    0
                ) as free
            ')
            ->having('free', '>', 0)
            ->pluck('free', 'oi.component_id');
    }

    /** quantità prenotata su PO per QUESTO OC (solo informativa) */
    protected function myIncoming(Collection $componentIds): Collection
    {
        if (!$this->excludeOrderId) return collect();

        $data = DB::table('po_reservations as pr')
            ->join('order_items as oi', 'oi.id', '=', 'pr.order_item_id')
            ->join('orders as o',      'o.id',  '=', 'oi.order_id')
            ->join('order_numbers as on','o.order_number_id','=','on.id')
            ->where('on.order_type','supplier')
            ->where('pr.order_customer_id', $this->excludeOrderId)
            ->whereIn('oi.component_id', $componentIds)
            ->whereBetween('o.delivery_date', [now()->startOfDay(), $this->deliveryDate])
            ->selectRaw('oi.component_id, SUM(pr.quantity) as qty')
            ->groupBy('oi.component_id')
            ->pluck('qty', 'oi.component_id');

        Log::debug('myIncoming', ['data' => $data]);
        return $data;
    }

    /**
     * Verifica la disponibilità partendo già da un array
     * [ component_id => qty ]  senza passare per explodeBom().
     * 
     */
    public function checkComponents(array $componentsQty): AvailabilityResult
    {
        // ⬇️  trasformiamo in Collection compatibile con il resto del service
        $required = collect($componentsQty);

        /* Stock fisico */
        $onHand = StockLevel::query()
            ->whereIn('component_id', $required->keys())
            ->selectRaw('component_id, SUM(quantity) as qty')
            ->groupBy('component_id')
            ->pluck('qty', 'component_id');

        $reserved  = $this->reservedStock($required->keys());
        $available = $onHand->map(fn ($q,$cid) => $q - ($reserved[$cid] ?? 0));

        /* In arrivo (altri OC + questo OC) */
        $incoming     = $this->incomingPurchase($required->keys());
        $incomingMine = $this->myIncoming($required->keys());

        /* Shortage */
        $shortage = collect();
        foreach ($required as $cid => $need) {
            $have = ($available[$cid] ?? 0)
                + ($incoming[$cid] ?? 0)
                + ($incomingMine[$cid] ?? 0);

            if ($need > $have + 1e-6) {
                $shortage->push([
                    'component_id' => $cid,
                    'code'         => Component::findOrFail($cid)->code,
                    'description'  => Component::findOrFail($cid)->description,
                    'needed'       => $need,
                    'available'    => $available[$cid]    ?? 0,
                    'incoming'     => $incoming[$cid]     ?? 0,
                    'my_incoming'  => $incomingMine[$cid] ?? 0,
                    'shortage'     => round($need - $have, 4),
                ]);
            }
        }

        Log::debug('checkComponents – result', [
            'delivery_date' => $this->deliveryDate->toDateString(),
            'exclude_oc'    => $this->excludeOrderId,
            'ok'            => $shortage->isEmpty(),
            'shortage_cnt'  => $shortage->count(),
        ]);

        return new AvailabilityResult($shortage->isEmpty(), $shortage);
    }

}
