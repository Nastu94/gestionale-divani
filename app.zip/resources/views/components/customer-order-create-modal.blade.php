{{-- resources/views/components/customer-order-create-modal.blade.php --}}
{{-- =========================================================================
 |  Modale Crea / Modifica Ordine Cliente
 |  – PHP 8.4 / Laravel 12 – completamente commentato
 |  – front-end only: gli endpoint chiamati in fetch saranno implementati
 |    nella prossima fase (controller + rotte API)
 |  Basato su supplier-order-create-modal.blade.php → adattato a clienti /
 |  prodotti (stessa UX, stessi helper).
 |  Permesso minimo: orders.customer.create
 ========================================================================= --}}
<div
    x-data="customerOrderModal()"
    x-on:guest-created.window="handleGuest($event.detail)"
    x-show="show"
    x-cloak
    class="fixed inset-0 z-50 flex items-center justify-center"
    {{-- ascolta l’evento lanciato dalla toolbar della lista --}}
    x-init="setupWatches(); window.addEventListener('open-customer-order-modal', e => open(e.detail?.orderId));"
>
    {{-- BACKDROP --}}
    <div class="absolute inset-0 bg-black opacity-75" @click="close"></div>

    {{-- MODALE --}}
    <div
        class="relative bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-200
               rounded-xl shadow-xl w-full max-w-5xl p-6 overflow-y-auto max-h-[99vh]"
    >
        {{-- HEADER --}}
        <div class="flex items-start justify-between mb-4">
            <h3 class="text-lg font-semibold tracking-wide">
                <span x-show="!editMode" x-cloak>Crea Ordine Cliente</span>
                <span x-show="editMode"  x-cloak>Modifica Ordine #<span x-text="orderId"></span></span>
            </h3>
            <button @click="close" class="text-gray-500 hover:text-gray-800"><i class="fas fa-times"></i></button>
        </div>

        {{-- ================= FORM ================= --}}
        <form @submit.prevent="editMode ? update() : save()" class="space-y-4">
            {{-- ========= DATI TESTATA ========= --}}
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                {{-- Colonna SX --}}
                <div class="space-y-4">
                    {{-- Numero ordine (progressivo riservato) --}}
                    <div>
                        <label class="block text-sm font-medium">N. ordine</label>
                        <input type="text" x-model="order_number" class="mt-1 block w-full px-3 py-2 border rounded-md bg-gray-50 dark:bg-gray-700
                               text-sm text-gray-900 dark:text-gray-100" readonly>
                    </div>

                    {{-- Selezione cliente --}}
                    <div class="relative">
                        <label x-show="!selectedCustomer" x-cloak class="block text-sm font-medium">Cliente</label>

                        <input
                            type="text"
                            x-show="!selectedCustomer"
                            x-cloak
                            x-model="customerSearch"
                            @input.debounce.500="searchCustomers"
                            placeholder="Cerca cliente…"
                            class="mt-1 block w-full px-3 py-2 border rounded-md bg-gray-50 dark:bg-gray-700
                               text-sm text-gray-900 dark:text-gray-100"
                        >

                        {{-- Dropdown risultati --}}
                        <div
                            x-show="customerOptions.length"
                            x-cloak
                            class="absolute z-50 w-full mt-1 bg-white dark:bg-gray-800 border dark:border-gray-700 rounded shadow max-h-40 overflow-y-auto"
                        >
                            <template x-for="(option, idx) in customerOptions" :key="option.id + '-' + idx">
                                <div class="px-2 py-1 hover:bg-gray-100 dark:hover:bg-gray-700 cursor-pointer"
                                     @click="selectCustomer(option)">
                                    <span class="text-xs" x-text="option.company + ' - ' + option.shipping_address"></span>
                                </div>
                            </template>
                        </div>

                        {{-- link crea guest --}}
                        <div class="mt-1">
                            <button type="button"
                                    class="text-xs text-emerald-700 hover:underline"
                                    @click.stop="window.dispatchEvent(new CustomEvent('open-occasional-customer-modal'))"
                                    x-show="showGuestButton && !selectedCustomer"
                                    x-cloak>
                                + Nuovo cliente occasionale
                            </button>
                        </div>

                        {{-- Riepilogo cliente scelto --}}
                        <template x-if="selectedCustomer">
                            <div class="mt-2 p-2 border dark:border-gray-700 rounded bg-gray-50 dark:bg-gray-800">
                                <p class="font-semibold" x-text="selectedCustomer.company"></p>

                                <template x-if="selectedCustomer.email">
                                    <p class="text-xs" x-text="selectedCustomer.email"></p>
                                </template>

                                <template x-if="selectedCustomer.vat_number">
                                    <p class="text-xs" x-text="'P.IVA: ' + selectedCustomer.vat_number"></p>
                                </template>

                                <template x-if="selectedCustomer.tax_code && !selectedCustomer.vat_number">
                                    <p class="text-xs" x-text="'C.F.: ' + selectedCustomer.tax_code"></p>
                                </template>

                                <template x-if="selectedCustomer.shipping_address">
                                    <p class="text-xs" x-text="selectedCustomer.shipping_address"></p>
                                </template>

                                <button type="button"
                                        x-show="!editMode"
                                        @click="selectedCustomer=null; showGuestButton=true"
                                        class="text-xs text-red-600 mt-1">
                                    Cambia
                                </button>
                            </div>
                        </template>

                    </div>

                    {{-- Zona spedizione (orders.shipping_zone) - nota interna, solo stampa documenti --}}
                    <div x-show="selectedCustomer" x-cloak>
                        <label class="block text-sm font-medium">Zona spedizione</label>
                        <input type="text"
                            x-model="shipping_zone"
                            placeholder="Es. Nord, Centro, Sud, Isole, o note logistiche interne…"
                            class="mt-1 block w-full px-3 py-2 border rounded-md bg-gray-50 dark:bg-gray-700
                                    text-sm text-gray-900 dark:text-gray-100">
                    </div>

                    {{-- Riferimento (orders.reference) - usato per tabelle e documenti stampati --}}
                    <div x-show="selectedCustomer" x-cloak>
                        <label class="block text-sm font-medium">Riferimento</label>
                        <input type="text"
                            x-model="reference"
                            placeholder="Inserisci un riferimento"
                            class="mt-1 block w-full px-3 py-2 border rounded-md bg-gray-50 dark:bg-gray-700
                                    text-sm text-gray-900 dark:text-gray-100">
                    </div>
                </div>

                {{-- Colonna DX --}}
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium">Data consegna richiesta</label>
                        <input type="date" x-model="delivery_date" class="mt-1 block w-full px-3 py-2 border rounded-md bg-gray-50 dark:bg-gray-700
                               text-sm text-gray-900 dark:text-gray-100" required>
                    </div>
                    <div>
                        <label class="block text-sm font-medium">Valore ordine (€)</label>
                        <input type="text" :value="formatCurrency(total)" class="mt-1 block w-full px-3 py-2 border rounded-md bg-gray-50 dark:bg-gray-700
                               text-sm text-gray-900 dark:text-gray-100" readonly>
                    </div>

                    {{-- Numero colli --}}
                    <div>
                        <label class="block text-sm font-medium">Numero colli</label>
                        <input type="number" x-model="packages" min="1" step="1" placeholder="Opzionale (se noto)"
                               class="mt-1 block w-full px-3 py-2 border rounded-md bg-gray-50 dark:bg-gray-700
                               text-sm text-gray-900 dark:text-gray-100">
                    </div>
                    {{-- Flag anonimo "#" (orders.hash_flag) - checkbox senza label visibile --}}
                    <div class="flex items-center justify-end">
                        {{-- Checkbox senza label testuale; manteniamo solo tooltip e un badge # quando attivo --}}
                        <input  id="hash_flag"
                                type="checkbox"
                                x-model="hash_flag"
                                title="Flag #"
                                class="h-4 w-4 rounded border-gray-300 text-purple-600 focus:ring-purple-500 cursor-pointer" />
                    </div>
                </div>
            </div>

            {{-- ========= RIGHE DELL'ORDINE ========= --}}
            <div class="border-t pt-4">
                {{-- tabella righe già inserite --}}
                <table class="table-auto w-full text-xs mb-4">
                    <thead class="bg-gray-200 dark:bg-gray-800">
                        <tr>
                            <th class="px-2 py-1 text-left">Prodotto</th>
                            <th class="px-2 py-1 text-left">Tessuto</th>
                            <th class="px-2 py-1 w-20 text-right">Q.tà</th>
                            <th class="px-2 py-1 w-24 text-right">Prezzo €</th>
                            <th class="px-2 py-1 w-24 text-right">Sub-Tot €</th>
                            <th class="px-2 py-1 w-8"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <template x-for="(l,idx) in lines" :key="'line'+idx">
                            <tr class="border-b">
                                <td class="px-2 py-1" x-text="l.product.sku + ' — ' + l.product.name"></td>
                                <td class="px-2 py-1">
                                    <div class="flex items-center gap-2">
                                        <span class="inline-flex items-center gap-1 text-[11px] px-2 py-0.5 rounded-full bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200">
                                            <i class="fas fa-tshirt text-[11px]"></i>
                                            <span x-text="l.fabric_name || '—'"></span>
                                        </span>
                                        <span class="inline-flex items-center gap-1 text-[11px] px-2 py-0.5 rounded-full bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200">
                                            <i class="fas fa-palette text-[11px]"></i>
                                            <span x-text="l.color_name || '—'"></span>
                                        </span>
                                    </div>
                                    {{-- NEW: Visualizzazione note colori (solo se presente) --}}
                                    <template x-if="l.color_notes">
                                        <div class="mt-1 text-[11px] text-gray-600 whitespace-pre-line">
                                            <span x-text="l.color_notes"></span>
                                        </div>
                                    </template>
                                </td>
                                <td class="px-2 py-1 text-right" x-text="l.qty"></td>
                                <td class="px-2 py-1 text-right" x-text="formatCurrency(l.price)"></td>
                                <td class="px-2 py-1 text-right" x-text="formatCurrency(l.subtotal)"></td>
                                <td class="px-2 py-1 text-center flex space-x-1">
                                    <button type="button" @click="editLine(idx)" class="text-indigo-600"><i class="fas fa-pen"></i></button>
                                    <button type="button" @click="removeLine(idx)" class="ml-1 text-red-600"><i class="fas fa-trash"></i></button>
                                </td>
                            </tr>
                        </template>
                    </tbody>
                </table>
            </div>

            {{-- CARENZE COMPONENTI --}}
            <div x-show="availabilityOk === false"
                x-cloak
                class="border-t pt-4 mt-4">
                <h4 class="font-semibold text-red-700 text-sm mb-2">
                    Componenti mancanti
                </h4>

                <table class="w-full text-xs border">
                    <thead class="bg-red-100">
                        <tr>
                            <th class="px-2 py-1 text-left">Codice</th>
                            <th class="px-2 py-1 text-left">Descrizione</th>
                            <th class="px-2 py-1 text-right">Necessari</th>
                            <th class="px-2 py-1 text-right">Disponibili</th>
                            <th class="px-2 py-1 text-right">In arrivo</th>
                            <th class="px-2 py-1 text-right">Mancano</th>
                        </tr>
                    </thead>
                    <tbody>
                        <template x-for="row in shortage" :key="row.component_id">
                            <tr class="border-t">
                                <td class="px-2 py-1" x-text="row.code"></td>
                                <td class="px-2 py-1" x-text="row.description"></td>
                                <td class="px-2 py-1 text-right" x-text="row.needed"></td>
                                <td class="px-2 py-1 text-right" x-text="row.available"></td>
                                <td class="px-2 py-1 text-right" x-text="Number(row.incoming) + Number(row.my_incoming)"></td>
                                <td class="px-2 py-1 text-right font-semibold text-red-700" x-text="row.shortage"></td>
                            </tr>
                        </template>
                    </tbody>
                </table>
            </div>

            {{-- ========= AGGIUNGI PRODOTTO ========= --}}
            <div class="border-t pt-4 mt-4"
                 x-bind:class="canAddLines ? '' : 'opacity-50 pointer-events-none select-none'">
                <h4 class="font-semibold mb-2">Aggiungi prodotto</h4>

                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {{-- Ricerca prodotto --}}
                    <div class="relative">
                        <label class="block text-sm font-medium">Ricerca prodotto</label>

                        <input type="text"
                               x-model="productSearch"
                               @input.debounce.500="searchProducts"
                               placeholder="Cerca prodotto…"
                               class="mt-1 block w-full px-3 py-2 border rounded-md bg-gray-50 dark:bg-gray-700
                               text-sm text-gray-900 dark:text-gray-100"
                               x-show="!selectedProduct"
                               x-cloak
                               :disabled="!canAddLines">

                        <div x-show="productOptions.length"
                             x-cloak
                             class="absolute z-50 w-full mt-1 bg-white dark:bg-gray-800 border dark:border-gray-700 rounded shadow max-h-40 overflow-y-auto">
                            <template x-for="option in productOptions" :key="option.id">
                                <div class="px-2 py-1 hover:bg-gray-100 dark:hover:bg-gray-700 cursor-pointer"
                                     @click="selectProduct(option)">
                                    <span class="text-xs" x-text="option.sku + ' — '"></span>
                                    <span class="text-xs" x-text="option.name"></span>
                                </div>
                            </template>
                        </div>

                        {{-- Riepilogo prodotto scelto --}}
                        <template x-if="selectedProduct">
                            <div class="mt-2 p-2 border dark:border-gray-700 rounded bg-gray-50 dark:bg-gray-800">
                                <p><strong x-text="selectedProduct.sku"></strong> — <span x-text="selectedProduct.name"></span></p>
                                <button type="button" @click="selectedProduct=null"
                                        class="text-xs text-red-600 mt-1">Cambia</button>
                            </div>
                        </template>
                    </div>

                    {{-- Quantità --}}
                    <div>
                        <label class="block text-sm font-medium">Quantità</label>
                        <input type="number" min="1" x-model.number="quantity" @input.debounce.250ms="reprice()"
                               class="mt-1 block w-full px-3 py-2 border rounded-md bg-gray-50 dark:bg-gray-700
                               text-sm text-gray-900 dark:text-gray-100" :disabled="!canAddLines">
                    </div>

                    {{-- Prezzo + pulsante --}}
                    <div class="flex flex-col">
                        <label class="block text-sm font-medium">Prezzo (€)</label>
                        <input type="number" min="0" step="0.01" x-model.number="price"
                               class="mt-1 block w-full px-3 py-2 border rounded-md bg-gray-50 dark:bg-gray-700
                               text-sm text-gray-900 dark:text-gray-100" :disabled="!canAddLines">
                    </div>
                </div>

                {{-- Selezione variabili per la riga corrente --}}
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-2">
                    {{-- Tessuto --}}
                    <div>
                        <label class="block text-sm font-medium">Tessuto</label>
                        <select class="mt-1 block w-full px-3 py-2 border rounded-md bg-gray-50 dark:bg-gray-700 text-sm"
                                x-model.number="fabric_id"
                                @change="reprice()"
                                :disabled="!selectedProduct || fabricOptions.length === 0">
                            <option value="">—</option>
                            <template x-for="f in fabricOptions" :key="'f-'+f.id">
                                <option :value="f.id" x-text="f.name"></option>
                            </template>
                        </select>
                        <p class="text-[11px] text-amber-600 mt-1" x-show="selectedProduct && fabricOptions.length===0" x-cloak>
                            Nessun tessuto in whitelist per questo prodotto.
                        </p>
                    </div>

                    {{-- Colore --}}
                    <div>
                        <label class="block text-sm font-medium">Colore</label>
                        <select class="mt-1 block w-full px-3 py-2 border rounded-md bg-gray-50 dark:bg-gray-700 text-sm"
                                x-model.number="color_id"
                                @change="reprice()"
                                :disabled="!selectedProduct || colorOptions.length === 0">
                            <option value="">—</option>
                            <template x-for="c in colorOptions" :key="'c-'+c.id">
                                <option :value="c.id" x-text="c.name"></option>
                            </template>
                        </select>
                        <p class="text-[11px] text-amber-600 mt-1" x-show="selectedProduct && colorOptions.length===0" x-cloak>
                            Nessun colore in whitelist per questo prodotto.
                        </p>
                    </div>

                    {{-- NEW: Note colori per riga (order_product_variables.color_notes) --}}
                    <div class="md:col-span-2 mt-2">
                        <label class="block text-sm font-medium">Note colori</label>
                        <textarea x-model="color_notes"
                                rows="2"
                                placeholder="Es. stesso tessuto: seduta Blu, schienale Grigio… (nota interna)"
                                class="mt-1 block w-full px-3 py-2 border rounded-md bg-gray-50 dark:bg-gray-700
                                        text-sm text-gray-900 dark:text-gray-100"
                                :disabled="!selectedProduct"></textarea>
                    </div>
                </div>

                {{-- Sconti riga multipli (order_items.discount) --}}
                <div class="md:col-span-3 mt-2">
                    <div class="flex items-center justify-start space-x-2">
                        <label class="block text-sm font-medium">Sconti riga</label>
                        <button type="button"
                                class="text-xs text-emerald-700 hover:underline"
                                @click="discountsDraft.push({ type: 'percent', value: '' })">
                            + Aggiungi sconto
                        </button>
                    </div>

                    <template x-for="(d, i) in discountsDraft" :key="'disc'+i">
                        <div class="mt-2 flex items-center gap-2">
                            {{-- Tipo sconto: percentuale o fisso --}}
                            <select x-model="d.type"
                                    class="px-2 py-1 border rounded bg-gray-50 dark:bg-gray-700 text-xs" @change="reprice()">
                                <option value="percent">%</option>
                                <option value="fixed">Fisso</option>
                            </select>

                            {{-- Valore sconto --}}
                            <input  type="number" step="0.01" min="0"
                                    x-model.number="d.value" @input.debounce.250="reprice()"
                                    placeholder="valore"
                                    class="px-2 py-1 border rounded bg-gray-50 dark:bg-gray-700 text-xs w-24" />

                            {{-- Rappresentazione token che andrà salvata (es. "10%" o "25") --}}
                            <span class="text-[11px] text-gray-600"
                                x-text="'-' + (d.type === 'percent' && d.value !== '' ? (Number(d.value) + '%') : ((d.value + '€') ?? ''))">
                            </span>

                            {{-- Rimuovi riga --}}
                            <button type="button" class="text-xs text-red-600"
                                    @click="discountsDraft.splice(i, 1); reprice()">
                                Rimuovi
                            </button>
                        </div>
                    </template>

                    {{-- Nota: nel DB salveremo un array di stringhe ["10%","25"] --}}
                </div>


                <div class="flex justify-end">
                    <button type="button"
                            class="mt-3 inline-flex items-center justify-center
                                    px-3 py-1.5 rounded-md text-xs font-semibold text-white uppercase
                                    bg-emerald-600 hover:bg-emerald-500"
                            :disabled="!canAddLines || !selectedProduct || quantity <= 0"
                            @click="addLine">
                        <i class="fas fa-plus-square mr-1"></i> Aggiungi prodotto
                    </button>
                </div>
            </div>

            {{-- Note ordine (orders.note) --}}
            <div class="border-t pt-4 mt-4">
                <label class="block text-sm font-medium">Note ordine</label>
                <textarea x-model="note"
                        rows="3"
                        placeholder="Annotazioni interne…"
                        class="mt-1 block w-full px-3 py-2 border rounded-md bg-gray-50 dark:bg-gray-700
                                text-sm text-gray-900 dark:text-gray-100"></textarea>
                {{-- Le note saranno salvate in orders.note e mostrate nella sidebar "Visualizza" --}}
            </div>

            {{-- ========= SALVA ========= --}}
            <div class="flex justify-end border-t pt-4 mt-4 space-x-2">
                <button type="button"
                        @click="close()"
                        class="inline-flex items-center px-3 py-1.5 border rounded-md text-xs font-semibold
                            text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600">
                    Annulla
                </button>

                {{-- Verifica disponibilità --}}
                <button type="button"
                        class="inline-flex items-center px-3 py-1.5 rounded-md text-xs font-semibold
                            text-white uppercase bg-blue-600 hover:bg-blue-500
                            disabled:opacity-50"
                        :disabled="checking"
                        x-show="occasional_customer_id != null"
                        @click="checkAvailability">
                    <i class="fas fa-circle-notch fa-spin mr-2" x-show="checking"></i>
                    Verifica disponibilità
                </button>

                {{-- Visibile solo quando il BE, dopo l’update, ha risposto recalc_available=true --}}
                <button type="button"
                        class="inline-flex items-center px-3 py-1.5 rounded-md text-xs font-semibold
                            text-white uppercase bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50"
                        x-show="recalcAvailable && !recalcDone"
                        @click="recalcProcurement">
                    <i class="fas fa-rotate mr-2"></i>
                    Ricalcola approvvigionamenti
                </button>

                <button type="submit"
                        class="inline-flex items-center px-4 py-2 bg-purple-600
                            rounded-md text-sm font-semibold text-white uppercase
                            hover:bg-purple-500"
                        :disabled="(availabilityOk === null || checking) && occasional_customer_id != null">
                    <i class="fas fa-save mr-2"></i>
                    <span x-text="editMode ? 'Modifica Ordine' : 'Salva Ordine'"></span>
                </button>
            </div>
        </form>

        {{-- modale per cliente occasionale --}}
        <x-occasional-customer-modal />
    </div>
</div>

{{-- ===================== SCRIPT ALPINE ===================== --}}
<script>
    if (!window.GD_VARIABLE_OPTIONS) {
        fetch('/products/variables/options', { headers:{ Accept:'application/json' }})
            .then(r => r.json())
            .then(data => {
            // atteso: { fabrics:[{id,name},...], colors:[{id,name},...] }
            window.GD_VARIABLE_OPTIONS = data || {fabrics:[], colors:[]};
            })
            .catch(() => { window.GD_VARIABLE_OPTIONS = {fabrics:[], colors:[]}; });
    }

    window.GD_findName = (arr, id) =>
        (arr || []).find(x => Number(x.id) === Number(id))?.name ?? null;
    
    function customerOrderModal() {
        return {
            /* ==== Stato base ==== */
            show      : false,
            editMode  : false,
            orderId   : null,
            showGuestButton : true,

            /* ==== Stato ordine (nuovi flag) ==== */
            orderStatus: 0,            // 0 = non confermato, 1 = confermato (popolato in fetchOrder)
            recalcAvailable: false,    // true se BE segnala che serve ricalcolo (standard confermato)
            recalcDone: false,         // true dopo CTA “Ricalcola approvvigionamenti”

            /* ==== Snapshot per rilevare modifiche effettive ==== */
            _initialSnapshot: null,
            _snapshotReady: false,
            _skipReprice: false,

            /**
             * Campi header dell'ordine.
             */
            delivery_date    : '',
            order_number_id  : null,
            order_number     : '—',
            hash_flag        : false,
            note             : '',
            shipping_zone    : '',
            reference        : '',
            packages         : null,

            /* ==== Cliente ==== */
            customerSearch   : '',
            customerOptions  : [],
            selectedCustomer : null,
            occasional_customer_id : null,

            /* ==== Righe ==== */
            lines            : [],
            productSearch    : '',
            productOptions   : [],
            selectedProduct  : null,
            price            : 0,
            quantity         : 1,
            discountsDraft   : [],

            /* ==== Variabili di riga ==== */
            fabricOptions : [],
            colorOptions  : [],
            fabric_id     : '',
            color_id      : '',
            color_notes     : '',

            /* ==== Verifica disponibilità ==== */
            availabilityOk : null,     // null = non ancora verificato
            shortage       : [],       // array componenti mancanti
            poLinks        : [],       // ordini fornitore creati
            checking       : false,    // spinner Verifica

            /* ================= Metodi ================ */

            /* Inizializzazione component */
            init() {
                this.setupWatches();

                // Cattura/azzera snapshot quando il modale apre/chiude
                this.$watch('show', (open) => {
                    if (open) {
                        // reset stato CTA ad ogni apertura
                        this.recalcDone = false;
                        // recalcAvailable: lo imposta BE dopo update; non lo forziamo qui
                        this.$nextTick(() => this._captureSnapshot());
                    } else {
                        this._snapshotReady = false;
                        this._initialSnapshot = null;
                    }
                });
            },

            /* Watchers utili per il pricing live */
            setupWatches() {
                this.$watch('fabric_id',  () => { if (!this._skipReprice) this.reprice(); });
                this.$watch('color_id',   () => { if (!this._skipReprice) this.reprice(); });
                this.$watch('quantity',   () => { if (!this._skipReprice) this.reprice(); });
                this.$watch('discountsDraft', () => { if (!this._skipReprice) this.reprice(); }, { deep: true });
            },

            /* Snapshot normalizzato (stessa forma del payload submit) */
            _makeSnapshot() {
                return JSON.stringify({
                    order_number_id: this.order_number_id,
                    customer_id: this.occasional_customer_id ? null : (this.selectedCustomer ? this.selectedCustomer.id : null),
                    occasional_customer_id: this.occasional_customer_id ?? null,
                    delivery_date: this.delivery_date || null,
                    shipping_address: this.selectedCustomer ? (this.selectedCustomer.shipping_address || null) : null,
                    shipping_zone: (this.shipping_zone && String(this.shipping_zone).trim()) || null,
                    reference: (this.reference && String(this.reference).trim()) || null,
                    packages: this.packages ? parseInt(this.packages) : null,
                    hash_flag: !!this.hash_flag,
                    note: (this.note && String(this.note).trim()) || null,
                    lines: (this.lines || []).map(l => ({
                        product_id : l.product?.id ?? null,
                        quantity   : +l.qty,
                        price      : l.price !== '' && l.price !== null ? +l.price : null,
                        fabric_id  : l.fabric_id || null,
                        color_id   : l.color_id  || null,
                        color_notes: (l.color_notes && String(l.color_notes).trim()) || null,
                        discount   : Array.isArray(l.discount) ? l.discount : [],
                    })),
                });
            },

            _captureSnapshot() {
                this._initialSnapshot = this._makeSnapshot();
                this._snapshotReady = true;
            },

            hasChanges() {
                if (!this._snapshotReady) return false;
                return this._makeSnapshot() !== this._initialSnapshot;
            },

            isStandard() { return this.occasional_customer_id == null; },

            /* Gestione guest/occasionale */
            handleGuest(guest) {
                guest.shipping_address = [
                    guest.address,
                    guest.postal_code && guest.city ? `${guest.postal_code} ${guest.city}` : guest.city,
                    guest.province,
                    guest.country
                ].filter(Boolean).join(', ');

                this.selectedCustomer        = guest;
                this.occasional_customer_id  = guest.id;
                this.customer_id             = null;
                this.showGuestButton         = false;
            },

            /* Getter */
            get canAddLines() { return this.selectedCustomer && this.delivery_date; },
            get total()       { return this.lines.reduce((t,l)=>t + l.subtotal, 0); },

            /* Apertura / chiusura modale */
            open(id = null) {
                this.show     = true;
                this.editMode = !!id;
                this.orderId  = id;

                // reset flag CTA a ogni nuova apertura
                this.recalcAvailable = false;
                this.recalcDone = false;

                if (this.editMode) {
                    this.fetchOrder(id).then(() => {
                        // snapshot dopo aver caricato i dati dell’ordine
                        this.$nextTick(() => this._captureSnapshot());
                    });
                } else {
                    this.resetForm();
                    this.reserveNumber();
                    // snapshot sul form “nuovo”
                    this.$nextTick(() => this._captureSnapshot());
                }
            },

            close() {
                // Blocca/avvisa SOLO se: edit di standard confermato, serve ricalcolo, non fatto, e ci sono MODIFICHE
                const mustBlock =
                    this.editMode &&
                    this.isStandard() &&
                    this.orderStatus === 1 &&
                    this.recalcAvailable &&
                    !this.recalcDone &&
                    this.hasChanges();

                if (mustBlock) {
                    const ok = confirm('Hai modificato un ordine confermato. Devi completare il “Ricalcola approvvigionamenti” per aggiornare riserve e PO. Vuoi davvero chiudere senza ricalcolare?');
                    if (!ok) return;
                }
                this.show = false;
            },

            /* Reset form */
            resetForm() {
                this.delivery_date    = '';
                this.selectedCustomer = null;
                this.occasional_customer_id  = null;
                this.customerOptions  = [];
                this.customerSearch   = '';
                this.lines            = [];
                this.selectedProduct  = null;
                this.shipping_zone    = '';
                this.reference        = '';
                this.packages         = null;
                this.productSearch    = '';
                this.price            = 0;
                this.quantity         = 1;
                this.order_number_id  = null;
                this.order_number     = '—';
                this.availabilityOk   = null;
                this.shortage         = [];
                this.poLinks          = [];
                this.checking         = false;
                this.fabricOptions    = [];
                this.colorOptions     = [];
                this.fabric_id        = '';
                this.color_id         = '';
                this.color_notes      = '';
                this.discountsDraft   = [];
                this.hash_flag        = false;
                this.note             = '';
                this.orderStatus      = 0;
            },

            /* Prenota progressivo */
            reserveNumber() {
                fetch('/order-numbers/reserve', {
                    method : 'POST',
                    headers: {
                        'Accept':'application/json','Content-Type':'application/json',
                        'X-CSRF-TOKEN':document.querySelector('meta[name="csrf-token"]').content
                    },
                    credentials:'same-origin',
                    body: JSON.stringify({ type:'customer' })
                })
                .then(r=>r.json()).then(j=>{ this.order_number_id=j.id; this.order_number=j.number; })
                .catch(()=>{ this.order_number_id=null; this.order_number='—'; });
            },

            /* Ricerca clienti */
            async searchCustomers(){
                if (this.customerSearch.trim().length < 2) { this.customerOptions=[]; return; }
                try{
                    const r = await fetch(`/customers/search?q=${encodeURIComponent(this.customerSearch.trim())}`,
                                        { headers:{Accept:'application/json'}, credentials:'same-origin' });
                    if(!r.ok) throw new Error(r.status);
                    this.customerOptions = await r.json();
                }catch{ this.customerOptions=[]; }
            },

            selectCustomer(o){
                this.selectedCustomer=o;
                this.customerOptions=[];
                this.occasional_customer_id = null;
            },

            /* Ricerca prodotti */
            async searchProducts() {
                if (this.productSearch.trim().length < 2) {
                    this.productOptions = []; return;
                }

                const custId = this.occasional_customer_id ? '' : (this.selectedCustomer?.id ?? '');

                const qs = new URLSearchParams({
                    q: this.productSearch.trim(),
                    ...(custId ? { customer_id: String(custId) } : {}),
                    ...(this.delivery_date ? { date: this.delivery_date } : {}),
                });

                try {
                    const r = await fetch(`/products/search?${qs.toString()}`, {
                        headers:{ Accept:'application/json' }, credentials:'same-origin'
                    });
                    if (!r.ok) throw new Error(r.status);
                    this.productOptions = await r.json();
                } catch {
                    this.productOptions = [];
                }
            },

            selectProduct(option) {
                this.selectedProduct = option;
                this.productOptions  = [];
                const p = option.effective_price ?? option.price ?? 0;
                this.price = Number(p);
                this.loadProductWhitelist(option.id);
            },

            /* Gestione righe */
            addLine() {
                if (!this.selectedProduct || this.quantity <= 0) return;

                const qty  = Number(this.quantity || 1);
                const unit = Number(this.price || 0);

                const discountTokens = (this.discountsDraft || [])
                    .filter(d => d && d.value !== '' && !Number.isNaN(Number(d.value)))
                    .map(d => d.type === 'percent' ? `${Number(d.value)}%` : `${Number(d.value)}`);

                this.lines.push({
                    product     : this.selectedProduct,
                    qty         : qty,
                    price       : unit,                // unitario NETTO
                    subtotal    : unit * qty,
                    fabric_id   : this.fabric_id || null,
                    color_id    : this.color_id  || null,
                    fabric_name : window.GD_findName(window.GD_VARIABLE_OPTIONS.fabrics, this.fabric_id),
                    color_name  : window.GD_findName(window.GD_VARIABLE_OPTIONS.colors,  this.color_id),
                    color_notes : (this.color_notes && String(this.color_notes).trim().length) ? this.color_notes.trim() : null,
                    discount    : discountTokens,
                });

                // reset input riga
                this.availabilityOk = null;
                this.selectedProduct=null; this.productSearch=''; this.price=0; this.quantity=1;
                this.fabric_id=null; this.color_id=null; this.discountsDraft=[];
                this.color_notes = '';
            },

            editLine(i){
                if(this.selectedProduct){
                    alert('Completa prima la riga in modifica.');
                    return;
                }
                const l = this.lines.splice(i,1)[0];
                
                this._skipReprice = true; // Sospendo il ricalcolo per conservare il prezzo
                
                this.selectedProduct    = l.product;
                this.price              = l.price;
                this.quantity           = l.qty;
                this.color_notes        = l.color_notes ?? ''; 
                this.productSearch      = '';
                this.availabilityOk     = null;
                this.discountsDraft     = Array.isArray(l.discount)
                    ? l.discount.map(tok => {
                        const isPerc = typeof tok === 'string' && tok.trim().endsWith('%');
                        const val = parseFloat(isPerc ? tok.slice(0, -1) : tok);
                        return { type: isPerc ? 'percent' : 'fixed', value: Number.isFinite(val) ? val : '' };
                    })
                    : [];

                this.loadProductWhitelist(l.product.id, l.fabric_id ?? null, l.color_id ?? null, true)
                    .finally(() => {
                        this.$nextTick(() => { this._skipReprice = false; });
                    });
            },

            removeLine(i){ this.lines.splice(i,1); this.availabilityOk = null; },

            /* Helpers */
            formatCurrency(v){ return Intl.NumberFormat('it-IT',{minimumFractionDigits:2}).format(v||0); },

            /* Submit unico (create / update) */
            async submit() {
                if (!this.selectedCustomer || !this.delivery_date || !this.lines.length) {
                    alert('Compila data consegna, cliente e almeno una riga.'); return;
                }
                if (this.availabilityOk === null && this.occasional_customer_id != null) {
                    alert('Esegui prima la verifica disponibilità.'); return;
                }

                /**
                 * Payload di salvataggio ordine.
                 *
                 * I campi testuali opzionali vengono normalizzati:
                 * - stringa vuota => null
                 */
                const payload = {
                    order_number_id : this.order_number_id,
                    customer_id     : this.occasional_customer_id ? null : this.selectedCustomer.id,
                    occasional_customer_id : this.occasional_customer_id ?? null,
                    delivery_date   : this.delivery_date,
                    shipping_address: this.selectedCustomer.shipping_address,
                    shipping_zone   : (this.shipping_zone && String(this.shipping_zone).trim().length) ? this.shipping_zone.trim() : null,
                    reference       : (this.reference && String(this.reference).trim().length) ? this.reference.trim() : null,
                    packages        : this.packages ? parseInt(this.packages) : null,
                    hash_flag       : this.hash_flag ? 1 : 0,
                    note            : (this.note && String(this.note).trim().length) ? this.note.trim() : null,
                    lines : this.lines.map(l => ({
                        product_id : l.product.id,
                        quantity   : l.qty,
                        price      : l.price,
                        fabric_id  : l.fabric_id || null,
                        color_id   : l.color_id  || null,
                        color_notes: (l.color_notes && String(l.color_notes).trim().length) ? String(l.color_notes).trim() : null,
                        discount   : Array.isArray(l.discount) ? l.discount : [],
                    }))
                };

                const url    = this.editMode ? `/orders/customer/${this.orderId}` : '/orders/customer';
                const method = this.editMode ? 'PUT' : 'POST';

                try {
                    const r = await fetch(url, {
                        method,
                        headers : {
                            Accept         : 'application/json',
                            'Content-Type' : 'application/json',
                            'X-CSRF-TOKEN' : document.querySelector('meta[name="csrf-token"]').content
                        },
                        credentials : 'same-origin',
                        body        : JSON.stringify(payload)
                    });

                    if (!r.ok) {
                        let msg = 'Errore nel salvataggio.';
                        try {
                            const err = await r.json();
                            msg = (err && err.message) ? err.message : msg;
                        } catch {
                            msg = await r.text();
                        }
                        alert(msg);
                        return;
                    }

                    const j = await r.json();

                    // PO creati (tipicamente occasionali o ricalcoli)
                    if (Array.isArray(j.po_numbers) && j.po_numbers.length > 0) {
                        alert('Ordine cliente salvato.\nSono stati creati i seguenti ordini fornitore: ' + j.po_numbers.join(', '));
                        this.close();
                        window.location.reload();
                        return;
                    }

                    // STANDARD in attesa conferma (store o update pre-conferma)
                    if (j.awaiting_confirmation === true) {
                        alert('Richiesta conferma inviata al cliente.');
                        this.close();
                        window.location.reload();
                        return;
                    }

                    // STANDARD confermato, Opzione A (nessun ricalcolo auto)
                    if (j.recalc_available === true) {
                        alert('Ordine aggiornato.');
                        this.recalcAvailable = true;
                        this.orderId = j.order_id ?? this.orderId;
                        // NON chiudo: l’utente deve lanciare il CTA oppure chiudere consapevolmente
                        // Aggiorno snapshot alla nuova versione post-update
                        this.$nextTick(() => this._captureSnapshot());
                        return;
                    }

                    // Default
                    alert(j.message || 'Ordine salvato con successo.');
                    this.close();
                    window.location.reload();

                } catch (e) {
                    console.error('Errore salvataggio', e);
                    alert('Errore nel salvataggio.');
                }
            },

            save()   { this.submit(); },
            update() { this.submit(); },

            /* Fetch ordine esistente (edit) */
            async fetchOrder(id) {
                try {
                    const r = await fetch(`/orders/customer/${id}/edit`, {
                        headers     : { 'Accept':'application/json' },
                        credentials : 'same-origin'
                    });
                    if (!r.ok) throw new Error(r.status);
                    const o = await r.json();

                    this.orderId          = o.id;
                    this.order_number     = o.number;
                    this.order_number_id  = o.order_number_id;
                    this.delivery_date    = o.delivery_date;
                    this.orderStatus      = Number(o.status ?? 0);

                    // Standard vs Occasionali
                    this.occasional_customer_id = o.occ_customer ? (o.occ_customer.id ?? null) : null;

                    // Cliente (standard o occasionale) + indirizzo
                    this.selectedCustomer = o.customer ?? o.occ_customer ?? null;
                    if (this.selectedCustomer) {
                        this.selectedCustomer.shipping_address = o.shipping_address ?? '';
                    }
                    this.customerSearch = this.selectedCustomer?.company ?? '';

                    this.hash_flag = !!o.hash_flag;
                    this.note      = o.note ?? '';
                    this.packages  = o.packages ?? null;
                    this.shipping_zone = o.shipping_zone ?? '';
                    this.reference     = o.reference ?? '';
                    this.lines = (o.lines || []).map(l => ({
                        product  : { id:l.product_id, sku:l.sku, name:l.name },
                        qty      : l.quantity,
                        price    : Number(l.price),
                        fabric_id: l.fabric_id,
                        color_id : l.color_id,
                        fabric_name : window.GD_findName(window.GD_VARIABLE_OPTIONS.fabrics, l.fabric_id),
                        color_name  : window.GD_findName(window.GD_VARIABLE_OPTIONS.colors,  l.color_id),
                        color_notes : l.color_notes ?? null,
                        subtotal : l.quantity * l.price,
                        discount : Array.isArray(l.discount) ? l.discount : [],
                    }));

                    this.selectedProduct = null;
                    this.productSearch   = '';
                    this.price           = 0;
                    this.quantity        = 1;

                } catch (e) {
                    console.error('Impossibile caricare ordine', e);
                    alert('Errore nel caricamento dei dati ordine.');
                    this.close();
                }
            },

            /* Verifica disponibilità (solo occasionali) */
            async checkAvailability () {
                this.checking       = true;
                this.availabilityOk = null;

                try {
                    const payload = {
                        order_id      : this.editMode ? this.orderId : null,
                        delivery_date : this.delivery_date,
                        lines         : this.lines.map(l => ({
                            product_id : l.product.id,
                            quantity   : l.qty,
                            fabric_id  : l.fabric_id || null,
                            color_id   : l.color_id  || null,
                        }))
                    };

                    const r = await fetch('/orders/check-components', {
                        method  : 'POST',
                        headers : {
                            Accept         : 'application/json',
                            'Content-Type' : 'application/json',
                            'X-CSRF-TOKEN' : document.querySelector('meta[name="csrf-token"]').content
                        },
                        credentials : 'same-origin',
                        body        : JSON.stringify(payload)
                    });

                    const j = await r.json();

                    this.availabilityOk = j.ok;
                    this.shortage       = j.shortage ?? [];

                    if (j.ok) {
                        alert('Tutti i componenti sono disponibili.');
                    } else {
                        alert('Componenti insufficienti: controlla la tabella sotto.');
                    }

                } catch (e) {
                    console.error(e);
                    alert('Errore nella verifica disponibilità');
                } finally {
                    this.checking = false;
                }
            },

            /* Carica whitelist variabili prodotto */
            async loadProductWhitelist(productId, preselectFabricId = null, preselectColorId = null, skipReprice = false) {
                if (!productId) {
                    this.fabricOptions = [];
                    this.colorOptions  = [];
                    this.fabric_id     = '';
                    this.color_id      = '';
                    return;
                }

                try {
                    const r = await fetch(`/products/${productId}/variables`, { headers: { Accept:'application/json' } });
                    if (!r.ok) throw new Error(String(r.status));
                    const js = await r.json();

                    const allF = (window.GD_VARIABLE_OPTIONS && window.GD_VARIABLE_OPTIONS.fabrics) || [];
                    const allC = (window.GD_VARIABLE_OPTIONS && window.GD_VARIABLE_OPTIONS.colors)  || [];

                    const allowedF = new Set((js.fabric_ids || []).map(n => Number(n)));
                    const allowedC = new Set((js.color_ids  || []).map(n => Number(n)));

                    this.fabricOptions = allF.filter(f => allowedF.has(Number(f.id)));
                    this.colorOptions  = allC.filter(c => allowedC.has(Number(c.id)));

                    const defF = Number(js.default_fabric_id || 0);
                    const defC = Number(js.default_color_id || 0);
                    const wantF = Number(preselectFabricId || 0);
                    const wantC = Number(preselectColorId  || 0);

                    const pick = (preferred, def, allowed, options) => {
                        if (preferred && allowed.has(preferred)) return preferred;
                        if (def && allowed.has(def))             return def;
                        const first = options[0]?.id ?? '';
                        return first ? Number(first) : '';
                    };

                    this.fabric_id = pick(wantF, defF, allowedF, this.fabricOptions);
                    this.color_id  = pick(wantC, defC, allowedC, this.colorOptions);

                    if (!skipReprice) {
                        this.reprice();
                    }
                } catch (e) {
                    console.error('variables load failed', e);
                    this.fabricOptions=[]; this.colorOptions=[];
                    this.fabric_id=''; this.color_id='';
                }
            },

            /* Ricalcolo prezzo lato server */
            _priceAbort: null,
            async reprice() {
                if (!this.selectedProduct) return;
                try {
                    if (this._priceAbort) this._priceAbort.abort();
                    this._priceAbort = new AbortController();

                    const discounts = (this.discountsDraft || [])
                        .filter(d => d && d.value !== '' && !Number.isNaN(Number(d.value)))
                        .map(d => d.type === 'percent' ? `${Number(d.value)}%` : `${Number(d.value)}`);

                    const body = {
                        product_id: this.selectedProduct.id,
                        qty: this.quantity || 1,
                        fabric_id: this.fabric_id || null,
                        color_id:  this.color_id  || null,
                        customer_id: this.occasional_customer_id ? null : (this.selectedCustomer?.id ?? null),
                        discounts  : discounts,
                    };

                    const r = await fetch('/orders/line-quote', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'Accept': 'application/json',
                            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.content,
                        },
                        body: JSON.stringify(body),
                        signal: this._priceAbort.signal,
                    });
                    if (!r.ok) throw new Error('pricing_failed');
                    const q = await r.json();

                    let unitNet = q.discounted_unit_price ?? q.unit_price ?? q.effective_price;
                    if (unitNet !== undefined && unitNet !== null) {
                        this.price = Number(unitNet);
                    }
                    this.total = this.lines.reduce((s,l)=>s+(l.subtotal||0),0) + Number(this.price||0) * (this.quantity||1);
                } catch(e) {
                    if (e.name === 'AbortError') return;
                }
            },

            /* CTA: Ricalcola approvvigionamenti (standard confermato) */
            async recalcProcurement() {
                if (!this.orderId) { alert('Ordine non valido.'); return; }
                try {
                    const r = await fetch(`/orders/customer/${this.orderId}/recalc-procurement`, {
                        method: 'POST',
                        headers: {
                            Accept: 'application/json',
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                        },
                        credentials: 'same-origin',
                    });

                    if (!r.ok) {
                        let msg = 'Errore durante il ricalcolo.';
                        try {
                            const err = await r.json();
                            if (err && err.message) msg = err.message;
                        } catch (e) {
                            msg = await r.text();
                        }
                        alert(msg);
                        return;
                    }

                    const j = await r.json();
                    this.recalcDone = true;

                    if (Array.isArray(j.po_numbers) && j.po_numbers.length) {
                        alert((j.message || 'Ricalcolo completato.') + '\nPO creati: ' + j.po_numbers.join(', '));
                    } else {
                        alert(j.message || 'Ricalcolo completato. Nessun nuovo PO necessario.');
                    }

                    // NON chiudiamo automaticamente: l’utente decide.
                    // Aggiorna snapshot per evitare falsi positivi alla chiusura
                    this.$nextTick(() => this._captureSnapshot());

                    this.close();

                } catch (e) {
                    console.error(e);
                    alert('Errore durante il ricalcolo.');
                }
            },
        };
    }
</script>
