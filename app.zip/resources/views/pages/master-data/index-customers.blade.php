{{-- resources/views/pages/master-data/index-customers.blade.php --}}

<x-app-layout>
    <x-slot name="header">
        <div class="flex flex-wrap items-center justify-between">
            <h2 class="font-semibold text-lg text-gray-800 dark:text-gray-200 leading-tight">{{ __('Clienti') }}</h2>
            <x-dashboard-tiles />
        </div>
        
        @if (session('success'))
            <div
                x-data="{ show: true }"
                x-init="setTimeout(() => show = false, 10000)"
                x-show="show"
                x-transition.opacity.duration.500ms
                class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mt-2"
                role="alert"
            >
                <i class="fas fa-check-circle mr-2"></i>
                <span class="block sm:inline">{{ session('success') }}</span>
            </div>
        @endif

        @if (session('error'))
            <div
                x-data="{ show: true }"
                x-init="setTimeout(() => show = false, 10000)"
                x-show="show"
                x-transition.opacity.duration.500ms
                class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mt-2"
                role="alert"
            >
                <i class="fas fa-exclamation-triangle mr-2"></i>
                <span class="block sm:inline">{{ session('error') }}</span>
            </div>
        @endif
    </x-slot>

    <div class="py-6">
        <div x-data="customerCrud()" class="max-w-full mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 shadow sm:rounded-lg">

                {{-- Pulsante “Nuovo” --}}
                <div class="flex justify-end m-2 p-2">
                    @if(auth()->user()->can('customers.create'))
                        <button 
                            @click="openCreate"
                            class="inline-flex items-center m-2 px-3 py-1.5 bg-purple-600 rounded-md
                                        text-xs font-semibold text-white uppercase hover:bg-purple-500
                                        focus:outline-none focus:ring-2 focus:ring-purple-300 transition"
                        >
                            <i class="fas fa-plus mr-1"></i> Nuovo
                        </button>
                    @endif

                    {{-- Pulsante Estendi/Comprimi su tutta la tabella --}}
                    <button
                        type="button"
                        @click="extended = !extended"
                        class="inline-flex items-center m-2 px-3 py-1.5 bg-indigo-600 rounded-md text-xs font-semibold text-white uppercase
                            hover:bg-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-900 transition"
                    >
                        <i class="fas p-1" :class="extended ? 'fa-compress' : 'fa-expand'"></i>
                        <span x-text="extended ? 'Comprimi tabella' : 'Estendi tabella'"></span>
                    </button>
                </div>

                {{-- Modale Create / Edit --}}
                <div x-show="showModal" x-cloak class="fixed inset-0 z-50 flex items-center justify-center">
                    <div class="absolute inset-0 bg-black opacity-75"></div>
                    <div class="relative z-10 w-full max-w-3xl">
                        <x-customer-create-modal :customers="$customers" />
                    </div>
                </div>             

                {{-- Tabella espandibile --}}
                <div class="overflow-x-auto p-4">
                    <table class="table-auto min-w-full text-sm divide-y divide-gray-200 dark:divide-gray-700">
                        <thead class="bg-gray-300 dark:bg-gray-700">
                            <tr class="uppercase tracking-wider">
                                <th class="px-6 py-2 text-left">#</th>
                                <x-th-menu
                                    field="company"
                                    label="Cliente"
                                    :sort="$sort"
                                    :dir="$dir"
                                    :filters="$filters"
                                    :filterable="true"
                                    reset-route="customers.index"
                                    align="left"
                                />
                                <th class="px-6 py-2 text-left">Città</th>
                                <th class="px-6 py-2 text-left">Note</th>
                                <th class="px-6 py-2 text-left">Email</th>
                                <th class="px-6 py-2 text-left">Telefono</th>
                                <th class="px-6 py-2 text-center">Attivo</th>

                                {{-- Colonne indirizzi, visibili solo se extended --}}
                                <th x-show="extended" x-cloak class="px-6 py-2 text-left whitespace-nowrap">Indirizzo Fatturazione</th>
                                <th x-show="extended" x-cloak class="px-6 py-2 text-left whitespace-nowrap">Indirizzo Spedizione</th>
                                <th x-show="extended" x-cloak class="px-6 py-2 text-left whitespace-nowrap">Altro Indirizzo</th>
                            </tr>
                        </thead>

                        <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                            @foreach($customers as $customer)
                                @php
                                    $canEdit   = auth()->user()->can('customers.update');
                                    $canDelete = auth()->user()->can('customers.delete');
                                    $canCrud   = $canEdit || $canDelete;

                                    // indirizzo fatturazione e “altro” (li prendo ancora dalla relazione)
                                    $b = $customer->addresses->firstWhere('type','billing');
                                    $o = $customer->addresses->firstWhere('type','other');

                                    // indirizzo di spedizione “srotolato” dal join
                                    $sa = $customer->shipping_address;
                                    $sc = $customer->shipping_city;
                                    $sp = $customer->shipping_postal_code;
                                    $sn = $customer->shipping_country;

                                    // CHIAVE UNICA DI RIGA: prefisso 'row-' per evitare ambiguità con numeri
                                    $rowKey = 'row-' . $customer->shipping_address_id;
                                @endphp

                                {{-- Riga principale --}}
                                <tr
                                    @if($canCrud)
                                        @click="openId = (openId === '{{ $rowKey }}' ? null : '{{ $rowKey }}')"
                                        class="cursor-pointer hover:bg-gray-200 dark:hover:bg-gray-700"
                                        :class="openId === '{{ $rowKey }}' ? 'bg-gray-200 dark:bg-gray-700' : ''"
                                    @endif
                                >
                                    <td class="px-6 py-2 whitespace-nowrap">{{ $loop->iteration + ($customers->currentPage()-1)*$customers->perPage() }}</td>
                                    <td class="px-6 py-2 whitespace-nowrap">{{ $customer->company }}</td>
                                    <td class="px-6 py-2 whitespace-nowrap">{{ $sc ?? '—' }}</td>
                                    <td class="px-6 py-2 whitespace-nowrap">{{ \Illuminate\Support\Str::limit($customer->notes, 30) ?? '—' }}</td>
                                    <td class="px-6 py-2 whitespace-nowrap">{{ $customer->email ?? '—' }}</td>
                                    <td class="px-6 py-2 whitespace-nowrap">{{ $customer->phone ?? '—' }}</td>
                                    <td class="px-6 py-2 text-center whitespace-nowrap">
                                        <span
                                            class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium"
                                            :class="{
                                                'bg-green-100 text-green-800': {{ $customer->is_active ? 'true' : 'false' }},
                                                'bg-red-100 text-red-800': {{ $customer->is_active ? 'false' : 'true' }}
                                            }"
                                        >
                                            {{ $customer->is_active ? 'Sì' : 'No' }}
                                        </span>
                                    </td>

                                    {{-- Colonne indirizzi, visibili solo se extended --}}
                                    <td x-show="extended" x-cloak class="px-6 py-2 whitespace-nowrap">
                                        @if($b)
                                            {{ $b->address }}, {{ $b->city }}, {{ $b->country }}
                                        @else
                                            —
                                        @endif
                                    </td>
                                    <td x-show="extended" x-cloak class="px-6 py-2 whitespace-nowrap">
                                        @if($sa)
                                            {{ $sa }}, {{ $sc }}, {{ $sn }}
                                        @else
                                            —
                                        @endif
                                    </td>
                                    <td x-show="extended" x-cloak class="px-6 py-2 whitespace-nowrap">
                                        @if($o)
                                            {{ $o->address }}, {{ $o->city }}, {{ $o->country }}
                                        @else
                                            —
                                        @endif
                                    </td>
                                </tr>

                                {{-- Riga espansa con Modifica / Elimina / Estendi --}}
                                @if($canCrud)
                                    <tr x-show="openId === '{{ $rowKey }}'" x-cloak>
                                        <td
                                            :colspan="extended ? 10 : 7"
                                            class="px-6 py-3 bg-gray-200 dark:bg-gray-700"
                                        >
                                            <div class="flex items-center space-x-4 text-xs">
                                                @if($canEdit)
                                                    <button
                                                        type="button"
                                                        @click='openEdit(@json($customer))'
                                                        class="inline-flex items-center hover:text-yellow-600"
                                                    >
                                                        <i class="fas fa-pencil-alt mr-1"></i> Modifica
                                                    </button>
                                                @endif

                                                @if($canDelete)
                                                    <form
                                                        action="{{ route('customers.destroy', $customer) }}"
                                                        method="POST"
                                                        onsubmit="return confirm('Sei sicuro di voler eliminare questo cliente?');"
                                                    >
                                                        @csrf
                                                        @method('DELETE')
                                                        <button type="submit" class="inline-flex items-center hover:text-red-600">
                                                            <i class="fas fa-trash-alt mr-1"></i> Elimina
                                                        </button>
                                                    </form>
                                                @endif
                                            </div>
                                        </td>
                                    </tr>
                                @endif
                            @endforeach
                            @if($customers->isEmpty())
                                <tr>
                                    <td :colspan="extended ? 10 : 7" x-cloak class="px-6 py-4 text-center text-gray-500">
                                        Nessun cliente trovato.
                                    </td>
                                </tr>
                            @endif
                        </tbody>
                    </table>
                </div>

                {{-- Paginazione --}}
                <div class="mt-4 px-6 py-2">
                    {{ $customers->links('vendor.pagination.tailwind-compact') }}
                </div>
            </div>
        </div>
    </div>

    @push('scripts')
    <script>
    document.addEventListener('alpine:init', () => {
        Alpine.data('customerCrud', () => ({
            // Modal
            showModal: false,
            mode: 'create',
            form: { 
                id: null, 
                company: '', 
                email: '', 
                phone: '', 
                is_active: true, 
                notes: '',
                addresses: [] 
            },
            errors: {},

            // Per riga espansa e colonne aggiuntive
            openId: null,
            extended: false,

            openCreate() {
                this.resetForm();
                this.mode = 'create';
                this.showModal = true;
            },

            openEdit(customer) {
                this.mode = 'edit';
                this.form.id         = customer.id;
                this.form.company    = customer.company;
                this.form.email      = customer.email      ?? '';
                this.form.phone      = customer.phone      ?? '';
                this.form.is_active  = customer.is_active;
                this.form.notes      = customer.notes      ?? '';
                this.form.addresses  = customer.addresses.map(a => ({
                    type:         a.type,
                    address:      a.address,
                    city:         a.city,
                    postal_code:  a.postal_code,
                    country:      a.country,
                }));
                this.errors = {};
                this.showModal = true;
            },

            resetForm() {
                this.form = { 
                    id: null, 
                    company: '', 
                    email: '', 
                    phone: '', 
                    is_active: true, 
                    notes: '',
                    addresses: [] 
                };
                this.errors = {};
            },

            validateCustomer() {
                this.errors = {};
                let valid = true;
                if (! this.form.company.trim()) {
                    this.errors.company = 'Il nome è obbligatorio.';
                    valid = false;
                }
                return valid;
            },

            init() {
                @if($errors->any())
                    this.showModal = true;
                    this.mode = '{{ old('_method','create') === 'PUT' ? 'edit' : 'create' }}';
                    this.errors = @json($errors->toArray());
                    this.form = {
                        id:         {{ old('id', 'null') }},
                        company:    '{{ old('company', '') }}',
                        email:      '{{ old('email', '') }}',
                        phone:      '{{ old('phone', '') }}',
                        is_active:  {{ old('is_active', true) ? 'true' : 'false' }},
                        notes:      @json(old('notes', '')),
                        addresses:  @json(old('addresses', [])),
                    };
                @endif
            },

        }));
    });
    </script>
    @endpush
</x-app-layout>