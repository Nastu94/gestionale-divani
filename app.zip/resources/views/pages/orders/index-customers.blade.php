{{-- resources/views/pages/orders/index-customers.blade.php --}}

<x-app-layout>
    {{-- ========== HEADER ========== --}}
    <x-slot name="header">
        <div class="flex flex-wrap items-center justify-between">
            <h2 class="font-semibold text-lg text-gray-800 dark:text-gray-200 leading-tight">
                {{ __('Ordini Cliente') }}
            </h2>
            <x-dashboard-tiles />
        </div>

        {{-- alert successo --}}
        @if (session('success'))
            <div  x-data="{ show: true }"
                  x-init="setTimeout(() => show = false, 10000)"
                  x-show="show"
                  x-transition.opacity.duration.500ms
                  class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mt-2"
                  role="alert">
                <i class="fas fa-check-circle mr-1"></i>
                <span class="block sm:inline">{{ session('success') }}</span>
            </div>
        @endif

        {{-- alert errore --}}
        @if (session('error'))
            <div  x-data="{ show: true }"
                  x-init="setTimeout(() => show = false, 10000)"
                  x-show="show"
                  x-transition.opacity.duration.500ms
                  class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mt-2"
                  role="alert">
                <i class="fas fa-exclamation-triangle mr-1"></i>
                <span class="block sm:inline">{{ session('error') }}</span>
            </div>
        @endif
    </x-slot>

    {{-- ========== MAIN ========== --}}
    <div class="py-6">
        <div  x-data="{
                    openId: null,

                    init() {
                        let openOrder = {{ request()->query('open_order', 'null') }};
                        if (openOrder) {
                            this.openSidebar(openOrder, 'Dettaglio da Alert');
                        }
                    },

                    /*
                    * ID degli ordini selezionati nella tabella.
                    * La selezione vale per la pagina corrente.
                    */
                    selectedOrderIds: [],

                    /*
                    * ID visibili nella pagina corrente della paginazione.
                    * Servono per la checkbox master nell'head.
                    */
                    pageOrderIds: @js($orders->pluck('id')->map(fn ($id) => (int) $id)->values()),

                    /*
                    * Verifica se una riga è selezionata.
                    */
                    isSelected(id) {
                        return this.selectedOrderIds.includes(Number(id));
                    },

                    /*
                    * Seleziona o deseleziona una singola riga.
                    */
                    toggleOrder(id) {
                        id = Number(id);

                        if (this.isSelected(id)) {
                            this.selectedOrderIds = this.selectedOrderIds.filter(selectedId => selectedId !== id);
                            return;
                        }

                        this.selectedOrderIds.push(id);
                    },

                    /*
                    * Numero totale di righe selezionate.
                    */
                    get selectedCount() {
                        return this.selectedOrderIds.length;
                    },

                    /*
                    * Numero di righe visibili selezionate nella pagina corrente.
                    */
                    get visibleSelectedCount() {
                        return this.pageOrderIds.filter(id => this.isSelected(id)).length;
                    },

                    /*
                    * True quando tutte le righe visibili sono selezionate.
                    */
                    get allVisibleSelected() {
                        return this.pageOrderIds.length > 0
                            && this.visibleSelectedCount === this.pageOrderIds.length;
                    },

                    /*
                    * Seleziona o deseleziona tutte le righe visibili.
                    */
                    toggleVisibleRows() {
                        const visibleIds = this.pageOrderIds.map(id => Number(id));

                        if (this.allVisibleSelected) {
                            this.selectedOrderIds = this.selectedOrderIds.filter(id => !visibleIds.includes(Number(id)));
                            return;
                        }

                        this.selectedOrderIds = Array.from(new Set([
                            ...this.selectedOrderIds.map(id => Number(id)),
                            ...visibleIds,
                        ]));
                    },

                    /*
                    * Invia il form nascosto verso la pagina di stampa.
                    */
                    printSelectedOrders() {
                        if (this.selectedCount === 0) {
                            return;
                        }

                        this.$nextTick(() => {
                            this.$refs.printSelectedOrdersForm.submit();
                        });
                    },
                    openCreate() {
                        window.dispatchEvent(new CustomEvent('open-customer-order-modal'))
                    },
                    openEdit(id) {
                        window.dispatchEvent(
                            new CustomEvent('open-customer-order-modal', { detail: { orderId: id } })
                        )
                    },
                    sidebarOpen        : false,
                    sidebarLines       : [],
                    sidebarOrderNumber : null,
                    sidebarLoading     : false,
                    sidebarNote        : null,
                    sidebarReason      : null,
                    sidebarReference   : null,
                    sidebarPackages    : null,
                    formatCurrency(v)  { return Intl.NumberFormat('it-IT', { minimumFractionDigits: 2 }).format(v) },
                    openSidebar(id, num) {
                        this.sidebarOpen        = true
                        this.sidebarLoading     = true
                        this.sidebarLines       = []
                        this.sidebarOrderNumber = num
                        this.sidebarNote        = null
                        this.sidebarReason      = null
                        this.sidebarReference   = null
                        this.sidebarPackages    = null

                        fetch(`/orders/customer/${id}/lines`, {
                            headers     : { Accept: 'application/json' },
                            credentials : 'same-origin'
                        })
                        .then(r => { if (!r.ok) throw new Error('Errore ' + r.status); return r.json() })
                        .then(js => {
                            // Compat: se è un array (vecchio), usa come rows; altrimenti usa il nuovo oggetto
                            if (Array.isArray(js)) {
                                this.sidebarLines      = js;
                                this.sidebarNote       = null;
                                this.sidebarReason     = null;
                                this.sidebarReference  = null;
                                this.sidebarPackages   = null;
                            } else {
                                this.sidebarLines      = Array.isArray(js.rows) ? js.rows : [];
                                this.sidebarNote       = js.note ?? null;
                                this.sidebarReason     = js.reason ?? null;
                                this.sidebarReference  = js.reference ?? null;
                                this.sidebarPackages   = js.packages ?? null;
                            }
                            this.sidebarLoading = false;
                        })
                        .catch(e => {
                            alert('Impossibile caricare i dettagli ordine');
                            console.error(e);
                            this.sidebarLoading = false;
                        });
                    },
                }"
                class="max-w-full mx-auto sm:px-6 lg:px-8"
        >
            <div class="bg-white dark:bg-gray-800 shadow sm:rounded-lg">

                {{-- Toolbar --}}
                <div class="flex flex-wrap items-center justify-between gap-2 m-2 p-2">

                    {{-- Form nascosto per stampare le righe selezionate --}}
                    @can('orders.customer.view')
                        <form  x-ref="printSelectedOrdersForm"
                            method="POST"
                            action="{{ route('orders.customer.print.selected') }}"
                            target="_blank"
                            class="hidden">
                            @csrf

                            <template x-for="id in selectedOrderIds" :key="'selected-order-' + id">
                                <input type="hidden" name="ids[]" :value="id">
                            </template>
                        </form>

                        <div x-show="selectedCount > 0"
                            x-cloak
                            class="inline-flex items-center gap-3 rounded-md border border-purple-200 bg-purple-50 px-3 py-2 text-xs text-purple-900">
                            
                            <span>
                                <strong x-text="selectedCount"></strong>
                                <span x-text="selectedCount === 1 ? 'riga selezionata' : 'righe selezionate'"></span>
                            </span>

                            <button type="button"
                                    @click.stop="printSelectedOrders"
                                    class="inline-flex items-center rounded-md bg-purple-600 px-3 py-1.5 font-semibold uppercase text-white hover:bg-purple-500 focus:outline-none focus:ring-2 focus:ring-purple-300">
                                <i class="fas fa-print mr-1"></i>
                                Stampa selezionate
                            </button>
                        </div>
                    @endcan

                    <div class="flex justify-end">
                        @can('orders.customer.create')
                            <button  @click="openCreate"
                                    class="inline-flex items-center m-2 px-3 py-1.5 bg-purple-600 rounded-md
                                            text-xs font-semibold text-white uppercase hover:bg-purple-500
                                            focus:outline-none focus:ring-2 focus:ring-purple-300 transition">
                                <i class="fas fa-plus mr-1"></i> Nuovo
                            </button>
                        @endcan
                    </div>
                </div>

                {{-- ====== TABELLA ====== --}}
                <div class="overflow-x-auto p-4">
                    <table class="table-auto min-w-full text-sm divide-y divide-gray-200 dark:divide-gray-700">
                        <thead class="bg-gray-300 dark:bg-gray-700 uppercase tracking-wider">
                            <tr>
                                <th class="px-3 py-2 text-center w-12">
                                    <label class="inline-flex items-center justify-center gap-1 cursor-pointer"
                                        title="Seleziona le righe visibili">
                                        <input type="checkbox"
                                            class="rounded border-gray-300 text-purple-600 focus:ring-purple-500"
                                            :checked="allVisibleSelected"
                                            :indeterminate.prop="visibleSelectedCount > 0 && !allVisibleSelected"
                                            @click.stop="toggleVisibleRows">

                                        <span class="text-[10px] normal-case"
                                            x-show="selectedCount > 0"
                                            x-text="'(' + selectedCount + ')'">
                                        </span>
                                    </label>
                                </th>
                                <x-th-menu field="id" label="Ordine #"
                                           :sort="$sort" :dir="$dir" :filters="$filters"
                                           reset-route="orders.customer.index"
                                           :filterable="false" align="left" />
                                <x-th-menu field="customer" label="Cliente"
                                           :sort="$sort" :dir="$dir" :filters="$filters"
                                           reset-route="orders.customer.index" />
                                <th>Indirizzo Spedizione</th>
                                <x-th-menu field="reference" label="Riferimento"
                                           :sort="$sort" :dir="$dir" :filters="$filters"
                                           reset-route="orders.customer.index" />
                                <x-th-menu field="ordered_at" label="Data Ordine"
                                           :sort="$sort" :dir="$dir" :filters="$filters"
                                           reset-route="orders.customer.index"
                                           :filterable="false" />
                                <x-th-menu field="delivery_date" label="Data Consegna"
                                           :sort="$sort" :dir="$dir" :filters="$filters"
                                           reset-route="orders.customer.index"
                                           :filterable="false" />
                                <x-th-menu field="total" label="Valore (€)"
                                           :sort="$sort" :dir="$dir" :filters="$filters"
                                           reset-route="orders.customer.index"
                                           :filterable="false" align="left" />
                                <th>Stato</th>
                            </tr>
                        </thead>

                        <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                            @foreach ($orders as $order)
                                @php
                                    $started      = (bool) $order->has_started_prod;          // nuovo flag
                                    $canEdit      = auth()->user()->can('orders.customer.update')  && ! $started;
                                    $canDelete    = auth()->user()->can('orders.customer.delete')  && ! $started;
                                    $canCrud      = $canEdit || $canDelete;                   // apre/chiude toolbar
                                    //dd(config('orders.modifiable_occasional_roles', []), auth()->user()->roles->pluck('name')->toArray(), auth()->user()->can('update', $order));
                                @endphp

                                {{-- RIGA PRINCIPALE --}}
                                <tr  @if ($canCrud || auth()->user()->can('orders.customer.view'))
                                         @click="openId = (openId === {{ $order->id }} ? null : {{ $order->id }})"
                                         class="cursor-pointer hover:bg-gray-200 dark:hover:bg-gray-700"
                                         :class="openId === {{ $order->id }} ? 'bg-gray-200 dark:bg-gray-700' : ''"
                                     @endif
                                >
                                    <td class="px-3 py-2 text-center">
                                        <input type="checkbox"
                                            class="rounded border-gray-300 text-purple-600 focus:ring-purple-500"
                                            :checked="isSelected({{ $order->id }})"
                                            @click.stop="toggleOrder({{ $order->id }})">
                                    </td>
                                    <td class="px-6 py-2 text-center">
                                        {{ $order->orderNumber->number }}
                                        @if ($order->has_started_prod)
                                            <i class="fas fa-industry text-xs text-purple-600 ml-1" title="Produzione in corso"></i>
                                        @endif
                                    </td>
                                    <td class="px-6 py-2">
                                        {{ $order->customer      ? $order->customer->company
                                        : ($order->occasionalCustomer->company ?? '—') }}
                                    </td>
                                    <td class="px-6 py-2">
                                        {{ $order->shipping_address ?? '—' }}
                                    </td>
                                    <td class="px-6 py-2">
                                        {{ $order->reference ?? '—' }}
                                    </td>
                                    <td class="px-6 py-2">{{ $order->ordered_at?->format('d/m/Y') }}</td>
                                    <td class="px-6 py-2">{{ $order->delivery_date?->format('d/m/Y') }}</td>
                                    <td class="px-6 py-2 text-center">{{ number_format($order->total, 2, ',', '.') }}</td>
                                    <td class="px-6 py-2 whitespace-nowrap">
                                        @if ($order->status == 0 && $order->reason === null)
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">
                                                Non confermato
                                            </span>
                                        @elseif ($order->status == 0 && $order->reason !== null)
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">
                                                Rifiutato
                                            </span>
                                        @elseif ($order->status == 1)
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                                Confermato
                                            </span>
                                        @endif
                                    </td>
                                </tr>

                                {{-- RIGA ESPANSA CON AZIONI --}}
                                @if ($canCrud || auth()->user()->can('orders.customer.view'))
                                    <tr x-show="openId === {{ $order->id }}" x-cloak>
                                        <td :colspan="9" class="px-6 py-3 bg-gray-200 dark:bg-gray-700">
                                            <div class="flex items-center space-x-4 text-xs">

                                                {{-- Visualizza --}}
                                                @can('orders.customer.view')
                                                    <button type="button"
                                                            @click.stop="openSidebar({{ $order->id }}, {{ $order->number }})"
                                                            class="inline-flex items-center hover:text-blue-600">
                                                        <i class="fas fa-eye mr-1"></i> Visualizza
                                                    </button>
                                                @endcan

                                                {{-- Modifica --}}
                                                @if(auth()->user()->can('update', $order) || $order->status == 0)
                                                    @if ($canEdit)
                                                        <button  type="button"
                                                                @click.stop="openEdit({{ $order->id }})"
                                                                class="inline-flex items-center hover:text-green-600">
                                                            <i class="fas fa-pen mr-1"></i> Modifica
                                                        </button>
                                                    @endif
                                                @endcan

                                                @can('orders.customer.update')
                                                    @if (is_null($order->occasional_customer_id) && (int) $order->status === 0)
                                                        <form method="POST"
                                                            action="{{ route('orders.customer.confirm.manual', $order) }}"
                                                            onsubmit="return confirm('Confermare manualmente questo ordine?');"
                                                            class="inline">
                                                            @csrf

                                                            <button type="submit"
                                                                    class="inline-flex items-center hover:text-green-700">
                                                                <i class="fas fa-circle-check mr-1"></i> Conferma
                                                            </button>
                                                        </form>
                                                    @endif
                                                @endcan
                                                
                                                {{-- 🖨 Etichetta --}}
                                                @can('orders.customer.view')
                                                    @php
                                                        $labelUrl = \Illuminate\Support\Facades\URL::temporarySignedRoute(
                                                            'orders.customer.label.print',
                                                            now()->addMinutes(5),
                                                            ['order' => $order->id]
                                                        );
                                                    @endphp

                                                    <button type="button"
                                                            @click.stop="
                                                                const w = window.open('{{ $labelUrl }}', '_blank', 'noopener,noreferrer');
                                                                if (!w) alert('Popup bloccato: consenti i popup per stampare l’etichetta.');
                                                            "
                                                            class="inline-flex items-center hover:text-purple-600">
                                                        <i class="fas fa-tag mr-1"></i> Stampa etichetta
                                                    </button>
                                                @endcan

                                                {{-- Cancella --}}
                                                @if ($canDelete)
                                                    <form  method="POST"
                                                           action="{{ route('orders.customer.destroy', $order) }}"
                                                           onsubmit="return confirm('Sei sicuro di voler eliminare quest\'ordine?')"
                                                           class="inline">
                                                        @csrf @method('DELETE')
                                                        <button type="submit"
                                                                class="inline-flex items-center hover:text-red-600">
                                                            <i class="fas fa-trash mr-1"></i> Elimina
                                                        </button>
                                                    </form>
                                                @endif
                                            </div>
                                        </td>
                                    </tr>
                                @endif
                            @endforeach

                            {{-- RIGA NESSUN RISULTATO --}}
                            @if ($orders->isEmpty())
                                <tr>
                                    <td colspan="9" class="px-6 py-2 text-center text-gray-500">Nessun risultato trovato.</td>
                                </tr>
                            @endif
                        </tbody>
                    </table>
                </div>

                {{-- PAGINAZIONE --}}
                <div class="mt-4">
                    {{ $orders->links('vendor.pagination.tailwind-compact') }}
                </div>
            </div>

            {{-- Modale per creazione/modifica ordine --}}
            <x-customer-order-create-modal />

            {{-- ===== OVERLAY SIDEBAR RIGHE ORDINE ===== --}}
            <div  x-show="sidebarOpen"
                  x-cloak
                  class="fixed inset-0 flex z-50"
                  x-transition.opacity>
                {{-- backdrop --}}
                <div class="flex-1 bg-black/50" @click="sidebarOpen = false"></div>

                {{-- pannello --}}
                <div  class="w-full max-w-2xl bg-white dark:bg-gray-900 shadow-xl overflow-y-auto"
                      x-transition:enter="transition transform duration-300"
                      x-transition:enter-start="translate-x-full"
                      x-transition:leave="transition transform duration-300"
                      x-transition:leave-end="translate-x-full"
                >
                    <div class="p-6 border-b flex justify-between items-center">
                        <h3 class="text-lg font-semibold">
                            Righe ordine # <span x-text="sidebarOrderNumber"></span>
                        </h3>
                        <button @click="sidebarOpen = false">
                            <i class="fas fa-times text-gray-600"></i>
                        </button>
                    </div>

                    {{-- spinner overlay --}}
                    <div  x-show="sidebarLoading"
                          x-transition.opacity
                          x-cloak
                          class="absolute inset-0 flex items-center justify-center bg-white/70">
                        <i class="fas fa-circle-notch fa-spin text-3xl text-gray-600"></i>
                    </div>

                    {{-- NEW: Meta (Note / Ragione rifiuto) --}}
                    <div class="p-4 space-y-3">
                        {{-- Note ordine --}}
                        <template x-if="sidebarNote">
                            <div class="rounded border border-purple-200 bg-purple-50/70 p-3">
                                <div class="flex items-center gap-2 mb-1">
                                    <i class="fas fa-sticky-note text-purple-600"></i>
                                    <span class="font-semibold">Note ordine</span>
                                </div>
                                <p class="text-sm text-purple-900 whitespace-pre-line" x-text="sidebarNote"></p>
                            </div>
                        </template>

                        {{-- Numero colli --}}
                        <template x-if="sidebarPackages">
                            <div class="rounded border border-blue-200 bg-blue-50 p-3">
                                <div class="flex items-center gap-2 mb-1">
                                    <i class="fas fa-box text-blue-600"></i>
                                    <span class="font-semibold">Numero colli</span>
                                </div>
                                <p class="text-sm text-blue-900" x-text="sidebarPackages"></p>
                            </div>
                        </template>

                        {{-- Ragione rifiuto --}}
                        <template x-if="sidebarReason">
                            <div class="rounded border border-rose-200 bg-rose-50 p-3">
                                <div class="flex items-center gap-2 mb-1">
                                    <i class="fas fa-triangle-exclamation text-rose-600"></i>
                                    <span class="font-semibold">Ragione del rifiuto</span>
                                </div>
                                <p class="text-sm text-rose-900 whitespace-pre-line" x-text="sidebarReason"></p>
                            </div>
                        </template>
                    </div>
                    
                    {{-- tabella righe --}}
                    <div x-show="sidebarLines.length > 0" class="p-4">
                        <table class="w-full text-sm border divide-y">
                            <thead class="bg-gray-100">
                                <tr>
                                    <th class="px-2 py-1">Codice</th>
                                    <th class="px-2 py-1">Articolo</th>
                                    <th class="px-2 py-1 w-14 text-right">Q.tà</th>
                                    <th class="px-2 py-1 w-14">Unit</th>
                                    <th class="px-2 py-1 w-20 text-right">Prezzo</th>
                                    <th class="px-2 py-1 w-24 text-right">Subtot.</th>
                                </tr>
                            </thead>
                            <tbody>
                                <template x-for="(row, idx) in sidebarLines" :key="row.uid ?? (row.code + '-' + idx)">
                                    <tr
                                        :class="{
                                            'font-semibold bg-purple-50' : row.type === 'product',
                                            'text-gray-600 italic text-xs'       : row.type === 'component'
                                        }"
                                    >
                                        <td class="px-2 py-1"
                                            :class="row.type === 'component' ? 'pl-6' : ''"
                                            x-text="row.code">
                                        </td>
                                        <td class="px-2 py-1" x-text="row.desc"></td>
                                        <td class="px-2 py-1 text-right" x-text="row.qty"></td>
                                        <td class="px-2 py-1 uppercase"   x-text="row.unit"></td>
                                        <td class="px-2 py-1 text-right"
                                            x-text="formatCurrency(row.price)">
                                        </td>
                                        <td class="px-2 py-1 text-right"
                                            x-text="formatCurrency(row.subtot)">
                                        </td>
                                    </tr>
                                </template>
                            </tbody>
                        </table>

                        {{-- Riferimento ordine --}}
                        <div class="rounded border border-gray-200 bg-gray-50 p-3">
                            <div class="flex items-center gap-2 mb-1">
                                <i class="fas fa-bookmark text-gray-600"></i>
                                <span class="font-semibold">Riferimento</span>
                            </div>

                            <p class="text-sm text-gray-900 whitespace-pre-line"
                            x-text="sidebarReference || '—'"></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</x-app-layout>
