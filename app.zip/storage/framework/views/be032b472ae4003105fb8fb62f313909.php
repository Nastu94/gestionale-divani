
<div>

    
    <div class="py-2">
        <?php
            $fasi = [
                0 => ['txt' => 'Inserito'      , 'icon' => 'fa-upload'          , 'bg' => 'bg-gray-300 dark:bg-gray-700'],
                1 => ['txt' => 'Cucito'        , 'icon' => 'fa-thumbtack'       , 'bg' => 'bg-indigo-100 dark:bg-indigo-700'],
                2 => ['txt' => 'Assemblaggio'  , 'icon' => 'fa-screwdriver-wrench' , 'bg' => 'bg-purple-100 dark:bg-purple-700'],
                3 => ['txt' => 'Spedizione'    , 'icon' => 'fa-truck'           , 'bg' => 'bg-red-100   dark:bg-red-700'],
            ];
        ?>

        <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-2">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $fasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $sel = $phase === $idx; ?>
                <div  tabindex="0"
                    wire:click="$set('phase', <?php echo e($idx); ?>)"
                    @keydown.enter.prevent="$set('phase', <?php echo e($idx); ?>)"
                    class="cursor-pointer rounded p-3 flex flex-col items-center justify-center
                            <?php echo e($d['bg']); ?>

                            <?php echo e($sel ? 'ring-2 ring-indigo-500 scale-105 transition transform' : ''); ?>">
                    <i class="fas <?php echo e($d['icon']); ?> text-xl mb-1"></i>
                    <span class="text-xs font-semibold"><?php echo e($d['txt']); ?></span>
                    <span class="text-lg font-bold"><?php echo e($kpiCounts[$idx] ?? 0); ?></span>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>
    
    
    <?php if (isset($component)) { $__componentOriginal5168fdb0c14fd91c6598264bc4be63f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5168fdb0c14fd91c6598264bc4be63f2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.flash','data' => ['canForceReservation' => $canForceReservation,'forceMissingComponents' => $forceMissingComponents]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flash'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['canForceReservation' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($canForceReservation),'forceMissingComponents' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($forceMissingComponents)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5168fdb0c14fd91c6598264bc4be63f2)): ?>
<?php $attributes = $__attributesOriginal5168fdb0c14fd91c6598264bc4be63f2; ?>
<?php unset($__attributesOriginal5168fdb0c14fd91c6598264bc4be63f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5168fdb0c14fd91c6598264bc4be63f2)): ?>
<?php $component = $__componentOriginal5168fdb0c14fd91c6598264bc4be63f2; ?>
<?php unset($__componentOriginal5168fdb0c14fd91c6598264bc4be63f2); ?>
<?php endif; ?>

    
    <div class="py-6" x-data="exitCrud()" @open-row.window="openId = ($event.detail === openId ? null : $event.detail)" @close-row.window="openId = null">
        <div class="max-w-full mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 shadow sm:rounded-lg">
                <div class="p-4 overflow-x-auto">
                    <?php
                        /*
                        * ID visibili nella pagina corrente.
                        * Servono per la checkbox master nell'head.
                        */
                        $visibleExitRowIds = $exitRows
                            ->pluck('id')
                            ->map(fn ($id) => (int) $id)
                            ->values();

                        /*
                        * Selezione corrente normalizzata.
                        */
                        $selectedExitIds = collect($selectedExitRowIds ?? [])
                            ->map(fn ($id) => (int) $id)
                            ->values();

                        /*
                        * Conteggio righe visibili selezionate.
                        */
                        $visibleSelectedCount = $visibleExitRowIds
                            ->filter(fn ($id) => $selectedExitIds->contains($id))
                            ->count();

                        /*
                        * True quando tutte le righe visibili sono selezionate.
                        */
                        $allVisibleSelected = $visibleExitRowIds->isNotEmpty()
                            && $visibleSelectedCount === $visibleExitRowIds->count();

                        /*
                        * Conteggio totale selezionate nello stato Livewire.
                        */
                        $selectedCount = $selectedExitIds->count();
                    ?>
                    
                    <div class="flex flex-wrap items-center justify-between gap-2 mb-2">

                        
                        <div>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($selectedCount > 0): ?>
                                <div class="inline-flex items-center gap-3 rounded-md border border-purple-200 bg-purple-50 px-3 py-2 text-xs text-purple-900">
                                    <span>
                                        <strong><?php echo e($selectedCount); ?></strong>
                                        <?php echo e($selectedCount === 1 ? 'riga selezionata' : 'righe selezionate'); ?>

                                    </span>

                                    <button type="button"
                                            wire:click="printSelectedRows"
                                            wire:loading.attr="disabled"
                                            wire:target="printSelectedRows"
                                            class="inline-flex items-center rounded-md bg-purple-600 px-3 py-1.5
                                                font-semibold uppercase text-white hover:bg-purple-500
                                                focus:outline-none focus:ring-2 focus:ring-purple-300
                                                disabled:opacity-60">
                                        <span wire:loading.remove wire:target="printSelectedRows">
                                            <i class="fas fa-print mr-1"></i>
                                            Stampa selezionate
                                        </span>

                                        <span wire:loading wire:target="printSelectedRows">
                                            <i class="fas fa-circle-notch fa-spin mr-1"></i>
                                            Preparazione...
                                        </span>
                                    </button>

                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($phase == 3): ?>
                                        <button type="button"
                                                wire:click="generateAccorpatoDdt"
                                                wire:loading.attr="disabled"
                                                wire:target="generateAccorpatoDdt"
                                                class="inline-flex items-center rounded-md bg-green-600 px-3 py-1.5
                                                    font-semibold uppercase text-white hover:bg-green-500
                                                    focus:outline-none focus:ring-2 focus:ring-green-300
                                                    disabled:opacity-60 ml-2">
                                            <span wire:loading.remove wire:target="generateAccorpatoDdt">
                                                <i class="fas fa-object-group mr-1"></i>
                                                Genera DDT Accorpato
                                            </span>

                                            <span wire:loading wire:target="generateAccorpatoDdt">
                                                <i class="fas fa-circle-notch fa-spin mr-1"></i>
                                                Generazione...
                                            </span>
                                        </button>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                    <button type="button"
                                            wire:click="clearSelectedExitRows"
                                            class="inline-flex items-center hover:text-red-600">
                                        <i class="fas fa-times mr-1"></i>
                                        Annulla
                                    </button>
                                </div>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>

                        
                        <div>
                            <button wire:click="$refresh"
                                    class="inline-flex items-center px-3 py-1.5
                                        bg-indigo-600 hover:bg-indigo-500
                                        text-xs font-semibold text-white rounded-md">

                                <i class="fas fa-sync-alt mr-1"></i> Aggiorna

                                <span wire:loading.inline wire:target="$refresh" class="ml-2">
                                    <i class="fas fa-circle-notch fa-spin"></i>
                                </span>
                            </button>
                        </div>
                    </div>
                    
                    
                    <table class="table-auto min-w-full text-sm divide-y divide-gray-200 dark:divide-gray-700">
                        
                        <thead class="bg-gray-300 dark:bg-gray-700 uppercase tracking-wider">
                            <tr>
                                
                                <th class="px-3 py-2 text-center w-12">
                                    <button type="button"
                                            wire:click="toggleVisibleRows(<?php echo \Illuminate\Support\Js::from($visibleExitRowIds->all())->toHtml() ?>)"
                                            class="inline-flex items-center justify-center gap-1"
                                            title="Seleziona le righe visibili">

                                        <input type="checkbox"
                                            class="rounded border-gray-300 text-purple-600 focus:ring-purple-500 pointer-events-none"
                                            <?php if($allVisibleSelected): echo 'checked'; endif; ?>>

                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($selectedCount > 0): ?>
                                            <span class="text-[10px] normal-case">
                                                (<?php echo e($selectedCount); ?>)
                                            </span>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </button>
                                </th>

                                
                                <?php if (isset($component)) { $__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.th-menu-live','data' => ['field' => 'customer','label' => 'Cliente','sort' => $sort,'dir' => $dir,'filters' => $filters,'align' => 'left']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('th-menu-live'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'customer','label' => 'Cliente','sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'dir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dir),'filters' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($filters),'align' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('left')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8)): ?>
<?php $attributes = $__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8; ?>
<?php unset($__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8)): ?>
<?php $component = $__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8; ?>
<?php unset($__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8); ?>
<?php endif; ?>

                                
                                <?php if (isset($component)) { $__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.th-menu-live','data' => ['field' => 'shipping_zone','label' => 'Zona spedizione','sort' => $sort,'dir' => $dir,'filters' => $filters,'align' => 'left']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('th-menu-live'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'shipping_zone','label' => 'Zona spedizione','sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'dir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dir),'filters' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($filters),'align' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('left')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8)): ?>
<?php $attributes = $__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8; ?>
<?php unset($__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8)): ?>
<?php $component = $__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8; ?>
<?php unset($__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8); ?>
<?php endif; ?>

                                
                                <?php if (isset($component)) { $__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.th-menu-live','data' => ['field' => 'order_number','label' => 'Nr. Ordine','sort' => $sort,'dir' => $dir,'filters' => $filters,'align' => 'left']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('th-menu-live'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'order_number','label' => 'Nr. Ordine','sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'dir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dir),'filters' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($filters),'align' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('left')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8)): ?>
<?php $attributes = $__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8; ?>
<?php unset($__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8)): ?>
<?php $component = $__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8; ?>
<?php unset($__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8); ?>
<?php endif; ?>

                                
                                <?php if (isset($component)) { $__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.th-menu-live','data' => ['field' => 'product','label' => 'Prodotto','sort' => $sort,'dir' => $dir,'filters' => $filters,'align' => 'left']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('th-menu-live'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'product','label' => 'Prodotto','sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'dir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dir),'filters' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($filters),'align' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('left')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8)): ?>
<?php $attributes = $__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8; ?>
<?php unset($__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8)): ?>
<?php $component = $__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8; ?>
<?php unset($__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8); ?>
<?php endif; ?>

                                <?php if (isset($component)) { $__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.th-menu-live','data' => ['field' => 'color_note','label' => 'Colore / Nota','sort' => $sort,'dir' => $dir,'filters' => $filters,'align' => 'left']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('th-menu-live'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'color_note','label' => 'Colore / Nota','sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'dir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dir),'filters' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($filters),'align' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('left')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8)): ?>
<?php $attributes = $__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8; ?>
<?php unset($__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8)): ?>
<?php $component = $__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8; ?>
<?php unset($__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8); ?>
<?php endif; ?>

                                
                                <?php if (isset($component)) { $__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.th-menu-live','data' => ['field' => 'order_date','label' => 'Data ordine','sort' => $sort,'dir' => $dir,'filters' => $filters]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('th-menu-live'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'order_date','label' => 'Data ordine','sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'dir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dir),'filters' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($filters)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8)): ?>
<?php $attributes = $__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8; ?>
<?php unset($__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8)): ?>
<?php $component = $__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8; ?>
<?php unset($__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8); ?>
<?php endif; ?>

                                
                                <?php if (isset($component)) { $__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.th-menu-live','data' => ['field' => 'delivery_date','label' => 'Consegna','sort' => $sort,'dir' => $dir,'filters' => $filters]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('th-menu-live'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'delivery_date','label' => 'Consegna','sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'dir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dir),'filters' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($filters)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8)): ?>
<?php $attributes = $__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8; ?>
<?php unset($__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8)): ?>
<?php $component = $__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8; ?>
<?php unset($__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8); ?>
<?php endif; ?>

                                
                                <?php if (isset($component)) { $__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.th-menu-live','data' => ['field' => 'value','label' => 'Valore €','sort' => $sort,'dir' => $dir,'filters' => $filters]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('th-menu-live'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'value','label' => 'Valore €','sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'dir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dir),'filters' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($filters)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8)): ?>
<?php $attributes = $__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8; ?>
<?php unset($__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8)): ?>
<?php $component = $__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8; ?>
<?php unset($__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8); ?>
<?php endif; ?>

                                
                                <?php if (isset($component)) { $__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.th-menu-live','data' => ['field' => 'qty_in_phase','label' => 'Q.ty fase','sort' => $sort,'dir' => $dir,'filters' => $filters,'align' => 'right']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('th-menu-live'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'qty_in_phase','label' => 'Q.ty fase','sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'dir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dir),'filters' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($filters),'align' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('right')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8)): ?>
<?php $attributes = $__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8; ?>
<?php unset($__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8)): ?>
<?php $component = $__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8; ?>
<?php unset($__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8); ?>
<?php endif; ?>
                            </tr>
                        </thead>

                        
                        <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $exitRows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    // permessi grezzi
                                    $canAdvanceRaw  = auth()->user()->can('stock.exit');
                                    $canRollbackRaw = auth()->user()->can('orders.customer.rollback_item_phase');

                                    // logica di fase
                                    $canAdvance  = $canAdvanceRaw  && $phase < 3;   // no “Avanza” se già in Spedizione
                                    $canRollback = $canRollbackRaw && $phase > 0;   // no “Rollback” in Inserito
                                    $showDdT     =                ($phase == 3);    // DdT solo in Spedizione
                                    $showWorkOrder = ($phase < 3);    // Work Order solo se non in Spedizione

                                    $canToggle   = $canAdvance || $canRollback || $showDdT;
                                ?>

                                
                                <tr  wire:key="row-<?php echo e($row->id); ?>"
                                    <?php if($canToggle): ?>
                                         @click="$dispatch('open-row', <?php echo e($row->id); ?>)"
                                         class="cursor-pointer hover:bg-gray-200 dark:hover:bg-gray-700"
                                         :class="openId === <?php echo e($row->id); ?> ? 'bg-gray-200 dark:bg-gray-700' : ''"
                                     <?php endif; ?>
                                >
                                    
                                    <td class="px-3 py-2 text-center">
                                        <input type="checkbox"
                                            value="<?php echo e($row->id); ?>"
                                            wire:model.live="selectedExitRowIds"
                                            wire:key="select-exit-row-<?php echo e($row->id); ?>"
                                            @click.stop
                                            class="rounded border-gray-300 text-purple-600 focus:ring-purple-500">
                                    </td>
                                    
                                    <td class="px-6 py-2 whitespace-nowrap">
                                        <?php echo e($row->customer ?? '—'); ?>

                                    </td>

                                    <td class="px-6 py-2 whitespace-nowrap">
                                        <?php echo e($row->shipping_zone ?? '—'); ?>

                                    </td>

                                    
                                    <td class="px-6 py-2 text-center">
                                        <?php echo e($row->order_number ?? '—'); ?>

                                    </td>

                                    
                                    <td class="px-6 py-2 whitespace-nowrap"
                                        title="<?php echo e($row->product_name); ?>">
                                        <?php echo e($row->product_name ?? '—'); ?>

                                    </td>

                                    
                                    <td class="px-6 py-2 whitespace-nowrap">
                                        <?php
                                            $colName = $row->color_name ?? $row->color_code;
                                            $colNote = $row->color_notes;
                                        ?>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($colName && $colNote): ?>
                                            <?php echo e($colName); ?> - <?php echo e($colNote); ?>

                                        <?php elseif($colName): ?>
                                            <?php echo e($colName); ?>

                                        <?php elseif($colNote): ?>
                                            <?php echo e($colNote); ?>

                                        <?php else: ?>
                                            —
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </td>

                                    
                                    <td class="px-6 py-2  whitespace-nowrap">
                                        <?php echo e(\Carbon\Carbon::parse($row->order_date)->format('Y-m-d') ?? '—'); ?>

                                    </td>
                                    <td class="px-6 py-2 whitespace-nowrap">
                                        <?php echo e(\Carbon\Carbon::parse($row->delivery_date)->format('Y-m-d') ?? '—'); ?>

                                    </td>

                                    
                                    <td class="px-6 py-2 text-right whitespace-nowrap">
                                        € <?php echo e(number_format($row->value, 2, ',', '.')); ?>

                                    </td>
                                    <td class="px-6 py-2 text-right"><?php echo e($row->qty_in_phase); ?></td>
                                </tr>

                                
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($canToggle): ?>
                                    <tr wire:key="tb-<?php echo e($row->id); ?>" x-show="openId === <?php echo e($row->id); ?>" x-cloak>
                                        <td :colspan="10" class="px-6 py-3 bg-gray-200 dark:bg-gray-700">
                                            <div class="flex items-center space-x-4 text-xs">
                                                
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($canAdvance): ?>
                                                    <button type="button"
                                                            class="inline-flex items-center hover:text-green-700"
                                                            wire:click="openAdvance(<?php echo e($row->id); ?>, <?php echo e($row->qty_in_phase); ?>)">
                                                        <i class="fas fa-forward mr-1"></i> Avanza
                                                    </button>
                                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                                
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($canRollback): ?>
                                                    <button type="button"
                                                            class="inline-flex items-center hover:text-amber-600"
                                                            wire:click="openRollback(<?php echo e($row->id); ?>, <?php echo e($row->qty_in_phase); ?>)">
                                                        <i class="fas fa-undo mr-1"></i> Rollback
                                                    </button>
                                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                                
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($showWorkOrder): ?>
                                                    <button type="button"
                                                            class="inline-flex items-center hover:text-purple-600"
                                                            wire:click.stop="printWorkOrder(<?php echo e($row->order_id); ?>)">
                                                        <i class="fas fa-print mr-1"></i> Stampa buono
                                                    </button>

                                                    <button type="button"
                                                            class="inline-flex items-center hover:text-indigo-600"
                                                            wire:click.stop="openWorkOrderDrawer(<?php echo e($row->order_id); ?>)">
                                                        <i class="fas fa-list mr-1"></i> Mostra buono
                                                    </button>
                                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                                
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($showDdT): ?>
                                                    <button type="button"
                                                            class="inline-flex items-center hover:text-purple-600"
                                                            wire:click.stop="openDdtConfirm(<?php echo e($row->id); ?>)">
                                                        <i class="fas fa-print mr-1"></i> Stampa DdT
                                                    </button>

                                                    <button type="button"
                                                            class="inline-flex items-center hover:text-indigo-600"
                                                            wire:click.stop="openDdtDrawer(<?php echo e($row->order_id); ?>)">
                                                        <i class="fas fa-list mr-1"></i> Mostra DDT
                                                    </button>
                                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                            
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($exitRows->isEmpty()): ?>
                                <tr>
                                    <td colspan="10" class="px-6 py-2 text-center text-gray-500">Nessun risultato trovato.</td>
                                </tr>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </tbody>
                    </table>
                </div>

                
                <div class="flex items-center justify-between px-6 py-2">
                    <div>
                        <?php echo e($exitRows->links('vendor.livewire.tailwind-compact')); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <dialog  wire:ignore
            x-data="advanceModal()"
            x-init="
                dlg = $el;                   /*  inizializza subito  */
                window.addEventListener('show-adv-modal', e => open(e.detail))
            "
            @click.outside="close"           
            @keydown.escape.window="close"
            class="rounded-lg shadow-lg w-80 max-w-full p-5
                    bg-white dark:bg-gray-800 backdrop:bg-black/40">

        <h2 class="text-lg font-semibold mb-4">Avanza fase</h2>

        <form @submit.prevent="confirm" class="space-y-4">
            <div>
                <label class="block text-sm mb-1">
                    Quantità (max <span x-text="max"></span>)
                </label>

                <input type="number" step="1" min="1"
                    x-model.number="qty" required 
                    class="w-full border rounded px-2 py-1
                            focus:ring-indigo-500 focus:border-indigo-500">
            </div>

            <div>
                <label class="block text-sm mb-1">
                    Operatore
                </label>
                <input type="text" maxlength="255"
                    x-model.trim="operator"
                    class="w-full border rounded px-2 py-1
                            focus:ring-indigo-500 focus:border-indigo-500">
            </div>

            <div class="flex justify-end gap-2 text-sm">
                <button type="button" @click="close"
                        class="px-3 py-1 bg-gray-300 rounded">Annulla</button>
                <button type="submit"
                        class="px-3 py-1 bg-green-600 text-white rounded">
                    Conferma
                </button>
            </div>
        </form>
    </dialog>

    
    <dialog  wire:ignore.self
            x-data="forceReservationModal()"
            x-init="init()"
            @click.outside="close"
            @keydown.escape.window="close"
            class="rounded-lg shadow-lg w-[44rem] max-w-full p-5
                bg-white dark:bg-gray-800 backdrop:bg-black/40"
    >
        <h2 class="text-lg font-semibold mb-2">Forza prenotazione</h2>
        <p class="text-sm text-gray-600 dark:text-gray-300 mb-4">
            Stai per riallocare componenti per consentire l’avanzamento di fase.
            Prima di confermare, controlla il riepilogo.
        </p>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($forcePlan)): ?>
            <div class="space-y-5 text-sm">

                
                <div>
                    <div class="font-semibold mb-1">Componenti necessari</div>
                    <ul class="list-disc pl-5 space-y-1">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $forcePlan['missing']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <span class="font-semibold"><?php echo e($m['code']); ?></span>
                                — mancano <span class="font-semibold"><?php echo e(rtrim(rtrim(number_format($m['missing'], 4, '.', ''), '0'), '.')); ?></span>
                                <span class="text-xs text-gray-500">
                                    (richiesti: <?php echo e(rtrim(rtrim(number_format($m['needed'], 4, '.', ''), '0'), '.')); ?>,
                                    già prenotati: <?php echo e(rtrim(rtrim(number_format($m['reserved'], 4, '.', ''), '0'), '.')); ?>)
                                </span>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </ul>
                </div>

                
                <div>
                    <div class="font-semibold mb-1">Copertura da giacenza disponibile</div>

                    <?php
                        $freeTotal = 0;
                        foreach (($forcePlan['from_free'] ?? []) as $allocs) {
                            foreach ($allocs as $a) { $freeTotal += (float) $a['qty']; }
                        }
                    ?>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(empty($forcePlan['from_free'])): ?>
                        <div class="text-gray-500">Nessuna giacenza disponibile utilizzabile.</div>
                    <?php else: ?>
                        <div class="text-gray-700 dark:text-gray-200 mb-2">
                            Verranno prenotate da giacenza disponibile:
                            <span class="font-semibold"><?php echo e(rtrim(rtrim(number_format($freeTotal, 4, '.', ''), '0'), '.')); ?></span>
                            unità complessive.
                        </div>

                        
                        <ul class="list-disc pl-5 space-y-1">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $forcePlan['missing']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $cid = $m['component_id'];
                                    $qty = 0;
                                    foreach (($forcePlan['from_free'][$cid] ?? []) as $a) { $qty += (float) $a['qty']; }
                                ?>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($qty > 0): ?>
                                    <li>
                                        <span class="font-semibold"><?php echo e($m['code']); ?></span>
                                        — da giacenza: <?php echo e(rtrim(rtrim(number_format($qty, 4, '.', ''), '0'), '.')); ?>

                                    </li>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </ul>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                
                <div>
                    <div class="font-semibold mb-1">Riallocazione da altri ordini (ordini penalizzati)</div>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(empty($forcePlan['from_donors'])): ?>
                        <div class="text-gray-500">Non è necessario togliere prenotazioni ad altri ordini.</div>
                    <?php else: ?>
                        <p class="text-gray-700 dark:text-gray-200 mb-2">
                            Verranno spostate prenotazioni dai seguenti ordini:
                        </p>

                        
                        <?php
                            $donors = collect($forcePlan['from_donors'])
                                ->groupBy('donor_order_id')
                                ->map(function($rows) {
                                    $first = $rows->first();
                                    $total = $rows->sum('qty');
                                    return [
                                        'order_id'      => $first['donor_order_id'],
                                        'delivery_date' => $first['donor_delivery_date'],
                                        'total'         => (float) $total,
                                        'rows'          => $rows,
                                    ];
                                })->values();
                        ?>

                        <ul class="space-y-2">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $donors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="border rounded p-2">
                                    <div class="flex flex-wrap items-center justify-between gap-2">
                                        <div>
                                            <span class="font-semibold">Ordine #<?php echo e($d['order_id']); ?></span>
                                            <span class="text-xs text-gray-500">
                                                (consegna: <?php echo e($d['delivery_date']); ?>)
                                            </span>
                                        </div>
                                        <div>
                                            Totale riallocato:
                                            <span class="font-semibold"><?php echo e(rtrim(rtrim(number_format($d['total'], 4, '.', ''), '0'), '.')); ?></span>
                                        </div>
                                    </div>

                                    <div class="mt-2 text-xs text-gray-600 dark:text-gray-300">
                                        Dettaglio componenti:
                                        <ul class="list-disc pl-5 mt-1 space-y-1">
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $d['rows']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <span class="font-semibold"><?php echo e($row['code']); ?></span>
                                                    — <?php echo e(rtrim(rtrim(number_format($row['qty'], 4, '.', ''), '0'), '.')); ?>

                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        </ul>
                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </ul>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                
                <div class="text-xs text-gray-600 dark:text-gray-300 border-t pt-3">
                    <span class="font-semibold">Nota:</span>
                    per gli ordini penalizzati verrà generata automaticamente una proposta di approvvigionamento
                    per coprire la nuova mancanza.
                </div>

                
                <div class="flex justify-end gap-2 pt-1">
                    <button type="button"
                            @click="close"
                            class="px-3 py-1 bg-gray-300 rounded">
                        Annulla
                    </button>

                    <button type="button"
                            @click="confirm"
                            class="px-3 py-1 bg-red-600 text-white rounded">
                        Conferma e continua
                    </button>
                </div>
            </div>
        <?php else: ?>
            <div class="text-sm text-gray-500">
                Nessun piano di riallocazione disponibile.
            </div>

            <div class="flex justify-end gap-2 pt-4">
                <button type="button" @click="close" class="px-3 py-1 bg-gray-300 rounded">Chiudi</button>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </dialog>

    
    <dialog  wire:ignore
            x-data="rollbackModal()"
            x-init="
                dlg = $el;                                   /* init subito  */
                window.addEventListener('show-rollback-modal', e => open(e.detail))
            "
            @click.outside="close"                           
            @keydown.escape.window="close"
            class="rounded-lg shadow-lg w-96 max-w-full p-5
                bg-white dark:bg-gray-800 backdrop:bg-black/40">

        <h2 class="text-lg font-semibold mb-4">Rollback fase</h2>

        <form @submit.prevent="confirm" class="space-y-4">

            
            <div>
                <label class="block text-sm mb-1">
                    Quantità (max <span x-text="max"></span>)
                </label>
                <input  type="number" step="1" min="1"
                        x-model.number="qty"
                        class="w-full border rounded px-2 py-1
                            focus:ring-indigo-500 focus:border-indigo-500">
            </div>

            
            <div>
                <label class="block text-sm mb-1">Motivazione rollback *</label>
                <textarea x-model.trim="reason" rows="2"
                        class="w-full border rounded px-2 py-1
                                focus:ring-indigo-500 focus:border-indigo-500"></textarea>
            </div>

            
            <label class="inline-flex items-center text-sm">
                <input type="checkbox" x-model="reuse"
                    class="mr-2 rounded border-gray-300">
                Componenti riutilizzabili (smontaggio)
            </label>

            <div class="flex justify-end gap-2 text-sm pt-2">
                <button type="button" @click="close"
                        class="px-3 py-1 bg-gray-300 rounded">Annulla</button>
                <button type="submit"
                        class="px-3 py-1 bg-amber-600 text-white rounded">
                    Conferma
                </button>
            </div>
        </form>
    </dialog>

    
    <dialog
        wire:ignore.self
        x-data="{ open: <?php if ((object) ('ddtConfirmOpen') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('ddtConfirmOpen'->value()); ?>')<?php echo e('ddtConfirmOpen'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('ddtConfirmOpen'); ?>')<?php endif; ?> }"
        x-effect="open ? $el.showModal?.() : $el.close?.()"
        @close="$wire.closeDdtConfirm()"
        @click.outside="open = false; $wire.closeDdtConfirm()"
        @keydown.escape.window="open = false; $wire.closeDdtConfirm()"
        class="rounded-lg shadow-lg w-[34rem] max-w-full p-5
            bg-white dark:bg-gray-800 backdrop:bg-black/40"
    >
        <div class="flex items-start justify-between mb-4">
            <div>
                <h2 class="text-lg font-semibold">Conferma stampa DDT</h2>
                <p class="text-sm text-gray-500 mt-1">
                    Ordine n. <?php echo e($ddtConfirmOrderNumber ?? '—'); ?>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($ddtConfirmCustomer)): ?>
                        — <?php echo e($ddtConfirmCustomer); ?>

                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </p>
            </div>

            <button type="button"
                    wire:click="closeDdtConfirm"
                    class="px-2 py-1 rounded hover:bg-gray-200 dark:hover:bg-gray-700">
                <i class="fas fa-times"></i>
            </button>
        </div>

        <div class="space-y-4">
            
            <div>
                <label for="ddtConfirmNote" class="block text-sm font-medium mb-1">
                    Note
                </label>

                <textarea
                    id="ddtConfirmNote"
                    wire:model.defer="ddtConfirmNote"
                    rows="4"
                    placeholder="Inserisci eventuali note da riportare sull'ordine / DDT"
                    class="w-full border rounded px-3 py-2
                        focus:ring-indigo-500 focus:border-indigo-500"
                ></textarea>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['ddtConfirmNote'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-xs text-red-600 mt-1"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>

            
            <div>
                <label for="ddtConfirmUnitPriceOverride" class="block text-sm font-medium mb-1">
                    Prezzo unitario override
                </label>

                <input
                    id="ddtConfirmUnitPriceOverride"
                    type="number"
                    step="0.01"
                    min="0"
                    wire:model.defer="ddtConfirmUnitPriceOverride"
                    placeholder="Inserisci il prezzo unitario da usare per il DDT"
                    class="w-full border rounded px-3 py-2
                        focus:ring-indigo-500 focus:border-indigo-500"
                />

                <p class="text-xs text-gray-500 mt-1">
                    Se lasci vuoto, verrà mantenuto il prezzo unitario attuale dell’ordine.
                </p>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['ddtConfirmUnitPriceOverride'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-xs text-red-600 mt-1"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>

        <div class="flex justify-end gap-2 text-sm pt-5">
            <button type="button"
                    wire:click="closeDdtConfirm"
                    class="px-3 py-1 bg-gray-300 rounded">
                Annulla
            </button>

            <button type="button"
                    wire:click="confirmDdtPrint"
                    wire:loading.attr="disabled"
                    wire:target="confirmDdtPrint"
                    class="px-3 py-1 bg-purple-600 text-white rounded hover:bg-purple-500 disabled:opacity-60">
                <span wire:loading.remove wire:target="confirmDdtPrint">Conferma e stampa</span>
                <span wire:loading wire:target="confirmDdtPrint">
                    <i class="fas fa-circle-notch fa-spin mr-1"></i> Generazione...
                </span>
            </button>
        </div>
    </dialog>

    
    <div
        x-data="{ open: <?php if ((object) ('ddtDrawerOpen') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('ddtDrawerOpen'->value()); ?>')<?php echo e('ddtDrawerOpen'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('ddtDrawerOpen'); ?>')<?php endif; ?> }"
        x-show="open"
        x-cloak
        class="fixed inset-0 z-50"
        @keydown.escape.window="open=false; $wire.closeDdtDrawer()"
    >
        
        <div class="absolute inset-0 bg-black/40"
            @click="open=false; $wire.closeDdtDrawer()"></div>

        
        <div class="absolute top-0 right-0 h-full w-full max-w-md bg-white dark:bg-gray-800 shadow-xl">
            <div class="p-4 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between">
                <div>
                    <div class="text-sm font-semibold">DDT ordine</div>
                    <div class="text-xs text-gray-500">
                        Nr. Ordine: <?php echo e($ddtDrawerOrderNumber ?? '—'); ?>

                    </div>
                </div>

                <button type="button"
                        class="px-2 py-1 rounded hover:bg-gray-200 dark:hover:bg-gray-700"
                        @click="open=false; $wire.closeDdtDrawer()">
                    <i class="fas fa-times"></i>
                </button>
            </div>

            <div class="p-4 overflow-y-auto" style="height: calc(100% - 64px);">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(empty($ddtDrawerDdts)): ?>
                    <div class="text-sm text-gray-500">Nessun DDT trovato per questo ordine.</div>
                <?php else: ?>
                    <table class="min-w-full text-sm divide-y divide-gray-200 dark:divide-gray-700">
                        <thead class="bg-gray-100 dark:bg-gray-700 uppercase text-xs">
                            <tr>
                                <th class="px-3 py-2 text-left">Nr.</th>
                                <th class="px-3 py-2 text-left">Data</th>
                                <th class="px-3 py-2 text-right">Azioni</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $ddtDrawerDdts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="px-3 py-2 font-semibold">
                                        <?php echo e($d['number']); ?>/<?php echo e($d['year']); ?>

                                    </td>
                                    <td class="px-3 py-2">
                                        <?php echo e($d['issued_at']); ?>

                                    </td>
                                    <td class="px-3 py-2 text-right">
                                        <button type="button"
                                                class="inline-flex items-center hover:text-purple-600"
                                                wire:click="printExistingDdt(<?php echo e($d['id']); ?>)">
                                            <i class="fas fa-print mr-1"></i> Stampa
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </tbody>
                    </table>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>
    </div>

    
    <div
        x-data="{ open: <?php if ((object) ('woDrawerOpen') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('woDrawerOpen'->value()); ?>')<?php echo e('woDrawerOpen'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('woDrawerOpen'); ?>')<?php endif; ?> }"
        x-show="open"
        x-cloak
        class="fixed inset-0 z-50"
        @keydown.escape.window="open=false; $wire.closeWorkOrderDrawer()"
    >
        <div class="absolute inset-0 bg-black/40"
            @click="open=false; $wire.closeWorkOrderDrawer()"></div>

        <div class="absolute top-0 right-0 h-full w-full max-w-md bg-white dark:bg-gray-800 shadow-xl">
            <div class="p-4 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between">
                <div>
                    <div class="text-sm font-semibold">Buoni ordine</div>
                    <div class="text-xs text-gray-500">
                        Nr. Ordine: <?php echo e($woDrawerOrderNumber ?? '—'); ?> — Fase: <?php echo e($phase); ?>

                    </div>
                </div>

                <button type="button"
                        class="px-2 py-1 rounded hover:bg-gray-200 dark:hover:bg-gray-700"
                        @click="open=false; $wire.closeWorkOrderDrawer()">
                    <i class="fas fa-times"></i>
                </button>
            </div>

            <div class="p-4 overflow-y-auto" style="height: calc(100% - 64px);">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(empty($woDrawerWorkOrders)): ?>
                    <div class="text-sm text-gray-500">Nessun buono trovato per questo ordine in questa fase.</div>
                <?php else: ?>
                    <table class="min-w-full text-sm divide-y divide-gray-200 dark:divide-gray-700">
                        <thead class="bg-gray-100 dark:bg-gray-700 uppercase text-xs">
                            <tr>
                                <th class="px-3 py-2 text-left">Nr.</th>
                                <th class="px-3 py-2 text-left">Data</th>
                                <th class="px-3 py-2 text-right">Azioni</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $woDrawerWorkOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="px-3 py-2 font-semibold">
                                        <?php echo e($w['number']); ?>/<?php echo e($w['year']); ?>

                                    </td>
                                    <td class="px-3 py-2">
                                        <?php echo e($w['issued_at']); ?>

                                    </td>
                                    <td class="px-3 py-2 text-right">
                                        <button type="button"
                                                class="inline-flex items-center hover:text-purple-600"
                                                wire:click="printExistingWorkOrder(<?php echo e($w['id']); ?>)">
                                            <i class="fas fa-print mr-1"></i> Stampa
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </tbody>
                    </table>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
    <script>
        /**
         * Apre una nuova finestra con la pagina “wrapper” che contiene l’iframe PDF e chiama print().
         */
        window.addEventListener('open-print-window', (e) => {
            const url = e.detail?.url;

            if (!url) return;

            const w = window.open(url, '_blank', 'noopener,noreferrer');

            /* Se il popup blocker interviene */
            if (!w) {
                alert('Popup bloccato: consenti i popup per stampare il documento.');
            }
        });

        function advanceModal () {
            return {
                dlg : null,          // settato in x-init
                compId : null,
                id  : null,
                max : 0,
                qty : 1,
                operator : '',

                /* ▲ apre il dialog   -------------------------------------- */
                open (p) {
                    this.id  = p.id
                    this.max = p.maxQty
                    this.qty = p.defaultQty
                    this.operator = ''
                    /* fallback per browser senza <dialog> */
                    if (! this.dlg.showModal) {
                        this.dlg.setAttribute('open', '')
                    } else {
                        this.dlg.showModal()
                    }
                },

                /* ▲ conferma → chiama Livewire ----------------------------- */
                confirm () {
                    if (this.qty < 1 || this.qty > this.max) {
                        alert('Quantità non valida. Non può essere maggiore di' + this.max);
                        return;
                    }

                    const comp = Livewire.find(this.compId)
                    if (! comp) { console.error('Livewire component not found'); return }

                    // ①  aggiorna la property
                    comp.set('advQuantity', this.qty)
                        .then(() => comp.set('advOperator', this.operator))
                        // ②  solo dopo chiama il metodo
                        .then(() => comp.call('confirmAdvance', this.qty));

                    this.close();
                },

                /* ▲ chiusura ---------------------------------------------- */
                close () { this.dlg.close ? this.dlg.close() : this.dlg.removeAttribute('open') },
                
                init () {
                    this.dlg    = this.$el
                    this.compId = this.$el.closest('[wire\\:id]').getAttribute('wire:id')  // ② salva id

                    /* fallback browser che non supportano <dialog>  */
                    if (! this.dlg.showModal) {
                        this.dlg.showModal = () => this.dlg.setAttribute('open', '')
                        this.dlg.close     = () => this.dlg.removeAttribute('open')
                    }

                    /* listener all’evento dispatched da Livewire             */
                    window.addEventListener('show-adv-modal', e => this.open(e.detail))
                },
            }
        }

        function rollbackModal () {
            return {
                dlg : null,
                compId : null,    // id Livewire del componente tabella
                id  : null,       // order_item_id
                max : 0,
                qty : 1,
                reason : '',
                reuse  : false,   // flag “componenti riutilizzabili”

                /* ▲ apre il dialog ------------------------------------------------- */
                open (p) {
                    this.id     = p.id
                    this.max    = p.maxQty
                    this.qty    = p.defaultQty
                    this.reason = ''
                    this.reuse  = false

                    if (! this.dlg.showModal) {
                        this.dlg.setAttribute('open', '')
                    } else {
                        this.dlg.showModal()
                    }
                },

                /* ▲ conferma → chiama Livewire ------------------------------------ */
                confirm () {
                    if (this.qty < 1 || this.qty > this.max) {
                        alert('Quantità non valida (1-' + this.max + ').'); return;
                    }
                    if (this.reason.trim() === '') {
                        alert('La motivazione è obbligatoria.'); return;
                    }

                    const comp = Livewire.find(this.compId)
                    if (! comp) { console.error('Livewire component not found'); return }
                            
                    comp.call('confirmRollback', {
                            id:     this.id,
                            qty:    this.qty,
                            max:    this.max,
                            reason: this.reason,
                            reuse:  this.reuse
                        });

                    this.close()
                },

                /* ▲ chiusura ------------------------------------------------------- */
                close () { this.dlg.close ? this.dlg.close() : this.dlg.removeAttribute('open') },

                init () {
                    this.dlg    = this.$el
                    this.compId = this.$el.closest('[wire\\:id]').getAttribute('wire:id')

                    if (! this.dlg.showModal) {           // polyfill <dialog>
                        this.dlg.showModal = () => this.dlg.setAttribute('open', '')
                        this.dlg.close     = () => this.dlg.removeAttribute('open')
                    }
                    window.addEventListener('show-rollback-modal', e => this.open(e.detail))
                },
            }
        }

        function forceReservationModal () {
            return {
                dlg: null,
                compId: null,

                /* ▲ apre il dialog quando Livewire dispatcha l’evento */
                open () {
                    if (! this.dlg.showModal) {
                        this.dlg.setAttribute('open', '')
                    } else {
                        this.dlg.showModal()
                    }
                },

                /* ▲ conferma → chiama Livewire commitForceReservation() */
                confirm () {
                    const comp = Livewire.find(this.compId)
                    if (! comp) { console.error('Livewire component not found'); return }

                    comp.call('commitForceReservation')  // lo implementiamo subito dopo
                    this.close()
                },

                /* ▲ chiusura: chiude dialog e resetta flag in Livewire */
                close () {
                    const comp = Livewire.find(this.compId)
                    if (comp) {
                        comp.set('showForceReservationModal', false)
                    }
                    this.dlg.close ? this.dlg.close() : this.dlg.removeAttribute('open')
                },

                init () {
                    this.dlg    = this.$el
                    this.compId = this.$el.closest('[wire\\:id]').getAttribute('wire:id')

                    /* polyfill per browser senza <dialog> */
                    if (! this.dlg.showModal) {
                        this.dlg.showModal = () => this.dlg.setAttribute('open', '')
                        this.dlg.close     = () => this.dlg.removeAttribute('open')
                    }

                    /* listener evento dispatched da Livewire */
                    window.addEventListener('show-force-reservation-modal', () => this.open())
                },
            }
        }
    </script>
<?php $__env->stopPush(); ?><?php /**PATH C:\Users\vince\OneDrive\Desktop\gestionale-divani\resources\views/livewire/warehouse/exit-table.blade.php ENDPATH**/ ?>