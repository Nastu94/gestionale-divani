

<?php
    // $tiles viene iniettato dal View Composer in AppServiceProvider
    // e contiene già badge_count calcolati per ciascuna voce.
    // In alternativa, se non lo passi così, puoi fare:
    // $tiles = View::getShared()['menu']['dashboard_tiles'] ?? [];
    $tiles = $tiles ?? [];
?>

<!--<div class="flex flex-wrap gap-4">
    
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(collect($tiles)->pluck('permission')->all())): ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $tiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check($tile['permission'])): ?>
                <a href="<?php echo e(route($tile['route'])); ?>"
                   class="flex items-center p-4 bg-white dark:bg-gray-800 rounded-lg shadow
                          hover:shadow-lg transition w-full sm:w-auto">
                    
                    <div class="flex-shrink-0 p-2 bg-indigo-100 dark:bg-indigo-900 rounded-full">
                        <i class="fas <?php echo e($tile['icon']); ?> text-xl
                                  text-indigo-600 dark:text-indigo-400"></i>
                    </div>
                    
                    <div class="ml-3">
                        <span class="block text-sm font-medium
                                     text-gray-700 dark:text-gray-200">
                            <?php echo e($tile['label']); ?>

                        </span>

                        
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(array_key_exists('badge_count', $tile) && is_numeric($tile['badge_count'])): ?>
                            <span class="text-xs text-gray-500 dark:text-gray-400">
                                <?php echo e($tile['badge_count']); ?>

                            </span>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                </a>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php endif; ?>
</div>-->
<?php /**PATH C:\Users\vince\OneDrive\Desktop\gestionale-divani\resources\views/components/dashboard-tiles.blade.php ENDPATH**/ ?>