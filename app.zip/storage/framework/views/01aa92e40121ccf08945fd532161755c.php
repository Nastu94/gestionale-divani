

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-wrap items-center justify-between">
            <h2 class="font-semibold text-lg text-gray-800 dark:text-gray-200 leading-tight"><?php echo e(__('Prodotti')); ?></h2>
            <?php if (isset($component)) { $__componentOriginalac227964a792ab0ae2fb10589fa2a511 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalac227964a792ab0ae2fb10589fa2a511 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard-tiles','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard-tiles'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalac227964a792ab0ae2fb10589fa2a511)): ?>
<?php $attributes = $__attributesOriginalac227964a792ab0ae2fb10589fa2a511; ?>
<?php unset($__attributesOriginalac227964a792ab0ae2fb10589fa2a511); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalac227964a792ab0ae2fb10589fa2a511)): ?>
<?php $component = $__componentOriginalac227964a792ab0ae2fb10589fa2a511; ?>
<?php unset($__componentOriginalac227964a792ab0ae2fb10589fa2a511); ?>
<?php endif; ?>
        </div>
        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
            <div
                x-data="{ show: true }"
                x-init="setTimeout(() => show = false, 10000)"
                x-show="show"
                x-transition.opacity.duration.500ms
                class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mt-2"
                role="alert"
            >
                <i class="fas fa-check-circle mr-2"></i>
                <span class="block sm:inline"><?php echo e(session('success')); ?></span>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('error')): ?>
            <div
                x-data="{ show: true }"
                x-init="setTimeout(() => show = false, 10000)"
                x-show="show"
                x-transition.opacity.duration.500ms
                class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mt-2"
                role="alert"
            >
                <i class="fas fa-exclamation-triangle mr-2"></i>
                <span class="block sm:inline"><?php echo e(session('error')); ?></span>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
     <?php $__env->endSlot(); ?>
    <div class="py-6">
        <div x-data="productCrud()" class="max-w-full mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 shadow sm:rounded-lg">

                
                <div class="flex justify-end m-2 p-2">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->user()->can('products.create')): ?>
                        <button 
                            @click="openCreate"
                            class="inline-flex items-center m-2 px-3 py-1.5 bg-purple-600 rounded-md
                                        text-xs font-semibold text-white uppercase hover:bg-purple-500
                                        focus:outline-none focus:ring-2 focus:ring-purple-300 transition"
                        >
                            <i class="fas fa-plus mr-1"></i> Nuovo
                        </button>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    
                    <button
                        type="button"
                        @click="extended = !extended"
                        class="inline-flex items-center m-2 px-3 py-1.5 bg-indigo-600 rounded-md text-xs font-semibold text-white uppercase
                            hover:bg-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-900 transition"
                    >
                        <i class="fas p-1" :class="extended ? 'fa-compress' : 'fa-expand'"></i>
                        <span x-text="extended ? 'Comprimi tabella' : 'Estendi tabella'"></span>
                    </button>
                </div>

                
                <div x-show="showModal" x-cloak class="fixed inset-0 z-50 flex items-center justify-center">
                    <div class="absolute inset-0 bg-black opacity-75"></div>
                    <div class="relative z-10 w-full max-w-3xl">
                        <?php if (isset($component)) { $__componentOriginalfa9c3ae8859805d3e34b15772e1933c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfa9c3ae8859805d3e34b15772e1933c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.product-create-modal','data' => ['products' => $products,'components' => $components]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('product-create-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['products' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($products),'components' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($components)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfa9c3ae8859805d3e34b15772e1933c3)): ?>
<?php $attributes = $__attributesOriginalfa9c3ae8859805d3e34b15772e1933c3; ?>
<?php unset($__attributesOriginalfa9c3ae8859805d3e34b15772e1933c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfa9c3ae8859805d3e34b15772e1933c3)): ?>
<?php $component = $__componentOriginalfa9c3ae8859805d3e34b15772e1933c3; ?>
<?php unset($__componentOriginalfa9c3ae8859805d3e34b15772e1933c3); ?>
<?php endif; ?>
                    </div>
                </div>

                
                <template x-if="showPriceListModal">
                    <?php if (isset($component)) { $__componentOriginalfde28b47c608897cec6205fef533f0af = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfde28b47c608897cec6205fef533f0af = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.product-pricelist-modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('product-pricelist-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfde28b47c608897cec6205fef533f0af)): ?>
<?php $attributes = $__attributesOriginalfde28b47c608897cec6205fef533f0af; ?>
<?php unset($__attributesOriginalfde28b47c608897cec6205fef533f0af); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfde28b47c608897cec6205fef533f0af)): ?>
<?php $component = $__componentOriginalfde28b47c608897cec6205fef533f0af; ?>
<?php unset($__componentOriginalfde28b47c608897cec6205fef533f0af); ?>
<?php endif; ?>
                </template>

                
                <template x-if="showCustomerPriceModal">
                    <?php if (isset($component)) { $__componentOriginalcb899e54b3558cb8982019175ea26c64 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb899e54b3558cb8982019175ea26c64 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.product-price-form-modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('product-price-form-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb899e54b3558cb8982019175ea26c64)): ?>
<?php $attributes = $__attributesOriginalcb899e54b3558cb8982019175ea26c64; ?>
<?php unset($__attributesOriginalcb899e54b3558cb8982019175ea26c64); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb899e54b3558cb8982019175ea26c64)): ?>
<?php $component = $__componentOriginalcb899e54b3558cb8982019175ea26c64; ?>
<?php unset($__componentOriginalcb899e54b3558cb8982019175ea26c64); ?>
<?php endif; ?>
                </template>

                
                <template x-if="showViewModal">
                    <?php if (isset($component)) { $__componentOriginal25e55eb001d1272fc6f0b3a01566f732 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal25e55eb001d1272fc6f0b3a01566f732 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.product-view-modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('product-view-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal25e55eb001d1272fc6f0b3a01566f732)): ?>
<?php $attributes = $__attributesOriginal25e55eb001d1272fc6f0b3a01566f732; ?>
<?php unset($__attributesOriginal25e55eb001d1272fc6f0b3a01566f732); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal25e55eb001d1272fc6f0b3a01566f732)): ?>
<?php $component = $__componentOriginal25e55eb001d1272fc6f0b3a01566f732; ?>
<?php unset($__componentOriginal25e55eb001d1272fc6f0b3a01566f732); ?>
<?php endif; ?>
                </template>

                
                <?php if (isset($component)) { $__componentOriginalf5aa473aa91bafe5c63c4dca7f880244 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf5aa473aa91bafe5c63c4dca7f880244 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.product-variables-modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('product-variables-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf5aa473aa91bafe5c63c4dca7f880244)): ?>
<?php $attributes = $__attributesOriginalf5aa473aa91bafe5c63c4dca7f880244; ?>
<?php unset($__attributesOriginalf5aa473aa91bafe5c63c4dca7f880244); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf5aa473aa91bafe5c63c4dca7f880244)): ?>
<?php $component = $__componentOriginalf5aa473aa91bafe5c63c4dca7f880244; ?>
<?php unset($__componentOriginalf5aa473aa91bafe5c63c4dca7f880244); ?>
<?php endif; ?>

                
                <div class="overflow-x-auto p-4">
                    <table class="table-auto min-w-full text-sm divide-y divide-gray-200 dark:divide-gray-700">
                        <thead class="bg-gray-300 dark:bg-gray-700">
                            <tr class="uppercase tracking-wider">
                                <?php if (isset($component)) { $__componentOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.th-menu','data' => ['field' => 'sku','label' => 'Codice Prodotto','sort' => $sort,'dir' => $dir,'filters' => $filters,'resetRoute' => 'products.index']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('th-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'sku','label' => 'Codice Prodotto','sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'dir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dir),'filters' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($filters),'reset-route' => 'products.index']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235)): ?>
<?php $attributes = $__attributesOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235; ?>
<?php unset($__attributesOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235)): ?>
<?php $component = $__componentOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235; ?>
<?php unset($__componentOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.th-menu','data' => ['field' => 'name','label' => 'Nome','sort' => $sort,'dir' => $dir,'filters' => $filters,'resetRoute' => 'products.index']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('th-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'name','label' => 'Nome','sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'dir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dir),'filters' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($filters),'reset-route' => 'products.index']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235)): ?>
<?php $attributes = $__attributesOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235; ?>
<?php unset($__attributesOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235)): ?>
<?php $component = $__componentOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235; ?>
<?php unset($__componentOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235); ?>
<?php endif; ?>
                                <th x-show="extended" x-cloak class="px-6 py-2 text-left">Descrizione</th>
                                <?php if (isset($component)) { $__componentOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.th-menu','data' => ['xShow' => 'extended','xCloak' => true,'field' => 'price','label' => 'Prezzo','sort' => $sort,'dir' => $dir,'filters' => $filters,'resetRoute' => 'products.index','align' => 'right']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('th-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['x-show' => 'extended','x-cloak' => true,'field' => 'price','label' => 'Prezzo','sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'dir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dir),'filters' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($filters),'reset-route' => 'products.index','align' => 'right']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235)): ?>
<?php $attributes = $__attributesOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235; ?>
<?php unset($__attributesOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235)): ?>
<?php $component = $__componentOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235; ?>
<?php unset($__componentOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.th-menu','data' => ['field' => 'is_active','label' => 'Attivo','sort' => $sort,'dir' => $dir,'filters' => $filters,'align' => 'right','resetRoute' => 'products.index']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('th-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'is_active','label' => 'Attivo','sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'dir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dir),'filters' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($filters),'align' => 'right','reset-route' => 'products.index']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235)): ?>
<?php $attributes = $__attributesOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235; ?>
<?php unset($__attributesOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235)): ?>
<?php $component = $__componentOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235; ?>
<?php unset($__componentOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235); ?>
<?php endif; ?>
                            </tr>
                        </thead>

                        <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $canEdit   = auth()->user()->can('products.update');
                                    $canDelete = auth()->user()->can('products.delete');
                                    $canCrud   = $canEdit || $canDelete;
                                ?>

                                
                                <tr
                                    <?php if($canCrud || auth()->user()->can('products.view')): ?>
                                        @click="openId = (openId === <?php echo e($product->id); ?> ? null : <?php echo e($product->id); ?>)"
                                        class="cursor-pointer hover:bg-gray-200 dark:hover:bg-gray-700"
                                        :class="openId === <?php echo e($product->id); ?> ? 'bg-gray-200 dark:bg-gray-700' : ''"
                                    <?php endif; ?>
                                >
                                    <td class="px-6 py-2 whitespace-nowrap"><?php echo e($product->sku); ?></td>
                                    <td class="px-6 py-2 whitespace-nowrap"><?php echo e($product->name); ?></td>
                                    <td x-show="extended" x-cloak class="px-6 py-2 text-left"><?php echo e($product->description ?? '—'); ?></td>
                                    <td x-show="extended" x-cloak class="px-6 py-2 text-left whitespace-nowrap"><?php echo e($product->price ?? '—'); ?>€</td>
                                    <td class="px-6 py-2 text-center whitespace-nowrap">
                                        <span
                                            class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium"
                                            :class="{
                                                'bg-green-100 text-green-800': <?php echo e($product->is_active ? 'true' : 'false'); ?>,
                                                'bg-red-100 text-red-800': <?php echo e($product->is_active ? 'false' : 'true'); ?>

                                            }"
                                        >
                                            <?php echo e($product->is_active ? 'Sì' : 'No'); ?>

                                        </span>
                                    </td>
                                </tr>

                                
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($canCrud || auth()->user()->can('products.view')): ?>
                                <tr x-show="openId === <?php echo e($product->id); ?>" x-cloak>
                                    <td
                                        :colspan="extended ? 5 : 3"
                                        class="px-6 py-3 bg-gray-200 dark:bg-gray-700"
                                    >
                                        <div class="flex items-center space-x-4 text-xs">
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('products.view')): ?>
                                                <button
                                                    type="button"
                                                    @click='openShow(<?php echo json_encode($product, 15, 512) ?>)'
                                                    class="inline-flex items-center hover:text-indigo-600"
                                                >
                                                    <i class="fas fa-eye mr-1"></i> Visualizza
                                                </button>
                                            <?php endif; ?>

                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($canEdit): ?>
                                                <button
                                                    type="button"
                                                    @click='openEdit(<?php echo json_encode($product, 15, 512) ?>)'
                                                    class="inline-flex items-center hover:text-yellow-600"
                                                >
                                                    <i class="fas fa-pencil-alt mr-1"></i> Modifica
                                                </button>
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('products.create')): ?>
                                                <button
                                                    type="button"
                                                    class="inline-flex items-center hover:text-blue-600"
                                                    @click="duplicateProduct(<?php echo \Illuminate\Support\Js::from(route('products.duplicate', $product))->toHtml() ?>)"
                                                    x-data
                                                    title="Duplica prodotto e distinta"
                                                >
                                                    <i class="fas fa-copy mr-1"></i> Duplica
                                                </button>
                                            <?php endif; ?>
                                            
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product-prices.view')): ?>
                                                <button type="button"
                                                        @click='openPriceList(<?php echo json_encode($product, 15, 512) ?>)'
                                                        class="inline-flex items-center hover:text-pink-600">
                                                    <i class="fas fa-list mr-1"></i> Listino
                                                </button>
                                            <?php endif; ?>

                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['product-prices.create', 'product-prices.update'])): ?>
                                                <button type="button"
                                                        @click='openPriceCreate(<?php echo json_encode($product, 15, 512) ?>)'
                                                        class="inline-flex items-center hover:text-green-600">
                                                    <i class="fas fa-handshake mr-1"></i> Cliente
                                                </button>
                                            <?php endif; ?>
                                            
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product-variables.update')): ?>
                                                <button type="button"
                                                        class="inline-flex items-center hover:text-orange-600"
                                                        x-data
                                                        @click="$dispatch('open-product-variables', { productId: <?php echo e($product->id); ?> })">
                                                    <!-- icona semplice -->
                                                    <i class="fa-solid fa-swatchbook mr-1"></i> Variabili
                                                </button>
                                            <?php endif; ?>

                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($canDelete): ?>
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if (! ($product->trashed())): ?>
                                                    <form
                                                        action="<?php echo e(route('products.destroy', $product)); ?>"
                                                        method="POST"
                                                        onsubmit="return confirm('Sei sicuro di voler disattivare questo prodotto?');"
                                                    >
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="inline-flex items-center hover:text-red-600">
                                                            <i class="fas fa-trash-alt mr-1"></i> Disattiva
                                                        </button>
                                                    </form>
                                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                            
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($product->trashed() && auth()->user()->can('products.update')): ?>
                                                <form
                                                    action="<?php echo e(route('products.restore', $product->id)); ?>"
                                                    method="POST"
                                                    onsubmit="return confirm('Ripristinare questo prodotto?');"
                                                >
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" class="inline-flex items-center hover:text-green-600">
                                                        <i class="fas fa-undo mr-1"></i> Ripristina
                                                    </button>
                                                </form>
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                        </div>
                                    </td>
                                </tr>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($products->isEmpty()): ?>
                                <tr>
                                    <td :colspan="extended ? 5 : 3" x-cloak class="px-6 py-4 text-center text-gray-500">
                                        Nessun prodotto trovato.
                                    </td>
                                </tr>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </tbody>
                    </table>
                </div>

                
                <div class="mt-4 px-6 py-2">
                    <?php echo e($products->links('vendor.pagination.tailwind-compact')); ?>

                </div>
            </div>
        </div>
    </div>

<?php $__env->startPush('scripts'); ?>
    <script>
        document.addEventListener('alpine:init', () => {
            Alpine.data('productCrud', () => ({
                /* ============================================================
                * Sezione prodotti
                * ========================================================== */
                componentsList: <?php echo json_encode($components, 15, 512) ?>,
                generateCodeUrl: <?php echo json_encode(route('products.generate-code'), 15, 512) ?>,
                // Flag per evitare click multipli durante la richiesta
                dupBusy: false,

                // Modale prodotto
                showModal: false,
                mode: 'create',
                form: {
                    id: null,
                    sku: '',
                    name: '',
                    description: '',
                    price: '',
                    components: [],
                    fabric_required_meters: 0,
                    is_active: true,
                },
                errors: {},

                // Riga espansa / colonne
                openId: null,
                extended: false,

                // Modale "Visualizza" prodotto
                showViewModal: false,
                viewProduct: null,

                openShow(product) {
                    this.viewProduct = product;
                    this.$nextTick(() => { this.showViewModal = true; });
                },

                openCreate() {
                    this.resetForm();
                    this.mode = 'create';
                    this.showModal = true;
                },

                openEdit(product) {
                    // Fallback: se per qualsiasi motivo l'accessor non è presente,
                    // prendo la quantity della riga di pivot con variable_slot='TESSU'.
                    const fabricFromPivot = (product.components || [])
                        .find(c => (c.pivot && c.pivot.variable_slot === 'TESSU'))
                        ?.pivot?.quantity ?? 0;

                    this.mode = 'edit';
                    this.form = {
                        id         : product.id,
                        sku        : product.sku,
                        name       : product.name,
                        description: product.description ?? '',
                        price      : product.price,
                        // Preferisci l'attributo calcolato, altrimenti usa il pivot
                        fabric_required_meters: product.fabric_required_meters ?? fabricFromPivot,
                        is_active  : product.is_active,
                        components : (product.components ?? []).map(c => ({
                            id         : c.id,
                            quantity   : c.pivot.quantity,
                            code       : c.code,
                            description: c.description,
                            unit       : c.unit, // opzionale
                            existing   : true,
                            search     : '', options: []
                        }))
                    };
                    this.errors = {};
                    this.$nextTick(() => { this.showModal = true; });
                },

                resetForm() {
                    this.form = {
                        id: null,
                        sku: '',
                        name: '',
                        description: '',
                        price: '',
                        fabric_required_meters: 0,
                        components: [],
                        is_active: true,
                    };
                    this.errors = {};
                },

                validateProduct() {
                    this.errors = {};
                    let valid = true;
                    if (!this.form.sku.trim())   { this.errors.sku  = 'Il codice è obbligatorio.'; valid = false; }
                    if (!this.form.name.trim())  { this.errors.name = 'Il nome è obbligatorio.';   valid = false; }
                    if (!this.form.price.trim()) { this.errors.price= 'Il prezzo è obbligatorio.'; valid = false; }
                    if (!this.form.fabric_required_meters) { this.errors.fabric_required_meters= 'I metri di tessuto sono obbligatori.'; valid = false; }
                    return valid;
                },

                init() {
                    <?php if($errors->any()): ?>
                        this.showModal = true;
                        this.mode = '<?php echo e(old('_method','create') === 'PUT' ? 'edit' : 'create'); ?>';
                        this.errors = <?php echo json_encode($errors->toArray(), 15, 512) ?>;
                        this.form = {
                            id          : <?php echo e(old('id', 'null')); ?>,
                            sku         : '<?php echo e(old('sku', '')); ?>',
                            name        : '<?php echo e(old('name', '')); ?>',
                            description : '<?php echo e(old('description', '')); ?>',
                            price       : '<?php echo e(old('price', '')); ?>',
                            fabric_required_meters: <?php echo e(old('fabric_required_meters', 0)); ?>,
                            components  : <?php echo json_encode(old('components', []), 512) ?>,
                            is_active   : <?php echo e(old('is_active', true) ? 'true' : 'false'); ?>,
                        };
                    <?php endif; ?>

                    // Inizializzo il debounce per la ricerca clienti (fallback se non usi .debounce nel template)
                    this.searchCustomersDebounced = this.debounce(this.searchCustomers, 500);
                },

                async generateCode() {
                    try {
                        const res  = await fetch(this.generateCodeUrl);
                        const json = await res.json();
                        this.form.sku = json.code;
                    } catch (e) {
                        console.error('Errore generazione codice:', e);
                    }
                },

                /**
                 * Ritorna il token CSRF dal meta del layout (standard Laravel).
                 */
                getCsrfToken() {
                    return document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';
                },

                /**
                 * Duplica un prodotto chiamando l'endpoint passato già completo.
                 * Nessun reload: mostriamo solo una notifica con il nuovo SKU.
                 *
                 * @param {string} url URL già costruito lato Blade (es. "/products/123/duplicate")
                 */
                async duplicateProduct(url) {
                    if (this.dupBusy) return;
                    if (!confirm('Confermi la duplicazione di questo prodotto (distinta compresa)?')) return;

                    this.dupBusy = true;
                    try {
                        const r = await fetch(url, {
                            method: 'POST',
                            headers: {
                                'Accept'          : 'application/json',
                                'X-CSRF-TOKEN'    : this.getCsrfToken(),
                                'X-Requested-With': 'XMLHttpRequest',
                            },
                            credentials: 'same-origin',
                        });

                        const j = await r.json().catch(() => ({}));

                        if (!r.ok || !j.ok) {
                            alert(j.msg || j.message || 'Errore nella duplicazione.');
                            return;
                        }

                        // Successo: nessun insert in tabella (la copia apparirà sfogliando le pagine)
                        alert(`Prodotto duplicato.\nNuovo SKU: ${j.sku}`);
                        window.location.reload();
                    } catch (e) {
                        console.error('duplicateProduct error', e);
                        alert('Errore di rete nella duplicazione.');
                    } finally {
                        this.dupBusy = false;
                    }
                },

                /* Ricerca componenti (come da tuo codice) */
                async searchComponents(idx) {
                    const term = this.form.components[idx].search?.trim() || '';
                    if (term.length < 2) {
                        this.form.components[idx].options = [];
                        return;
                    }
                    try {
                        const r = await fetch(`/components/search?q=${encodeURIComponent(term)}`, { headers:{Accept:'application/json'} });
                        this.form.components[idx].options = await r.json();
                    } catch {
                        this.form.components[idx].options = [];
                    }
                },

                selectComponent(idx, opt) {
                    Object.assign(this.form.components[idx], {
                        id         : opt.id,
                        code       : opt.code,
                        description: opt.description,
                        unit       : opt.unit_of_measure,
                        options    : [],
                    });
                },

                removeSelection(idx) {
                    Object.assign(this.form.components[idx], {
                        id: null, code: '', description: '', search: '',
                    });
                },

                addComponentRow() {
                    this.form.components.push({
                        id: null, quantity: 1,
                        search: '', options: [], existing: false
                    });
                },

                /* ============================================================
                * Prezzi cliente–prodotto (modali + ricerca cliente)
                * ========================================================== */

                // Modale Listino
                showPriceListModal: false,
                priceList: [],

                // Modale Cliente (create/edit on-the-fly)
                showCustomerPriceModal: false,

                // Prodotto selezionato per l'assegnazione prezzi
                selectedProduct: null,

                // Form del modale Cliente
                priceForm: {
                    mode: 'create',              // 'create' | 'edit'
                    current_id: null,            // id versione in edit
                    customer_id: null,
                    customer_name: '',
                    price: '',
                    reference_date: new Date().toISOString().slice(0,10), // default oggi
                    valid_from: '',
                    valid_to: '',
                    auto_close_prev: true,       // chiudi automaticamente la versione che copre 'valid_from'
                    notes: '',
                    // updated_at: null,         // opzionale per concorrenza ottimistica
                },
                priceErrors: {},

                // Ricerca cliente (stile customer-order-create-modal)
                customerSearch: '',              // testo input
                customerOptions: [],             // dropdown risultati
                customerLoading: false,
                searchCustomersDebounced: null,  // fallback se non usi @input.debounce nel Blade
                selectedCustomer: null,     // oggetto cliente scelto (company, email, vat_number, etc.)
                showGuestButton: false,     // di default off: non ha senso assegnare prezzi ad un guest

                // Debounce utility
                debounce(fn, wait = 300) {
                    let t; return (...args) => { clearTimeout(t); t = setTimeout(() => fn.apply(this, args), wait); };
                },

                /* ---------- Apertura / chiusura modali prezzi ---------- */
                openPriceList(product) {
                    this.selectedProduct = product;
                    this.fetchPriceList().then(() => { this.showPriceListModal = true; });
                },

                openPriceCreate(product) {
                    this.selectedProduct = product;
                    this.resetCustomerPriceForm();

                    // reset ricerca + cliente selezionato
                    this.selectedCustomer = null;
                    this.customerSearch   = '';
                    this.customerOptions  = [];
                    this.customerLoading  = false;

                    this.showCustomerPriceModal = true;
                },

                closeCustomerPriceModal() {
                    this.showCustomerPriceModal = false;
                    this.resetCustomerPriceForm();

                    // reset ricerca + cliente selezionato
                    this.selectedCustomer = null;
                    this.customerSearch   = '';
                    this.customerOptions  = [];
                    this.customerLoading  = false;
                },

                /* ----------------- API prezzi ----------------- */
                async fetchPriceList() {
                    if (!this.selectedProduct) return;
                    const url = `/products/${this.selectedProduct.id}/customer-prices`;
                    const r = await fetch(url, { headers: {Accept: 'application/json'} });
                    const j = await r.json();
                    this.priceList = j.data ?? [];
                },

                /* ---------------- Ricerca clienti ----------------
                * identica nello spirito a customer-order-create-modal:
                * - input: customerSearch
                * - debounce: @input.debounce.500 (o this.searchCustomersDebounced)
                * - risultati: customerOptions
                * - key: option.id + '-' + idx
                */
                async searchCustomers() {
                    const term = (this.customerSearch || '').trim();
                    if (term.length < 2) { this.customerOptions = []; return; }

                    this.customerLoading = true;
                    try {
                        const r = await fetch(`/customers/search?q=${encodeURIComponent(term)}`, {
                            headers: { Accept:'application/json' }, credentials:'same-origin'
                        });
                        if (!r.ok) throw new Error(r.status);

                        const data = await r.json();
                        const arr  = Array.isArray(data) ? data : [];

                        // Deduplica: privilegio id, altrimenti stringa serializzata
                        const seen = new Set();
                        this.customerOptions = arr.filter((option) => {
                            const key = option && option.id != null ? `id:${option.id}` : `str:${JSON.stringify(option)}`;
                            if (seen.has(key)) return false;
                            seen.add(key); return true;
                        }).slice(0, 20);

                    } catch (e) {
                        console.error('searchCustomers error', e);
                        this.customerOptions = [];
                    } finally {
                        this.customerLoading = false;
                    }
                },

                // Selezione dal dropdown: popolo il form + risoluzione create→edit
                selectCustomer(option) {
                    // Normalizzo nome/label
                    const name = option?.company || option?.name || option?.label || '';

                    // Salvo oggetto completo per il pannellino riepilogo
                    this.selectedCustomer = {
                        id: option?.id ?? null,
                        company: option?.company ?? option?.name ?? '',
                        email: option?.email ?? null,
                        vat_number: option?.vat_number ?? null,
                        tax_code: option?.tax_code ?? null,
                        // se l’endpoint non restituisce shipping_address pronto, usa fallback base
                        shipping_address: option?.shipping_address
                            ?? [option?.address, option?.postal_code && option?.city ? `${option.postal_code} ${option.city}` : option?.city, option?.province, option?.country]
                                .filter(Boolean).join(', ')
                    };

                    // Allineo il form tecnico
                    this.priceForm.customer_id   = this.selectedCustomer.id;
                    this.priceForm.customer_name = name; // compat, se lo usi altrove

                    // UI input + dropdown
                    this.customerSearch  = name;
                    this.customerOptions = [];

                    // Escamotage: se esiste una versione valida alla data, passo in edit e precompilo
                    this.resolveCustomerPrice();
                },

                // Risolve product+customer(+date) → versione valida o ultimo storico
                async resolveCustomerPrice() {
                    this.priceErrors = {};
                    if (!this.selectedProduct || !this.priceForm.customer_id) return;

                    const url = `/products/${this.selectedProduct.id}/customer-prices/resolve?customer_id=${this.priceForm.customer_id}&date=${this.priceForm.reference_date}`;
                    const r   = await fetch(url, { headers: {Accept:'application/json'} });
                    const j   = await r.json();

                    if (j.current) {
                        this.priceForm.mode       = 'edit';
                        this.priceForm.current_id = j.current.id;
                        this.priceForm.price      = String(j.current.price);
                        this.priceForm.valid_from = j.current.valid_from ?? '';
                        this.priceForm.valid_to   = j.current.valid_to ?? '';
                        this.priceForm.notes      = j.current.notes ?? '';
                        // this.priceForm.updated_at = j.current.updated_at ?? null;  // se vuoi concorrenza
                    } else {
                        this.priceForm.mode       = 'create';
                        this.priceForm.current_id = null;
                        if (j.latestArchived) {
                            this.priceForm.price      = String(j.latestArchived.price);
                            this.priceForm.valid_from = '';
                            this.priceForm.valid_to   = '';
                            this.priceForm.notes      = j.latestArchived.notes ?? '';
                        } else {
                            this.priceForm.price = '';
                            this.priceForm.valid_from = '';
                            this.priceForm.valid_to   = '';
                            this.priceForm.notes      = '';
                        }
                    }
                },

                onValidFromChanged() {
                    // La chiusura della versione precedente avviene server-side
                },

                normalizePrice(v) {
                    return (typeof v === 'string') ? v.replace(',', '.') : v;
                },

                // Crea/Aggiorna versione prezzo
                async saveCustomerPrice() {
                    try {
                        this.priceErrors = {};

                        const payload = {
                            customer_id    : this.priceForm.customer_id,
                            price          : this.normalizePrice(this.priceForm.price),
                            currency       : 'EUR',
                            valid_from     : this.priceForm.valid_from || null,
                            valid_to       : this.priceForm.valid_to   || null,
                            notes          : this.priceForm.notes      || null,
                            auto_close_prev: this.priceForm.mode === 'create' ? !!this.priceForm.auto_close_prev : false,
                            updated_at     : this.priceForm.mode === 'edit' ? (this.priceForm.updated_at ?? null) : null,
                        };

                        let url = `/products/${this.selectedProduct.id}/customer-prices`;
                        let method = 'POST';
                        if (this.priceForm.mode === 'edit' && this.priceForm.current_id) {
                            url    = `/products/${this.selectedProduct.id}/customer-prices/${this.priceForm.current_id}`;
                            method = 'PUT';
                        }

                        // 🔐 Token CSRF dal meta
                        const token = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';

                        const r = await fetch(url, {
                            method,
                            headers: {
                                'Content-Type'   : 'application/json',
                                'Accept'         : 'application/json',
                                'X-CSRF-TOKEN'   : token,                    // ← obbligatorio
                                'X-Requested-With': 'XMLHttpRequest'
                            },
                            credentials: 'same-origin',                      // ← invia i cookie di sessione
                            body: JSON.stringify(payload)
                        });

                        if (r.status === 409) {
                            const j = await r.json();
                            alert(j.message || 'Il record è stato modificato da un altro utente.');
                            return;
                        }
                        if (r.status === 422) {
                            const j = await r.json();
                            this.priceErrors = j.errors || {};
                            alert(j.message || 'Errori di validazione.');
                            return;
                        }
                        if (!r.ok) {
                            const j = await r.json().catch(() => ({}));
                            alert(j.message || 'Errore salvataggio.');
                            return;
                        }

                        await this.fetchPriceList();
                        alert('Prezzo salvato con successo.');
                        this.closeCustomerPriceModal();
                        this.showPriceListModal = true;

                    } catch (e) {
                        console.error(e);
                        alert('Errore di rete.');
                    }
                },

                async deleteCustomerPrice(row) {
                    if (!this.selectedProduct) return;
                    if (!confirm('Eliminare questa versione di prezzo?')) return;

                    try {
                        const url = `/products/${this.selectedProduct.id}/customer-prices/${row.id}`;
                        const token = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';

                        const r = await fetch(url, {
                            method: 'DELETE',
                            headers: {
                                'Accept'          : 'application/json',
                                'X-CSRF-TOKEN'    : token,                    // ← obbligatorio
                                'X-Requested-With': 'XMLHttpRequest'
                            },
                            credentials: 'same-origin'                       // ← invia i cookie di sessione
                        });

                        if (!r.ok) {
                            const j = await r.json().catch(() => ({}));
                            alert(j.message || 'Errore eliminazione.');
                            return;
                        }
                        await this.fetchPriceList();

                    } catch (e) {
                        console.error(e);
                        alert('Errore di rete.');
                    }
                },

                resetCustomerPriceForm() {
                    this.priceForm = {
                        mode: 'create',
                        current_id: null,
                        customer_id: null,
                        customer_name: '',
                        price: '',
                        reference_date: new Date().toISOString().slice(0,10),
                        valid_from: '',
                        valid_to: '',
                        auto_close_prev: true,
                        notes: '',
                    };
                    this.priceErrors      = {};
                    this.selectedCustomer = null;  // ← reset pannellino
                    this.customerSearch   = '';    // ← reset input
                    this.customerOptions  = [];
                },

            }));
        });
    </script>
<?php $__env->stopPush(); ?>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Users\vince\OneDrive\Desktop\gestionale-divani\resources\views/pages/master-data/index-products.blade.php ENDPATH**/ ?>