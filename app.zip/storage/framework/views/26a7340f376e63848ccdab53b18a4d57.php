<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\vince\OneDrive\Desktop\gestionale-divani\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>