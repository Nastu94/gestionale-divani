<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'field',               // nome colonna (es. 'company', 'code', ecc.)
    'label',               // etichetta visuale (es. 'Cliente', 'Codice')
    'sort',                // campo attualmente ordinato, passato da controller
    'dir',                 // direzione corrente ('asc'|'desc'), passato da controller
    'filters',             // array filtri attivi, passato da controller
    'filterable' => true,  // mostra o meno l'input di filtro
    'resetRoute' => null,  // rotta per azzerare tutto; se null usa route corrente
    'align'      => 'left',// 'left' o 'right' per allineamento dropdown
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'field',               // nome colonna (es. 'company', 'code', ecc.)
    'label',               // etichetta visuale (es. 'Cliente', 'Codice')
    'sort',                // campo attualmente ordinato, passato da controller
    'dir',                 // direzione corrente ('asc'|'desc'), passato da controller
    'filters',             // array filtri attivi, passato da controller
    'filterable' => true,  // mostra o meno l'input di filtro
    'resetRoute' => null,  // rotta per azzerare tutto; se null usa route corrente
    'align'      => 'left',// 'left' o 'right' per allineamento dropdown
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $hasSort    = request()->has('sort');
    $isSorted   = $hasSort && $sort === $field;
    $exceptKeys = ['page', "filter.$field", 'sort', 'dir'];
    $baseQuery  = collect(request()->query())->forget($exceptKeys)->all();
    $urlWith    = fn(array $extra) => url()->current() . '?' . http_build_query(array_replace_recursive($baseQuery, $extra));
?>

<th <?php echo e($attributes->merge(['class' => 'px-6 py-2 text-left relative'])); ?>

    x-data="{
        open : false,
        updatePos() {
            const btn = $refs.btn, dd = $refs.dropdown;
            const r   = btn.getBoundingClientRect();

            // ▼ coord. verticali: sempre sotto la <th>
            dd.style.top = (r.bottom + window.scrollY) + 'px';

            if ('<?php echo e($align); ?>' === 'right') {
                // allineato a destra: calcoliamo lo spazio dal bordo destro viewport
                dd.style.left  = 'auto';
                dd.style.right = (window.innerWidth - r.right - window.scrollX) + 'px';
            } else {
                dd.style.right = 'auto';
                dd.style.left  = (r.left + window.scrollX) + 'px';
            }
        },
        init() {
            /* ───── sincronizza su scroll / resize ───── */
            const sync = () => { if (this.open) this.updatePos() };
            window.addEventListener('scroll',  sync, true);
            window.addEventListener('resize', sync);

            /* ───── sposta il nodo quando si apre ───── */
            this.$watch('open', val => {
                const dd = $refs.dropdown;

                if (val) {
                    if (dd.parentNode !== document.body) document.body.appendChild(dd);

                    dd.classList.remove('hidden');          // mostra
                    dd.style.position = 'absolute';
                    dd.style.zIndex   = 9999;
                    this.$nextTick(() => this.updatePos()); // calcola dopo il render
                    return;
                }

                dd.classList.add('hidden');                 // nascondi, nessun reset display
            });
        }

    }"
    :class="{ 'bg-gray-100': open }"
>
    
    <button x-ref="btn" @click="open = !open"
            class="flex items-center gap-1 hover:text-indigo-600 focus:outline-none uppercase tracking-wider">
        <?php echo e($label); ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isSorted): ?>
            <i class="fas fa-sort-<?php echo e($dir === 'asc' ? 'up' : 'down'); ?>"></i>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </button>

    
    <div  x-show="open"
          x-ref="dropdown"
          @click.outside="open = false"
          wire:ignore
          x-transition.opacity
          class="w-48 bg-white rounded shadow text-sm hidden">

        
        <a href="<?php echo e($urlWith(['sort'=>$field,'dir'=>'asc'])); ?>"  class="block px-3 py-1 hover:bg-gray-100">
            <i class="fa-solid fa-arrow-up-short-wide mr-1"></i><b>Crescente</b>
        </a>
        <a href="<?php echo e($urlWith(['sort'=>$field,'dir'=>'desc'])); ?>" class="block px-3 py-1 hover:bg-gray-100">
            <i class="fa-solid fa-arrow-down-wide-short mr-1"></i><b>Decrescente</b>
        </a>

        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($filterable): ?>
            <div class="border-t my-1"></div>
            <form method="GET" action="<?php echo e(url()->current()); ?>" class="px-3 py-1 space-y-1 text-xs">
                
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $baseQuery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(is_array($v)): ?>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $v; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subk => $subv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <input type="hidden" name="<?php echo e($k); ?>[<?php echo e($subk); ?>]" value="<?php echo e($subv); ?>" />
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php else: ?>
                        <input type="hidden" name="<?php echo e($k); ?>" value="<?php echo e($v); ?>" />
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <input type="text" name="filter[<?php echo e($field); ?>]" value="<?php echo e($filters[$field] ?? ''); ?>"
                       placeholder="Filtra <?php echo e(strtolower($label)); ?>…"
                       class="w-full border rounded px-1 py-0.5 focus:ring-indigo-500 focus:border-indigo-500" />
                <button class="w-full text-indigo-600 hover:underline"><b>Applica</b></button>
            </form>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <div class="border-t my-1"></div>
        <a href="<?php echo e($resetRoute ? route($resetRoute) : url()->current()); ?>"
           class="block px-3 py-1 text-red-600 hover:bg-gray-100"><b>Azzera filtri</b></a>
    </div>
</th>
<?php /**PATH C:\Users\vince\OneDrive\Desktop\gestionale-divani\resources\views/components/th-menu.blade.php ENDPATH**/ ?>