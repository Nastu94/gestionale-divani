<?php $__env->startComponent('mail::message'); ?>
# <?php echo app('translator')->get('orders.email.request_title'); ?>

<?php echo app('translator')->get('orders.email.request_intro', ['order' => $order->orderNumber->full ?? ('#'.$order->id)]); ?>

<?php $__env->startComponent('mail::button', ['url' => $confirmUrl]); ?>
<?php echo app('translator')->get('orders.email.request_cta'); ?>
<?php echo $__env->renderComponent(); ?>

<?php echo app('translator')->get('orders.email.request_footer', ['days' => $ttlDays]); ?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($replacePrevious): ?>
> <?php echo app('translator')->get('orders.email.request_replace_note'); ?>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\vince\OneDrive\Desktop\gestionale-divani\resources\views/emails/orders/confirmation-request.blade.php ENDPATH**/ ?>