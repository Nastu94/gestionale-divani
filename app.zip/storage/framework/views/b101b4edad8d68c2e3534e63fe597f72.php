



<div class="py-6" x-data="{ openId: <?php if ((object) ('expandedId') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('expandedId'->value()); ?>')<?php echo e('expandedId'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('expandedId'); ?>')<?php endif; ?> }" @close-row.window="openId = null">

    
    <?php if (isset($component)) { $__componentOriginal5168fdb0c14fd91c6598264bc4be63f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5168fdb0c14fd91c6598264bc4be63f2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.flash','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flash'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5168fdb0c14fd91c6598264bc4be63f2)): ?>
<?php $attributes = $__attributesOriginal5168fdb0c14fd91c6598264bc4be63f2; ?>
<?php unset($__attributesOriginal5168fdb0c14fd91c6598264bc4be63f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5168fdb0c14fd91c6598264bc4be63f2)): ?>
<?php $component = $__componentOriginal5168fdb0c14fd91c6598264bc4be63f2; ?>
<?php unset($__componentOriginal5168fdb0c14fd91c6598264bc4be63f2); ?>
<?php endif; ?>

    
    <div class="mb-3 flex items-center justify-between">
        <div class="inline-flex rounded-md shadow-sm bg-white dark:bg-gray-800 p-1">
            <button
                wire:click="$set('mode','components')"
                type="button"
                class="px-3 py-1.5 text-sm font-medium rounded-l-md border
                       <?php echo e($mode==='components' ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-200 border-gray-300'); ?>">
                Componenti
            </button>
            <button
                wire:click="$set('mode','products')"
                type="button"
                class="px-3 py-1.5 text-sm font-medium rounded-r-md border-t border-b border-r
                       <?php echo e($mode==='products' ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-200 border-gray-300'); ?>">
                Prodotti resi
            </button>
        </div>

        
        <div class="text-xs">
            <label class="mr-1 p-1">Righe:</label>
            <select wire:model="perPage" class="border rounded px-5 py-1 text-xs">
                <option value="50">50</option>
                <option value="100">100</option>
                <option value="250">250</option>
            </select>
        </div>
    </div>

    
    <div class="bg-white dark:bg-gray-800 shadow sm:rounded-lg">
        <div class="p-4 overflow-x-auto">

            <table class="min-w-full text-sm divide-y divide-gray-200 dark:divide-gray-700">
                
                <thead class="bg-gray-300 dark:bg-gray-700 uppercase tracking-wider">
                    <tr>
                        <?php if (isset($component)) { $__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.th-menu-live','data' => ['field' => 'component_code','label' => 'Codice','sort' => $sort,'dir' => $dir,'filters' => $filters]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('th-menu-live'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'component_code','label' => 'Codice','sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'dir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dir),'filters' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($filters)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8)): ?>
<?php $attributes = $__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8; ?>
<?php unset($__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8)): ?>
<?php $component = $__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8; ?>
<?php unset($__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.th-menu-live','data' => ['field' => 'component_description','label' => 'Descrizione','sort' => $sort,'dir' => $dir,'filters' => $filters]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('th-menu-live'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'component_description','label' => 'Descrizione','sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'dir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dir),'filters' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($filters)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8)): ?>
<?php $attributes = $__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8; ?>
<?php unset($__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8)): ?>
<?php $component = $__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8; ?>
<?php unset($__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8); ?>
<?php endif; ?>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($mode === 'components'): ?>
                            <?php if (isset($component)) { $__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.th-menu-live','data' => ['field' => 'uom','label' => 'UM','sort' => $sort,'dir' => $dir,'filters' => $filters,'align' => 'right']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('th-menu-live'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'uom','label' => 'UM','sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'dir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dir),'filters' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($filters),'align' => 'right']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8)): ?>
<?php $attributes = $__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8; ?>
<?php unset($__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8)): ?>
<?php $component = $__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8; ?>
<?php unset($__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8); ?>
<?php endif; ?>
                        <?php else: ?>
                            
                            <?php if (isset($component)) { $__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.th-menu-live','data' => ['field' => 'fabric','label' => 'Tessuto','sort' => $sort,'dir' => $dir,'filters' => $filters,'filterable' => true,'align' => 'right']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('th-menu-live'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'fabric','label' => 'Tessuto','sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'dir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dir),'filters' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($filters),'filterable' => true,'align' => 'right']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8)): ?>
<?php $attributes = $__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8; ?>
<?php unset($__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8)): ?>
<?php $component = $__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8; ?>
<?php unset($__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8); ?>
<?php endif; ?>

                            <?php if (isset($component)) { $__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.th-menu-live','data' => ['field' => 'color','label' => 'Colore','sort' => $sort,'dir' => $dir,'filters' => $filters,'filterable' => true,'align' => 'right']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('th-menu-live'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'color','label' => 'Colore','sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'dir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dir),'filters' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($filters),'filterable' => true,'align' => 'right']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8)): ?>
<?php $attributes = $__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8; ?>
<?php unset($__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8)): ?>
<?php $component = $__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8; ?>
<?php unset($__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8); ?>
<?php endif; ?>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                        <?php if (isset($component)) { $__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.th-menu-live','data' => ['field' => 'quantity','label' => 'Totale','sort' => $sort,'dir' => $dir,'filters' => $filters,'filterable' => false,'align' => 'right']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('th-menu-live'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'quantity','label' => 'Totale','sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'dir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dir),'filters' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($filters),'filterable' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false),'align' => 'right']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8)): ?>
<?php $attributes = $__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8; ?>
<?php unset($__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8)): ?>
<?php $component = $__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8; ?>
<?php unset($__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8); ?>
<?php endif; ?>

                        <?php if (isset($component)) { $__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.th-menu-live','data' => ['field' => 'reserved_quantity','label' => 'Riservato','sort' => $sort,'dir' => $dir,'filters' => $filters,'filterable' => false,'align' => 'right']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('th-menu-live'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'reserved_quantity','label' => 'Riservato','sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'dir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dir),'filters' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($filters),'filterable' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false),'align' => 'right']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8)): ?>
<?php $attributes = $__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8; ?>
<?php unset($__attributesOriginal6dbf3729a04faa507d37d8ddcd4fa1b8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8)): ?>
<?php $component = $__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8; ?>
<?php unset($__componentOriginal6dbf3729a04faa507d37d8ddcd4fa1b8); ?>
<?php endif; ?>
                    </tr>
                </thead>

                
                <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr wire:key="row-<?php echo e($level->id); ?>"
                            <?php if($mode === 'components'): ?>
                                x-data
                                x-on:click="$dispatch('open-lots', <?php echo e($level->id); ?>)"
                                class="cursor-pointer hover:bg-gray-200 dark:hover:bg-gray-700"
                            <?php else: ?>
                                class="hover:bg-gray-100 dark:hover:bg-gray-700"
                            <?php endif; ?>
                        >
                            
                            <td class="px-6 py-2">
                                <?php echo e($mode==='components' ? $level->component_code : $level->product_code); ?>

                            </td>
                            <td class="px-6 py-2">
                                <?php echo e($mode==='components' ? $level->component_description : $level->product_description); ?>

                            </td>

                            
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($mode === 'components'): ?>
                                <td class="px-6 py-2 text-left"><?php echo e(strtoupper($level->uom)); ?></td>
                            <?php else: ?>
                                <td class="px-6 py-2 text-left"><?php echo e($level->fabric_name ?? '—'); ?></td>
                                <td class="px-6 py-2 text-left"><?php echo e($level->color_name  ?? '—'); ?></td>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                            
                            <td class="px-6 py-2 text-center"><?php echo e($level->quantity); ?></td>
                            <td class="px-6 py-2 text-center"><?php echo e($level->reserved_quantity); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="<?php echo e($mode==='components' ? 5 : 6); ?>"
                                class="px-6 py-2 text-center text-gray-500">
                                Nessun risultato trovato.
                            </td>
                        </tr>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </tbody>
            </table>
        </div>

        
        <div class="flex items-center justify-between px-6 py-2">
            <div><?php echo e($levels->links('vendor.pagination.tailwind-compact')); ?></div>
            
        </div>
    </div>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($mode === 'components'): ?>
    <div  x-data="{ open:false, spin:false, lots:[] }"
          x-cloak
          x-on:open-lots.window="
                open=true; spin=true;
                $wire.call('toggle', $event.detail)
                    .then(() => { lots = $wire.lots[$event.detail]; spin=false; });">

        <div  x-show="open" x-transition.opacity
              class="fixed inset-0 bg-black/50 z-40" @click="open=false"></div>

        <aside x-show="open"
               x-transition:enter="transition duration-200 transform"
               x-transition:leave="transition duration-150 transform"
               x-transition:enter-start="translate-y-full"
               x-transition:enter-end="translate-y-0"
               x-transition:leave-start="translate-y-0"
               x-transition:leave-end="translate-y-full"
               class="fixed inset-x-0 bottom-0 bg-white dark:bg-gray-800
                      max-h-[60vh] rounded-t-2xl shadow-lg z-50 overflow-auto">

            <header class="p-4 font-semibold text-lg flex justify-between">
                Lotti componente
                <button @click="open=false"><i class="fas fa-times"></i></button>
            </header>

            <div class="px-5 pt-2 pb-6 md:pb-8 [padding-bottom:env(safe-area-inset-bottom)]">
                <div x-show="spin" class="py-6 text-center text-sm">
                    <i class="fas fa-circle-notch fa-spin mr-1"></i>Caricamento lotti…
                </div>

                <table x-show="!spin" class="min-w-full text-sm divide-y divide-gray-200">
                    <thead class="bg-gray-200 dark:bg-gray-700 text-left">
                        <tr>
                            <th class="px-4 py-2">Interno</th>
                            <th class="px-4 py-2">Fornitore</th>
                            <th class="px-4 py-2 text-right">Q.tà</th>
                        </tr>
                    </thead>
                    <tbody>
                        <template x-for="lot in lots" :key="lot.internal_lot_code">
                            <tr class="divide-x">
                                <td class="px-4 py-1" x-text="lot.internal_lot_code"></td>
                                <td class="px-4 py-1" x-text="lot.supplier_lot_code || '—'"></td>
                                <td class="px-4 py-1 text-right" x-text="lot.quantity"></td>
                            </tr>
                        </template>
                    </tbody>
                </table>
            </div>
        </aside>
    </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

</div>
<?php /**PATH C:\Users\vince\OneDrive\Desktop\gestionale-divani\resources\views/livewire/warehouse/stock-levels-table.blade.php ENDPATH**/ ?>