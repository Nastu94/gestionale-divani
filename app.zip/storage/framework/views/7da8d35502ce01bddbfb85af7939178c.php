<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- Header: Dashboard Tiles Component -->
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-wrap items-center justify-between">
            <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
                <?php echo e(__('Dashboard')); ?>

            </h2>
            <!-- Component per le dashboard tiles -->
            <?php if (isset($component)) { $__componentOriginalac227964a792ab0ae2fb10589fa2a511 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalac227964a792ab0ae2fb10589fa2a511 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard-tiles','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard-tiles'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalac227964a792ab0ae2fb10589fa2a511)): ?>
<?php $attributes = $__attributesOriginalac227964a792ab0ae2fb10589fa2a511; ?>
<?php unset($__attributesOriginalac227964a792ab0ae2fb10589fa2a511); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalac227964a792ab0ae2fb10589fa2a511)): ?>
<?php $component = $__componentOriginalac227964a792ab0ae2fb10589fa2a511; ?>
<?php unset($__componentOriginalac227964a792ab0ae2fb10589fa2a511); ?>
<?php endif; ?>
        </div>
     <?php $__env->endSlot(); ?>

    <!-- Main Content: Grid Menu Component -->
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-visible shadow-xl sm:rounded-lg py-6">
                <!-- Sostituiamo x-welcome con menu a griglia -->
                <?php if (isset($component)) { $__componentOriginal96e007dd5d3324966b6162c352c6e576 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal96e007dd5d3324966b6162c352c6e576 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.radial-grid-menu','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('radial-grid-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal96e007dd5d3324966b6162c352c6e576)): ?>
<?php $attributes = $__attributesOriginal96e007dd5d3324966b6162c352c6e576; ?>
<?php unset($__attributesOriginal96e007dd5d3324966b6162c352c6e576); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal96e007dd5d3324966b6162c352c6e576)): ?>
<?php $component = $__componentOriginal96e007dd5d3324966b6162c352c6e576; ?>
<?php unset($__componentOriginal96e007dd5d3324966b6162c352c6e576); ?>
<?php endif; ?>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Users\vince\OneDrive\Desktop\gestionale-divani\resources\views/dashboard.blade.php ENDPATH**/ ?>