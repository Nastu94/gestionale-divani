<?php echo e($slot); ?>

<?php /**PATH C:\Users\vince\OneDrive\Desktop\gestionale-divani\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>