



<div  
      class="relative bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-y-auto
             max-h-[90vh] w-full max-w-2xl p-6 z-10">

    
    <div class="flex justify-between items-center mb-4">
        <h3 class="text-lg font-semibold text-gray-900 dark:text-gray-100">Nuovo Magazzino</h3>
        <button type="button" @click="showModal = false"
                class="text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 focus:outline-none">
            <i class="fas fa-times"></i>
        </button>
    </div>

    
    <form action="<?php echo e(route('warehouses.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="space-y-4">
            
            <div>
                <label for="code" class="block text-xs font-medium text-gray-700 dark:text-gray-300">Codice</label>
                <input id="code" name="code" type="text" required
                       class="mt-1 block w-full px-3 py-2 border rounded-md bg-gray-50 dark:bg-gray-700
                              text-sm text-gray-900 dark:text-gray-100">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-600 text-xs mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>

            
            <div>
                <label for="name" class="block text-xs font-medium text-gray-700 dark:text-gray-300">Nome</label>
                <input id="name" name="name" type="text" required
                       class="mt-1 block w-full px-3 py-2 border rounded-md bg-gray-50 dark:bg-gray-700
                              text-sm text-gray-900 dark:text-gray-100">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-600 text-xs mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>

            
            <div>
                <label for="type" class="block text-xs font-medium text-gray-700 dark:text-gray-300">Tipo</label>
                <select id="type" name="type"
                        class="mt-1 block w-full px-3 py-2 border rounded-md bg-gray-50 dark:bg-gray-700
                               text-sm text-gray-900 dark:text-gray-100">
                    <option value="stock">Stock</option>
                    <option value="commitment">Impegnato</option>
                    <option value="scrap">Scarto</option>
                    
                </select>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-600 text-xs mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>

        
        <div class="mt-6 flex justify-end space-x-2">
            <button type="button" @click="showModal = false"
                    class="inline-flex items-center px-3 py-1.5 border rounded-md text-xs font-semibold
                           text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600">
                Annulla
            </button>
            <button type="submit"
                    class="inline-flex items-center px-3 py-1.5 bg-purple-600 rounded-md text-xs font-semibold
                           text-white uppercase hover:bg-purple-500 focus:outline-none focus:ring-2
                           focus:ring-purple-300 transition">
                <i class="fas fa-save mr-1"></i> Salva
            </button>
        </div>
    </form>
</div>
<?php /**PATH C:\Users\vince\OneDrive\Desktop\gestionale-divani\resources\views/components/warehouse-create-modal.blade.php ENDPATH**/ ?>