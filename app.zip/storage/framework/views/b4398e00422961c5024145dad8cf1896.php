

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-wrap items-center justify-between">
            <h2 class="font-semibold text-lg text-gray-800 dark:text-gray-200 leading-tight">
                <?php echo e(__('Ordini Fornitore')); ?>

            </h2>
            <?php if (isset($component)) { $__componentOriginalac227964a792ab0ae2fb10589fa2a511 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalac227964a792ab0ae2fb10589fa2a511 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard-tiles','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard-tiles'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalac227964a792ab0ae2fb10589fa2a511)): ?>
<?php $attributes = $__attributesOriginalac227964a792ab0ae2fb10589fa2a511; ?>
<?php unset($__attributesOriginalac227964a792ab0ae2fb10589fa2a511); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalac227964a792ab0ae2fb10589fa2a511)): ?>
<?php $component = $__componentOriginalac227964a792ab0ae2fb10589fa2a511; ?>
<?php unset($__componentOriginalac227964a792ab0ae2fb10589fa2a511); ?>
<?php endif; ?>
        </div>
        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
            <div
                x-data="{ show: true }"
                x-init="setTimeout(() => show = false, 10000)"
                x-show="show"
                x-transition.opacity.duration.500ms
                class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mt-2"
                role="alert"
            >
                <i class="fas fa-check-circle mr-2"></i>
                <span class="block sm:inline"><?php echo e(session('success')); ?></span>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('error')): ?>
            <div
                x-data="{ show: true }"
                x-init="setTimeout(() => show = false, 10000)"
                x-show="show"
                x-transition.opacity.duration.500ms
                class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mt-2"
                role="alert"
            >
                <i class="fas fa-exclamation-triangle mr-2"></i>
                <span class="block sm:inline"><?php echo e(session('error')); ?></span>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
     <?php $__env->endSlot(); ?>

    
    <div class="py-6">
        <div
            x-data="{
                openId: null,
                
                openCreate() {
                    window.dispatchEvent(new CustomEvent('open-supplier-order-modal'))
                },
                openEdit(id) {
                    window.dispatchEvent(
                        new CustomEvent('open-supplier-order-modal', { detail: { orderId: id } })
                    )
                },
                sidebarOpen       : false,
                sidebarLines      : [],
                sidebarOrderNumber: null,
                sidebarLoading    : false,
                formatCurrency(v){ return Intl.NumberFormat('it-IT',{minimumFractionDigits:2}).format(v); },
                openSidebar(id, num) {
                    this.sidebarOpen    = true
                    this.sidebarLoading = true
                    this.sidebarLines   = []
                    this.sidebarOrderNumber = num

                    fetch(`/orders/supplier/${id}/lines`, {
                        headers     : { Accept: 'application/json' },
                        credentials : 'same-origin'
                    })
                    .then(r => {
                        if (!r.ok) throw new Error('Errore ' + r.status)
                        return r.json()
                    })
                    .then(rows => {
                        this.sidebarLines   = rows
                        this.sidebarLoading = false
                    })
                    .catch(e => {
                        alert('Impossibile caricare le righe')
                        console.error(e)
                        this.sidebarLoading = false
                    })
                },
            }"
            class="max-w-full mx-auto sm:px-6 lg:px-8"
        >
            <div class="bg-white dark:bg-gray-800 shadow sm:rounded-lg">

                
                <div class="flex justify-end m-2 p-2">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('orders.supplier.create')): ?>
                        <button
                            @click="openCreate"
                            class="inline-flex items-center m-2 px-3 py-1.5 bg-purple-600 rounded-md
                                        text-xs font-semibold text-white uppercase hover:bg-purple-500
                                        focus:outline-none focus:ring-2 focus:ring-purple-300 transition"
                        >
                            <i class="fas fa-plus mr-1"></i> Nuovo
                        </button>
                    <?php endif; ?>
                </div>

                
                <div class="overflow-x-auto p-4">
                    <table class="table-auto min-w-full text-sm divide-y divide-gray-200 dark:divide-gray-700">
                        <thead class="bg-gray-300 dark:bg-gray-700 uppercase tracking-wider">
                            <tr>
                                <?php if (isset($component)) { $__componentOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.th-menu','data' => ['field' => 'id','label' => 'Ordine #','sort' => $sort,'dir' => $dir,'filters' => $filters,'resetRoute' => 'orders.supplier.index','filterable' => false,'align' => 'left']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('th-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'id','label' => 'Ordine #','sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'dir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dir),'filters' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($filters),'reset-route' => 'orders.supplier.index','filterable' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false),'align' => 'left']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235)): ?>
<?php $attributes = $__attributesOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235; ?>
<?php unset($__attributesOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235)): ?>
<?php $component = $__componentOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235; ?>
<?php unset($__componentOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.th-menu','data' => ['field' => 'supplier','label' => 'Fornitore','sort' => $sort,'dir' => $dir,'filters' => $filters,'resetRoute' => 'orders.supplier.index']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('th-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'supplier','label' => 'Fornitore','sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'dir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dir),'filters' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($filters),'reset-route' => 'orders.supplier.index']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235)): ?>
<?php $attributes = $__attributesOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235; ?>
<?php unset($__attributesOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235)): ?>
<?php $component = $__componentOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235; ?>
<?php unset($__componentOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.th-menu','data' => ['field' => 'ordered_at','label' => 'Data Ordine','sort' => $sort,'dir' => $dir,'filters' => $filters,'resetRoute' => 'orders.supplier.index','filterable' => false]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('th-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'ordered_at','label' => 'Data Ordine','sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'dir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dir),'filters' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($filters),'reset-route' => 'orders.supplier.index','filterable' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235)): ?>
<?php $attributes = $__attributesOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235; ?>
<?php unset($__attributesOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235)): ?>
<?php $component = $__componentOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235; ?>
<?php unset($__componentOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.th-menu','data' => ['field' => 'delivery_date','label' => 'Data Consegna','sort' => $sort,'dir' => $dir,'filters' => $filters,'resetRoute' => 'orders.supplier.index','filterable' => false]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('th-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'delivery_date','label' => 'Data Consegna','sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'dir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dir),'filters' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($filters),'reset-route' => 'orders.supplier.index','filterable' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235)): ?>
<?php $attributes = $__attributesOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235; ?>
<?php unset($__attributesOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235)): ?>
<?php $component = $__componentOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235; ?>
<?php unset($__componentOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.th-menu','data' => ['field' => 'total','label' => 'Valore (€)','sort' => $sort,'dir' => $dir,'filters' => $filters,'resetRoute' => 'orders.supplier.index','filterable' => false,'align' => 'left']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('th-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'total','label' => 'Valore (€)','sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'dir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dir),'filters' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($filters),'reset-route' => 'orders.supplier.index','filterable' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false),'align' => 'left']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235)): ?>
<?php $attributes = $__attributesOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235; ?>
<?php unset($__attributesOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235)): ?>
<?php $component = $__componentOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235; ?>
<?php unset($__componentOriginal2cd4a4a9fbcf85b08ff6ec106d7f0235); ?>
<?php endif; ?>
                            </tr>
                        </thead>

                        <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $canEdit   = auth()->user()->can('orders.supplier.update');
                                    $canDelete = auth()->user()->can('orders.supplier.delete');
                                    $canCrud   = $canEdit || $canDelete;
                                ?>

                                
                                <tr
                                    <?php if($canCrud || auth()->user()->can('orders.supplier.view')): ?>
                                        @click="openId = (openId === <?php echo e($order->id); ?> ? null : <?php echo e($order->id); ?>)"
                                        class="cursor-pointer hover:bg-gray-200 dark:hover:bg-gray-700"
                                        :class="openId === <?php echo e($order->id); ?> ? 'bg-gray-200 dark:bg-gray-700' : ''"
                                    <?php endif; ?>
                                >
                                    <td class="px-6 py-2 text-center"><?php echo e($order->orderNumber->number); ?></td>
                                    <td class="px-6 py-2"><?php echo e($order->supplier?->name); ?></td>
                                    <td class="px-6 py-2"><?php echo e($order->ordered_at?->format('d/m/Y')); ?></td>
                                    <td class="px-6 py-2"><?php echo e($order->delivery_date?->format('d/m/Y')); ?></td>
                                    <td class="px-6 py-2 text-center"><?php echo e(number_format($order->total, 2, ',', '.')); ?></td>
                                </tr>

                                
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($canCrud || auth()->user()->can('orders.supplier.view')): ?>
                                <tr x-show="openId === <?php echo e($order->id); ?>" x-cloak>
                                    <td :colspan="5" class="px-6 py-3 bg-gray-200 dark:bg-gray-700">
                                        <div class="flex items-center space-x-4 text-xs">

                                            
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('orders.supplier.view')): ?>
                                                <button type="button"
                                                        @click.stop="openSidebar(<?php echo e($order->id); ?>, <?php echo e($order->number); ?>)"
                                                        class="inline-flex items-center hover:text-blue-600">
                                                    <i class="fas fa-eye mr-1"></i> Visualizza
                                                </button>
                                            <?php endif; ?>

                                            
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($canEdit && !isset($order->bill_number)): ?>
                                                <button
                                                    type="button"
                                                    @click.stop="openEdit(<?php echo e($order->id); ?>)"
                                                    class="inline-flex items-center hover:text-yellow-600"
                                                >
                                                    <i class="fas fa-pencil-alt mr-1"></i> Modifica
                                                </button>
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                            
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($canDelete && !isset($order->bill_number)): ?>
                                                <form
                                                    action="<?php echo e(route('orders.supplier.destroy', $order)); ?>"
                                                    method="POST"
                                                    onsubmit="return confirm('Confermi di voler eliminare l\'ordine #<?php echo e($order->orderNumber->number); ?>?');"
                                                >
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button
                                                        type="submit"
                                                        class="inline-flex items-center hover:text-red-600"
                                                    >
                                                        <i class="fas fa-trash-alt mr-1"></i> Elimina
                                                    </button>
                                                </form>
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                        </div>
                                    </td>
                                </tr>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                            
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($orders->isEmpty()): ?>
                                <tr>
                                    <td colspan="6" class="px-6 py-2 text-center text-gray-500">Nessun risultato trovato.</td>
                                </tr>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </tbody>
                    </table>
                </div>

                
                <div class="mt-4 px-6 py-2">
                    <?php echo e($orders->links('vendor.pagination.tailwind-compact')); ?>

                </div>
            </div>
            
            
            <?php if (isset($component)) { $__componentOriginal6671b851a598a0aca697c881c4405751 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6671b851a598a0aca697c881c4405751 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.supplier-order-create-modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('supplier-order-create-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6671b851a598a0aca697c881c4405751)): ?>
<?php $attributes = $__attributesOriginal6671b851a598a0aca697c881c4405751; ?>
<?php unset($__attributesOriginal6671b851a598a0aca697c881c4405751); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6671b851a598a0aca697c881c4405751)): ?>
<?php $component = $__componentOriginal6671b851a598a0aca697c881c4405751; ?>
<?php unset($__componentOriginal6671b851a598a0aca697c881c4405751); ?>
<?php endif; ?>

            
            <div x-show="sidebarOpen"
                x-cloak
                class="fixed inset-0 z-50 flex justify-end">

                
                <div class="flex-1 bg-black/50" @click="sidebarOpen=false"></div>

                
                <div class="w-full max-w-lg bg-white dark:bg-gray-900 shadow-xl
                            overflow-y-auto"
                    x-transition:enter="transition transform duration-300"
                    x-transition:enter-start="translate-x-full"
                    x-transition:leave="transition transform duration-300"
                    x-transition:leave-end="translate-x-full">

                    <div class="p-6 border-b flex justify-between items-center">
                        <h3 class="text-lg font-semibold">
                            Righe ordine #
                            <span x-text="sidebarOrderNumber"></span>
                        </h3>
                        <button @click="sidebarOpen=false">
                            <i class="fas fa-times text-gray-600"></i>
                        </button>
                    </div>

                    <!-- overlay spinner -->
                    <div x-show="sidebarLoading"
                        x-transition.opacity
                        x-cloak
                        class="absolute inset-0 flex items-center justify-center bg-white/70">
                        <i class="fas fa-circle-notch fa-spin text-3xl text-gray-600"></i>
                    </div>

                    <div x-show="sidebarLines.length > 0" class="p-4">
                        <table class="w-full text-sm border divide-y">
                            <thead class="bg-gray-100">
                                <tr>
                                    <th class="px-2 py-1">Codice</th>
                                    <th class="px-2 py-1">Componente</th>
                                    <th class="px-2 py-1 w-14 text-right">Q.tà</th>
                                    <th class="px-2 py-1 w-14">Unit</th>
                                    <th class="px-2 py-1 w-20 text-right">Prezzo</th>
                                    <th class="px-2 py-1 w-24 text-right">Subtot.</th>
                                </tr>
                            </thead>
                            <tbody>
                                <template x-for="row in sidebarLines" :key="row.code">
                                    <tr>
                                        <td class="px-2 py-1" x-text="row.code"></td>
                                        <td class="px-2 py-1">
                                            <div x-text="row.desc"></div>

                                            
                                            <template x-if="row.color_notes">
                                                <div class="mt-1 text-[11px] text-gray-600 whitespace-pre-line">
                                                    <span x-text="row.color_notes"></span>
                                                </div>
                                            </template>
                                        </td>
                                        <td class="px-2 py-1 text-right" x-text="row.qty"></td>
                                        <td class="px-2 py-1 uppercase" x-text="row.unit"></td>
                                        <td class="px-2 py-1 text-right"
                                            x-text="formatCurrency(row.price)"></td>
                                        <td class="px-2 py-1 text-right"
                                            x-text="formatCurrency(row.subtot)"></td>
                                    </tr>
                                </template>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\vince\OneDrive\Desktop\gestionale-divani\resources\views/pages/orders/index-suppliers.blade.php ENDPATH**/ ?>