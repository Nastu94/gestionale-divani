

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-wrap items-center justify-between">
            <h2 class="font-semibold text-lg text-gray-800 dark:text-gray-200 leading-tight">
                <?php echo e(__('Magazzini')); ?>

            </h2>
            <?php if (isset($component)) { $__componentOriginalac227964a792ab0ae2fb10589fa2a511 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalac227964a792ab0ae2fb10589fa2a511 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard-tiles','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard-tiles'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalac227964a792ab0ae2fb10589fa2a511)): ?>
<?php $attributes = $__attributesOriginalac227964a792ab0ae2fb10589fa2a511; ?>
<?php unset($__attributesOriginalac227964a792ab0ae2fb10589fa2a511); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalac227964a792ab0ae2fb10589fa2a511)): ?>
<?php $component = $__componentOriginalac227964a792ab0ae2fb10589fa2a511; ?>
<?php unset($__componentOriginalac227964a792ab0ae2fb10589fa2a511); ?>
<?php endif; ?>
        </div>

        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = ['success' => 'green', 'error' => 'red']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session($key)): ?>
                <div  x-data="{ show: true }"
                      x-init="setTimeout(() => show = false, 10000)"
                      x-show="show"
                      x-transition.opacity.duration.500ms
                      class="bg-<?php echo e($color); ?>-100 border border-<?php echo e($color); ?>-400 text-<?php echo e($color); ?>-700 px-4 py-3 rounded relative mt-2"
                      role="alert"
                >
                    <i class="fas <?php echo e($key === 'success' ? 'fa-check-circle' : 'fa-exclamation-triangle'); ?> mr-2"></i>
                    <span class="block sm:inline"><?php echo e(session($key)); ?></span>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
     <?php $__env->endSlot(); ?>

    <div class="py-6">
        
        <div x-data="warehouseCrud()" class="max-w-full mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 shadow sm:rounded-lg">

                
                <div class="flex justify-end m-2 p-2">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('warehouses.create')): ?>
                        <button  @click="openCreate"
                                 class="inline-flex items-center m-2 px-3 py-1.5 bg-purple-600 rounded-md
                                        text-xs font-semibold text-white uppercase hover:bg-purple-500
                                        focus:outline-none focus:ring-2 focus:ring-purple-300 transition">
                            <i class="fas fa-plus mr-1"></i> Nuovo
                        </button>
                    <?php endif; ?>

                    
                    <button  type="button"
                             @click="extended = !extended"
                             class="inline-flex items-center m-2 px-3 py-1.5 bg-indigo-600 rounded-md text-xs font-semibold text-white uppercase
                                    hover:bg-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-900 transition">
                        <i class="fas p-1" :class="extended ? 'fa-compress' : 'fa-expand'"></i>
                        <span x-text="extended ? 'Comprimi tabella' : 'Estendi tabella'"></span>
                    </button>
                </div>

                
                <div x-show="showModal" x-cloak class="fixed inset-0 z-50 flex items-center justify-center">
                    <div class="absolute inset-0 bg-black opacity-75"></div>
                    <div class="relative z-10 w-full max-w-2xl">
                        <?php if (isset($component)) { $__componentOriginald77f3f8c53ccc625c16316bc3bc28763 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald77f3f8c53ccc625c16316bc3bc28763 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.warehouse-create-modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('warehouse-create-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald77f3f8c53ccc625c16316bc3bc28763)): ?>
<?php $attributes = $__attributesOriginald77f3f8c53ccc625c16316bc3bc28763; ?>
<?php unset($__attributesOriginald77f3f8c53ccc625c16316bc3bc28763); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald77f3f8c53ccc625c16316bc3bc28763)): ?>
<?php $component = $__componentOriginald77f3f8c53ccc625c16316bc3bc28763; ?>
<?php unset($__componentOriginald77f3f8c53ccc625c16316bc3bc28763); ?>
<?php endif; ?>
                    </div>
                </div>

                
                <div class="overflow-x-auto p-4">
                    <table class="table-auto min-w-full text-sm divide-y divide-gray-200 dark:divide-gray-700">
                        <thead class="bg-gray-300 dark:bg-gray-700 uppercase tracking-wider">
                            <tr>
                                <th class="px-6 py-2 text-left">#</th>
                                <th class="px-6 py-2 text-left">Codice</th>
                                <th class="px-6 py-2 text-left">Nome</th>
                                
                                <th x-show="extended" x-cloak class="px-6 py-2 text-left">Tipo</th>
                                <th class="px-6 py-2 text-center">Attivo</th>
                            </tr>
                        </thead>

                        <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $canToggle = auth()->user()->can('warehouses.update');
                                ?>

                                
                                <tr  <?php if($canToggle && $warehouse->id !== 1): ?>
                                         @click="openId = (openId === <?php echo e($warehouse->id); ?> ? null : <?php echo e($warehouse->id); ?>)"
                                         class="cursor-pointer hover:bg-gray-200 dark:hover:bg-gray-700"
                                         :class="openId === <?php echo e($warehouse->id); ?> ? 'bg-gray-200 dark:bg-gray-700' : ''"
                                     <?php endif; ?>
                                >
                                    <td class="px-6 py-2 whitespace-nowrap">
                                        <?php echo e($loop->iteration + ($warehouses->currentPage()-1)*$warehouses->perPage()); ?>

                                    </td>
                                    <td class="px-6 py-2 whitespace-nowrap"><?php echo e($warehouse->code); ?></td>
                                    <td class="px-6 py-2 whitespace-nowrap"><?php echo e($warehouse->name); ?></td>

                                    
                                    <td x-show="extended" x-cloak class="px-6 py-2 whitespace-nowrap"><?php echo e($warehouse->type); ?></td>

                                    
                                    <td class="px-6 py-2 text-center whitespace-nowrap">
                                        <span  class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium"
                                               :class="{
                                                   'bg-green-100 text-green-800': <?php echo e($warehouse->is_active ? 'true' : 'false'); ?>,
                                                   'bg-red-100 text-red-800'  : <?php echo e($warehouse->is_active ? 'false' : 'true'); ?>

                                               }">
                                            <?php echo e($warehouse->is_active ? 'Sì' : 'No'); ?>

                                        </span>
                                    </td>
                                </tr>

                                
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($canToggle && $warehouse->id !== 1): ?>
                                    <tr x-show="openId === <?php echo e($warehouse->id); ?>" x-cloak>
                                        <td :colspan="extended ? 5 : 4" class="px-6 py-3 bg-gray-200 dark:bg-gray-700">
                                            <div class="flex items-center space-x-4 text-xs">
                                                <form  action="<?php echo e(route('warehouses.update', $warehouse)); ?>"
                                                       method="POST"
                                                       onsubmit="return confirm('<?php echo e($warehouse->is_active ? 'Disattivare' : 'Ripristinare'); ?> il magazzino?');">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PUT'); ?>
                                                    
                                                    <input type="hidden" name="is_active" value="<?php echo e($warehouse->is_active ? 0 : 1); ?>">
                                                    <button type="submit"
                                                            class="inline-flex items-center hover:text-<?php echo e($warehouse->is_active ? 'red-600' : 'green-600'); ?>">
                                                        <i class="fas <?php echo e($warehouse->is_active ? 'fa-ban mr-1' : 'fa-undo mr-1'); ?>"></i>
                                                        <?php echo e($warehouse->is_active ? 'Disattiva' : 'Ripristina'); ?>

                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </tbody>
                    </table>
                </div>

                
                <div class="mt-4 px-6 py-2">
                    <?php echo e($warehouses->links('vendor.pagination.tailwind-compact')); ?>

                </div>
            </div>
        </div>
    </div>

    
    <?php $__env->startPush('scripts'); ?>
    <script>
        document.addEventListener('alpine:init', () => {
            Alpine.data('warehouseCrud', () => ({
                // Modal
                showModal: false,

                // Gestione riga espansa e colonna tipo
                openId:   null,
                extended: false,

                openCreate() { this.showModal = true; },

                init() {
                    <?php if($errors->any()): ?>
                        // Riapre il modal se il backend ha ritornato errori di validazione
                        this.showModal = true;
                    <?php endif; ?>
                },
            }));
        });
    </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\vince\OneDrive\Desktop\gestionale-divani\resources\views/pages/warehouse/index.blade.php ENDPATH**/ ?>