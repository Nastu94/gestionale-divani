<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = ['success'=>'green','error'=>'red']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session()->has($k)): ?>
        <div  x-data="{ show:true }"
              x-init="setTimeout(()=>show=false,10000)"
              x-show="show"
              x-transition.opacity
              class="flex justify-between bg-<?php echo e($c); ?>-100 border border-<?php echo e($c); ?>-400
                     text-<?php echo e($c); ?>-700 px-4 py-3 rounded relative mb-2">
            <div>
                <i class="fas <?php echo e($k=='success' ? 'fa-check-circle' : 'fa-exclamation-triangle'); ?> mr-2"></i>
                <?php echo nl2br(e(session($k))); ?>

            </div>
            
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($canForceReservation && !empty($forceMissingComponents)): ?>
                <button
                    type="button"
                    class="inline-flex items-center px-3 py-1.5
                            bg-red-900 hover:bg-red-800
                            text-xs font-semibold text-white rounded-md"
                    wire:click="openForceReservation"
                >
                    Forza Prenotazione
                </button>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php /**PATH C:\Users\vince\OneDrive\Desktop\gestionale-divani\resources\views/components/flash.blade.php ENDPATH**/ ?>