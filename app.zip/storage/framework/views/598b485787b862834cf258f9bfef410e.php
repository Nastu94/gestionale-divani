

<table class="min-w-full text-sm divide-y divide-gray-300">
    <thead class="bg-gray-200">
        <tr>
            <th class="px-3 py-1">Codice</th>
            <th class="px-3 py-1">Descrizione</th>
            <th class="px-3 py-1">UM</th>
            <th class="px-3 py-1 text-right">Totale</th>
            <th class="px-3 py-1 text-right">Riservato</th>
        </tr>
    </thead>
    <tbody>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="px-3 py-0.5"><?php echo e($row->component_code); ?></td>
                <td class="px-3 py-0.5"><?php echo e($row->component_description); ?></td>
                <td class="px-3 py-0.5"><?php echo e($row->uom); ?></td>
                <td class="px-3 py-0.5 text-right"><?php echo e($row->quantity); ?></td>
                <td class="px-3 py-0.5 text-right"><?php echo e($row->reserved_quantity); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </tbody>
</table>
<?php /**PATH C:\Users\vince\OneDrive\Desktop\gestionale-divani\resources\views/components/stock-levels-static-table.blade.php ENDPATH**/ ?>