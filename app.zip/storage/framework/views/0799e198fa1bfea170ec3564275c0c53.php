



<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'field',           // es. customer
    'label',           // testo header
    'sort'       => null,
    'dir'        => 'asc',
    'filters'    => [],
    'filterable' => true,
    'align'      => 'left',
    'page'       => 1,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'field',           // es. customer
    'label',           // testo header
    'sort'       => null,
    'dir'        => 'asc',
    'filters'    => [],
    'filterable' => true,
    'align'      => 'left',
    'page'       => 1,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php  $alignClass = $align === 'right' ? 'right-0' : 'left-0'; ?>

<th <?php echo e($attributes->merge(['class'=>'px-6 py-2 text-left relative'])); ?>

    x-data="(() => ({
        /* Livewire ⇄ Alpine */
        
        filter : <?php if ((object) ('filters.' . $field) instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('filters.' . $field->value()); ?>')<?php echo e('filters.' . $field->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('filters.' . $field); ?>')<?php endif; ?>.defer,
        sort   : <?php if ((object) ('sort') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('sort'->value()); ?>')<?php echo e('sort'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('sort'); ?>')<?php endif; ?>.live,
        dir    : <?php if ((object) ('dir') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('dir'->value()); ?>')<?php echo e('dir'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('dir'); ?>')<?php endif; ?>.live,

        open    : false,
        top     : null,   // coordinate runtime
        left    : null,
        right   : null,   // servirà per align = 'right'

        /* ---------- helpers ---------- */
        /** calcola le coordinate del trigger */
        updatePos() {
            const r = this.$refs.trigger.getBoundingClientRect();
            this.top = r.bottom + window.scrollY;
            if ('<?php echo e($align); ?>' === 'right') {
                this.right = window.innerWidth - r.right - window.scrollX;
                this.left  = null;
            } else {
                this.left  = r.left + window.scrollX;
                this.right = null;
            }
        },

        /** apre o chiude il menu */
        toggle() {
            if (this.open) { this.open = false; return; }
            window.dispatchEvent(new Event('close-th-menus'));
            this.updatePos();               // ① posizione iniziale
            this.open = true;
        },

        init() {
            /* chiudi se altri menu si aprono */
            window.addEventListener('close-th-menus', () => this.open = false);

            /* ri-allinea durante scroll/resize (capture=true → becca anche
               lo scroll del wrapper overflow-auto)                     */
            const sync = () => { if (this.open) this.updatePos(); };
            window.addEventListener('scroll',  sync, true);
            window.addEventListener('resize', sync);
        },

        sortAsc(){  this.sort = '<?php echo e($field); ?>'; this.dir = 'asc';  this.open = false },
        sortDesc(){ this.sort = '<?php echo e($field); ?>'; this.dir = 'desc'; this.open = false },

        /* ---------- FILTRO ---------- */
        apply(){                          // clic su “Applica”
            $wire.set('filters.<?php echo e($field); ?>', this.filter);
            this.open = false;
        },
        clear(){                          // clic su “Azzera filtri”
            this.filter = '';                                     // reset locale
            this.sort = '';
            this.dir = 'asc';
            $wire.set('filters.<?php echo e($field); ?>', '');               // ③ invia reset
            this.open = false;
        },
    }))()"
    @keydown.escape.window="open = false"
    :class="open && 'bg-gray-100 dark:bg-gray-700'"
>
    
    <button  type="button"
             x-ref="trigger"             
             @click.prevent="toggle"
             class="flex items-center gap-1 hover:text-indigo-600 uppercase tracking-wider">
        <?php echo e($label); ?>

        <template x-if="sort === '<?php echo e($field); ?>'">
            <i :class="dir === 'asc' ? 'fas fa-sort-up' : 'fas fa-sort-down'"></i>
        </template>
    </button>

    
    <template x-teleport="#portal-target">
        <div x-show="open"
             x-transition.opacity
             x-cloak
             x-bind:style="{
                 position: 'fixed',
                 top  : top  + 'px',
                 left : left  !== null ? left  + 'px' : null,
                 right: right !== null ? right + 'px' : null
             }"
             @click.outside="open = false"
             class="w-48 z-50 bg-white dark:bg-gray-800 rounded shadow
                    text-sm divide-y divide-gray-200 dark:divide-gray-700">

            
            <div class="py-1">
                <button type="button" @click.prevent="sortAsc"
                        class="w-full text-left px-3 py-1 hover:bg-gray-100 dark:hover:bg-gray-700">
                    <i class="fa-solid fa-arrow-up-short-wide mr-1"></i><b>Crescente</b>
                </button>
                <button type="button" @click.prevent="sortDesc"
                        class="w-full text-left px-3 py-1 hover:bg-gray-100 dark:hover:bg-gray-700">
                    <i class="fa-solid fa-arrow-down-wide-short mr-1"></i><b>Decrescente</b>
                </button>
            </div>

            
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($filterable): ?>
                <div class="py-1">
                    <div class="px-3 py-1 text-xs">
                        <input x-model.defer="filter"
                               type="text"
                               placeholder="Filtra <?php echo e(strtolower($label)); ?>…"
                               class="w-full border rounded px-1 py-0.5
                                      focus:ring-indigo-500 focus:border-indigo-500">
                    </div>
                    <button type="button" @click.prevent="apply"
                            class="w-full text-left px-3 py-1 text-indigo-600 hover:underline text-xs">
                        <b>Applica</b>
                    </button>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            
            <div class="py-1">
                <button type="button" @click.prevent="clear"
                        class="w-full text-left px-3 py-1 text-red-600 hover:bg-gray-100 dark:hover:bg-gray-700 text-xs">
                    <b>Azzera filtri</b>
                </button>
            </div>
        </div>
    </template>
</th>
<?php /**PATH C:\Users\vince\OneDrive\Desktop\gestionale-divani\resources\views/components/th-menu-live.blade.php ENDPATH**/ ?>