

<?php
/**
 * Componente Sidebar – Gestionale Divani v3.0
 *
 * - Accordion “una sola sezione aperta” usando `openSection` dal layout
 * - Nessun `x-data` proprio: eredita `isOpen` e `openSection` dal genitore
 * - Fa parte del layout Flex (non è più fixed)
 */
?>
<aside
    x-cloak
    x-show="isOpen"
    x-transition:enter="transition-all duration-200"
    x-transition:leave="transition-all duration-200"
    :class="isOpen ? 'w-48 sm:w-56 md:w-64' : 'w-0'"
    class="overflow-hidden bg-white dark:bg-gray-800 border-r dark:border-gray-700 flex flex-col"
>
    
    <div class="h-16 flex items-center justify-center">
        
    </div>

    
    <div class="border-b border-gray-200 dark:border-gray-700">
        <?php $dashboardActive = request()->routeIs('dashboard'); ?>
        <a
            href="<?php echo e(route('dashboard')); ?>"
            class="block px-8 py-2 text-sm transition-colors font-semibold
                   <?php echo e($dashboardActive
                        ? 'bg-gray-200 dark:bg-gray-700 text-gray-900 dark:text-gray-100'
                        : 'text-gray-700 hover:bg-gray-100 dark:text-gray-200 dark:hover:bg-gray-700'); ?>"
        >
            <div class="flex items-center">
                <span class="font-semibold"><?php echo e(__('Dashboard')); ?></span>
            </div>
        </a>
    </div>

    
    <?php
        $unreadAlertsCount = \App\Models\Alert::where('is_read', false)->count();
    ?>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = config('menu.sidebar'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            // filtro gli items cui l'utente ha effettivo accesso
            $accessible = collect($section['items'])
                ->filter(fn($item) => empty($item['permission']) || auth()->user()->can($item['permission']));
        ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($accessible->isEmpty()): ?>
            <?php continue; ?>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <div class="border-b border-gray-200 dark:border-gray-700">
            
            <button
                @click="openSection = (openSection === <?php echo e($i); ?> ? null : <?php echo e($i); ?>)"
                class="w-full flex justify-between items-center px-6 py-3 hover:bg-gray-100 dark:hover:bg-gray-700 focus:outline-none"
            >
                <span class="font-semibold text-gray-700 dark:text-gray-200">
                    <?php echo e(__($section['section'])); ?>

                </span>
                <i
                    :class="openSection === <?php echo e($i); ?> ? 'fas fa-chevron-up' : 'fas fa-chevron-down'"
                    class="text-gray-500 dark:text-gray-400"
                ></i>
            </button>

            
            <ul
                x-show="openSection === <?php echo e($i); ?>"
                x-transition
                class="space-y-1 bg-gray-50 dark:bg-gray-900"
            >
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $accessible; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $isActive = request()->routeIs($item['route']);
                        $badgeName = $item['badge_count'] ?? null;
                        $badgeCount = match ($badgeName) {
                            'alerts_unread' => $unreadAlertsCount,
                            default => 0,
                        };
                    ?>
                    <li>
                        <a
                            href="<?php echo e(route($item['route'])); ?>"
                            class="flex justify-between items-center px-8 py-2 text-sm transition-colors
                                   <?php echo e($isActive
                                        ? 'bg-gray-200 dark:bg-gray-700 font-medium text-gray-900 dark:text-gray-100'
                                        : 'text-gray-700 hover:bg-gray-100 dark:text-gray-200 dark:hover:bg-gray-700'); ?>"
                        >
                            <span><?php echo e(__($item['label'])); ?></span>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($badgeCount > 0): ?>
                                <span class="ml-auto inline-flex min-w-5 items-center justify-center rounded-full bg-red-600 px-1.5 py-0.5 text-xs font-semibold text-white">
                                    <?php echo e($badgeCount > 99 ? '99+' : $badgeCount); ?>

                                </span>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </ul>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</aside><?php /**PATH C:\Users\vince\OneDrive\Desktop\gestionale-divani\resources\views/components/sidebar.blade.php ENDPATH**/ ?>