
<?php
    use Illuminate\Support\Facades\Gate;

    /* ------- 1. Sezioni visibili in base ai permessi ------------------- */
    $visibleSections = collect(config('menu.grid_menu'))
        ->filter(fn($s)=>Gate::any(collect($s['items'])->pluck('permission')->all()))
        ->values();

    /* ------- 2. Offset radiale (max 8) -------------------------------- */
    $offsets = [
        ['x'=> 0,'y'=>-90], ['x'=> 90,'y'=>  0],
        ['x'=> 0,'y'=> 90], ['x'=>-90,'y'=>  0],
        ['x'=> 60,'y'=>-60],['x'=> 60,'y'=> 60],
        ['x'=>-60,'y'=> 60],['x'=>-60,'y'=>-60],
    ];
?>

<?php if (! $__env->hasRenderedOnce('20d8353a-25d5-4359-a805-6f1110c112cf')): $__env->markAsRenderedOnce('20d8353a-25d5-4359-a805-6f1110c112cf'); ?>
<?php $__env->startPush('scripts'); ?>
<script>
/* ---------- helper: antenato scrollabile + centratura ----------------- */
function scrollParent(el){
    for(let p=el.parentElement;p&&p!==document.body;p=p.parentElement){
        const s=getComputedStyle(p);
        if(/(auto|scroll)/.test(s.overflow+s.overflowY+s.overflowX)) return p;
    }
    return document.scrollingElement||document.documentElement;
}
function centerTile(el){
    const par   = scrollParent(el);
    const rect  = el.getBoundingClientRect();
    const prect = par.getBoundingClientRect();
    const target = par.scrollTop + rect.top - prect.top - (par.clientHeight/2) + (rect.height/2);
    par.scrollTo({top: target, behavior:'smooth'});
}
</script>
<?php $__env->stopPush(); ?>
<?php endif; ?>

<div
    x-data="menuGrid()"
    x-init="init()"
    class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3
           gap-x-10 overflow-visible transition-all duration-100"
    :style="gridStyle()"
    x-cloak
>
<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $visibleSections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div x-ref="tile<?php echo e($i); ?>" class="relative flex justify-center">

        
        <button
            :data-row="Math.floor(<?php echo e($i); ?> / columns)"
            @click.stop="toggle(<?php echo e($i); ?>)"
            class="w-28 h-28 bg-white dark:bg-gray-800 rounded-lg shadow
                   flex flex-col items-center justify-center
                   hover:bg-indigo-50 dark:hover:bg-indigo-900
                   transition-all duration-100">
            <i class="fas <?php echo e($section['icon']); ?> text-3xl text-indigo-600 dark:text-indigo-400"></i>
            <span class="mt-1 text-sm font-medium text-gray-800 dark:text-gray-200">
                <?php echo e($section['section']); ?>

            </span>
        </button>

        
        <template x-if="openKey === <?php echo e($i); ?>">
            <div class="absolute inset-0 flex items-center justify-center pointer-events-none
                        z-30" x-cloak
                 @click.outside="openKey=null;openRow=null">
                <?php
                    $items = collect($section['items'])
                             ->filter(fn($it)=>auth()->user()->can($it['permission']))
                             ->values()->take(8);
                ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $o=$offsets[$k]; ?>
                    <a href="<?php echo e(route($item['route'])); ?>"
                       class="absolute w-14 h-14 bg-white dark:bg-gray-800 rounded-full shadow-lg z-40
                              flex flex-col items-center justify-center pointer-events-auto
                              hover:scale-110 transition"
                       style="left:50%;top:50%;
                              transform:translate(-50%,-50%) translate(<?php echo e($o['x']); ?>px,<?php echo e($o['y']); ?>px);">
                        <i class="fas <?php echo e($item['icon']); ?> text-lg"></i>
                        <span class="text-xs whitespace-nowrap"><?php echo e($item['label']); ?></span>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </template>

    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
function getCols(){return window.innerWidth>=768?3:window.innerWidth>=640?2:1}

function menuGrid(){
return{
    openKey:null,openRow:null,columns:getCols(),
    init(){window.addEventListener('resize',()=>this.columns=getCols())},

    totalRows(){return Math.ceil(<?php echo e($visibleSections->count()); ?> / this.columns)},

    gridStyle () {
        const hasOpen = this.openKey !== null;

        const gap = hasOpen ? '8rem' : '2.5rem';
        const top = (hasOpen && this.openRow === 0) ? '6rem' : '0';
        const bot = (hasOpen && this.openRow === this.totalRows() - 1) ? '6rem' : '0';

        return `row-gap:${gap}; padding-top:${top}; padding-bottom:${bot}`;
    },

    toggle(idx){
        const row=Math.floor(idx/this.columns);

        this.openKey=this.openKey===idx?null:idx;
        this.openRow=this.openKey!==null?row:null;

        if(this.openKey!==null){
            /* aspetta il repaint + transizione (300ms) → 350ms total */
            this.$nextTick(()=>{
                setTimeout(()=>{
                    const el=this.$refs['tile'+idx];
                    if(el) centerTile(el);
                },150);
            });
        }
    }
}};
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\Users\vince\OneDrive\Desktop\gestionale-divani\resources\views/components/radial-grid-menu.blade.php ENDPATH**/ ?>