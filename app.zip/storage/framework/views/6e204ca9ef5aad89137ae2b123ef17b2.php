<?php $__env->startComponent('mail::message'); ?>
# <?php echo app('translator')->get('orders.email.outcome_title'); ?>

<?php echo app('translator')->get('orders.email.outcome_intro', ['order' => $order->orderNumber->full ?? ('#'.$order->id)]); ?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($accepted): ?>
- **<?php echo app('translator')->get('orders.email.outcome_status'); ?>**: <?php echo app('translator')->get('orders.email.outcome_confirmed'); ?>
<?php else: ?>
- **<?php echo app('translator')->get('orders.email.outcome_status'); ?>**: <?php echo app('translator')->get('orders.email.outcome_rejected'); ?>
- **<?php echo app('translator')->get('orders.email.outcome_reason'); ?>**: "<?php echo new \Illuminate\Support\EncodedHtmlString($reason); ?>"
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($poNumbers)): ?>
- **<?php echo app('translator')->get('orders.email.outcome_ponumbers'); ?>**: <?php echo new \Illuminate\Support\EncodedHtmlString(implode(', ', $poNumbers)); ?>

<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\vince\OneDrive\Desktop\gestionale-divani\resources\views/emails/orders/confirmation-outcome.blade.php ENDPATH**/ ?>